/* FitPlan 1.2: deterministic operational analytics, equipment-specific load context.
   Heuristics are NOT clinical predictions or proof of muscle growth. No network calls. */
(function(root){'use strict';
 const n=(x,d=0)=>{let a=Number(x);return Number.isFinite(a)?a:d;};
 const lim=(x,lo,hi)=>Math.max(lo,Math.min(hi,x));
 const median=a=>{if(!a.length)return null;const s=a.slice().sort((a,b)=>a-b);return s.length%2?s[(s.length-1)/2]:(s[s.length/2-1]+s[s.length/2])/2;};
 const done=s=>(s.items||[]).flatMap(it=>(it.sets||[]).filter(x=>x.done&&!x.warmup).map(set=>({it,set})));
 function machineRecord(state,e){
  if(!state.machines)state.machines={};
  if(!state.machines[e.id])state.machines[e.id]={active:'default',variants:[{id:'default',name:e.n+' 기본 기구',increment:e.gear==='dumbbell'?1:2.5,seat:'',notes:''}]};
  const rec=state.machines[e.id];
  if(!Array.isArray(rec.variants)||!rec.variants.length)rec.variants=[{id:'default',name:e.n+' 기본 기구',increment:2.5,seat:'',notes:''}];
  if(!rec.variants.some(x=>x.id===rec.active))rec.active=rec.variants[0].id;
  return rec;
 }
 function machineHistory(history,eid,machineId){
  return (history||[]).map(sess=>{
   const items=(sess.items||[]).map(it=>{
    const sets=(it.sets||[]).filter(s=>{
     const id=s.actualId||it.currentId||it.eid;
     const machine=s.machineId||it.machineId||'default';
     return id===eid&&machine===machineId;
    });
    return {...it,sets};
   }).filter(it=>it.sets.length);
   if(!items.length)return null;
   // When the individual exercise was rated, do not rely on the entire session's rating.
   const rating=items[0].effort;
   const feedback={...(sess.feedback||{}),...(rating?{difficulty:rating===1?3:rating===2?6:8}:{})};
   return {...sess,items,feedback};
  }).filter(Boolean);
 }
 function machineDecision(state,e,rdy){
  const rec=machineRecord(state,e),varnt=rec.variants.find(x=>x.id===rec.active);
  const h=machineHistory(state.history,e.id,rec.active);
  const analysis=root.FitPlanPrecisionV3.assessLoad(e,h,rdy,{increment:{[e.id]:lim(n(varnt.increment,2.5),.25,25)}});
  return {analysis,varnt,history:h,machineId:rec.active};
 }
 function excessiveFatigue(history){
  const now=Date.now();const last=(history||[]).filter(s=>{const t=n(s.finishedAt,Date.parse(s.date)||0);return t>0&&now-t<14*86400000;}).slice(-4);
  if(last.length<3)return {active:false,score:0,reason:'평가 기록이 더 필요합니다.'};
  const flags=last.map(s=>{
   const f=s.feedback||{};
   return n(f.difficulty,5)>=8 && n(f.soreness,2)>=4 ||
    n(s.readiness?.energy,3)<=2&&n(f.difficulty,5)>=8 || !!f.pain;
  });
  const score=flags.filter(Boolean).length;
  return {active:score>=3,score,reason:score>=3?'최근 네 번 중 세 번 이상 강한 피로·어려움이 기록되어 이번 운동량을 약 30% 줄입니다.':'최근 평가상 자동 회복 주간 기준에 해당하지 않습니다.'};
 }
 function pace(history){
  const ratios=(history||[]).slice(-10).map(s=>n(s.durationMin,0)/Math.max(1,n(s.predictedMinutes,n(s.timeLimit,60)))).filter(v=>v>=.55&&v<=2.5);
  return {factor:lim(median(ratios)||1,.8,1.65),samples:ratios.length};
 }
 function weeklyMuscles(state,catalog){
  const response=root.FitPlanPrecisionV3.responseModel(state.history,catalog);
  const credits=root.FitPlanPrecisionV3.weeklyMuscleCredits(state.history,catalog,{days:28});
  const targets=root.FitPlanPrecisionV3.muscleTargets(state.profile,{},response);
  const groups=Object.keys(targets);
  return groups.map(m=>({muscle:m,actual:n(credits[m])/4,target:n(targets[m]),response:response[m]||{},ratio:n(targets[m])>0?n(credits[m])/4/n(targets[m]):0}));
 }
 function exerciseSeries(history,eid,machine='default'){
  const out=[];for(const session of history||[]){
   const candidates=done(session).filter(x=>(x.set.actualId||x.it.currentId||x.it.eid)===eid&&(x.set.machineId||x.it.machineId||'default')===machine&&n(x.set.actualWeight)>0&&n(x.set.actualReps)>=2&&n(x.set.actualReps)<=15&&!x.set.pain);
   if(!candidates.length)continue;
   const best=Math.max(...candidates.map(x=>n(x.set.actualWeight)*(1+lim(n(x.set.actualReps)+lim(n(x.set.rir,0),0,5),1,18)/30)));
   const time=n(session.finishedAt,Date.parse(session.date)||0);
   if(time>0)out.push({date:new Date(time).toISOString().slice(0,10),time,value:best});
  }
  const byDay=new Map();for(const x of out)byDay.set(x.date,Math.max(x.value,byDay.get(x.date)||0));
  return [...byDay].map(([date,value])=>({date,value})).sort((a,b)=>a.date.localeCompare(b.date));
 }
 function forecast(history,eid,machine='default'){
  const series=exerciseSeries(history,eid,machine).slice(-12);
  if(series.length<4)return {ready:false,samples:series.length,reason:'비교 가능한 4일 이상의 운동 기록이 있어야 추세 범위를 표시합니다.'};
  const span=(Date.parse(series[series.length-1].date)-Date.parse(series[0].date))/86400000;
  if(span<14)return {ready:false,samples:series.length,reason:'최소 2주 이상 누적된 기록이 필요합니다.'};
  const early=median(series.slice(0,Math.max(2,Math.floor(series.length/3))).map(x=>x.value));
  const late=median(series.slice(-Math.max(2,Math.floor(series.length/3))).map(x=>x.value));
  const current=series[series.length-1].value;
  const weeklyGrowth=lim(Math.pow(Math.max(.75,late/Math.max(1,early)),7/span)-1,-.025,.025);
  // Broad scenario band, not a target or guaranteed strength gain.
  return {ready:true,current:Math.round(current*10)/10,lower:Math.round(current*Math.pow(1+weeklyGrowth-.018,4)*10)/10,
    upper:Math.round(current*Math.pow(1+weeklyGrowth+.018,4)*10)/10,weeklyGrowth:Math.round(weeklyGrowth*1000)/10,
    samples:series.length,reason:'4주 후 예상 수행지표의 탐색적 범위입니다. 실제 근육량 또는 달성 보장이 아닙니다.'};
 }
 function metrics(history){
  const recent=(history||[]).slice(-8);let good=0,doneSets=0,min=0;
  for(const s of recent){min+=Math.max(1,n(s.durationMin,1));for(const x of done(s)){doneSets++;if(n(x.set.actualReps)>=n(x.set.targetReps))good++;}}
  return {sessions:recent.length,sets:doneSets,min,completion:doneSets?Math.round(good/doneSets*100):null,
    setsPerHour:min?Math.round(doneSets/min*60*10)/10:null};
 }
 function personalResponse(history,catalog){
  const r=root.FitPlanPrecisionV3.responseModel(history,catalog);
  return Object.entries(r).map(([g,x])=>({muscle:g,...x,proposal:x.samples<4?'관찰 중':x.highFatigue?'피로 관리 우선':x.stalled&&x.recoveryAdequate?'계획 검토·소폭 조정':'현재 계획 유지'}));
 }
 root.FitPlanAdvanced={machineRecord,machineHistory,machineDecision,excessiveFatigue,pace,weeklyMuscles,forecast,exerciseSeries,metrics,personalResponse};
})(window);
