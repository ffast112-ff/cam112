/* FitPlan V6 pure, deterministic timer planning helpers; no medical claims. */
(function(root){
 const number=(x,d=0)=>Number.isFinite(Number(x))?Number(x):d;
 const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
 function recommendRest({planned=90,goal='hypertrophy',kind='compound',rir=null,form='good',changedExercise=false,readiness={}}={}){
   let result=number(planned,90);
   if(kind==='compound'&&goal==='strength')result=Math.max(result,150);
   else if(kind==='compound')result=Math.max(result,90);
   else result=Math.max(result,60);
   if(rir!==null&&rir!==undefined&&rir!==''&&Number.isFinite(Number(rir))){
     const effort=Number(rir);
     if(effort<=1)result+=30;
     else if(effort>=4&&kind!=='compound')result=Math.max(60,result-10);
   }
   if(form==='uncertain')result+=15;
   if(number(readiness.energy,3)<=2||number(readiness.soreness,2)>=4)result+=15;
   if(changedExercise)result=Math.max(result,60);
   return clamp(Math.ceil(result/5)*5,45,300);
 }
 const clock=(end,now)=>Math.max(0,Math.ceil((number(end)-number(now))/1000));
 const expired=(end,now,paused)=>!paused&&number(end)>0&&number(now)>=number(end);
 root.FitPlanTimerV6={recommendRest,clock,expired};
})(typeof window==='undefined'?globalThis:window);
