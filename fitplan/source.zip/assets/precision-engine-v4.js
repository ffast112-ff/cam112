/* FitPlan Precision Engine V4 — bounded, offline, joint routine optimizer.
 * Heuristic engineering policy, NOT a validated physiological prediction model.
 * V3 remains the low-level engine for safe loads, exercise compatibility,
 * set prescription, observed training response and training history.
 */
(function(root,make){
  const base=root.FitPlanPrecisionV3 || (typeof require==='function'?require('./precision-engine-v3.js'):null);
  const api=make(base);
  if(typeof module==='object'&&module.exports)module.exports=api;
  root.FitPlanPrecisionV4=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(V3){
'use strict';
if(!V3)throw Error('FitPlan V4 requires Precision V3');
const VERSION='4.0.0',DAY=86400000;
const MUSCLES=['가슴','등','어깨','하체','뒤허벅지','둔근','이두','삼두','복부','종아리'];
const PRIMARY=new Set(['가슴','등','어깨','하체','뒤허벅지']);
const CREDIT={
 squat:{'하체':1,'둔근':.4},hinge:{'뒤허벅지':1,'둔근':.4},glutes:{'둔근':1},
 push:{'가슴':1,'삼두':.35,'어깨':.15},chestiso:{'가슴':1},
 pullvertical:{'등':1,'이두':.35},pullhorizontal:{'등':1,'이두':.35},
 verticalpush:{'어깨':1,'삼두':.35},shoulderiso:{'어깨':1},
 biceps:{'이두':1},triceps:{'삼두':1},core:{'복부':1},calves:{'종아리':1}
};
const SIMPLE=['leg_press','chest_press','lat_pulldown','seated_row','rld_machine','shoulder_press','goblet_squat','body_squat','pushup','db_row','db_press','db_shoulder','glute_bridge','plank','dead_bug','walking','biceps_curl','triceps_push','lateral_raise','calf_raise','db_rdl','band_row','cable_curl'];
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const N=(x,d=0)=>x===undefined||x===null||x===''?d:(Number.isFinite(Number(x))?Number(x):d);
const R=(x,d=1)=>Math.round(x*10**d)/10**d;
const sum=a=>a.reduce((x,y)=>x+y,0);
const fresh=()=>Object.fromEntries(MUSCLES.map(x=>[x,0]));
const focusSet=p=>{const s=new Set(p.focus||[]);if(s.has('팔')){s.add('삼두');s.add('이두');}if(s.has('하체')){s.add('둔근');s.add('뒤허벅지');s.add('종아리');}return s;};
const profileKey=p=>[p.goal,p.physique,p.level,p.days,p.place,[...(p.focus||[])].sort().join(',')].join('|');
const working=item=>item.sets.filter(s=>!s.warmup).length;
const pressure=read=>read.pain||read.energy<=2||read.sleep<=2||read.soreness>=4;
const duration=e=>e?.pattern==='core'||e?.pattern==='cardio';
function recentFatigue(history,catalog,now){
  const lookup=new Map(catalog.map(e=>[e.id,e])),fatigue=fresh(),last=fresh();
  const recent=(history||[]).filter(h=>{const t=N(h.finishedAt||h.timestamp,Date.parse(h.date)||0);return t>0&&now-t>=0&&now-t<5*DAY;});
  for(const h of recent){const t=N(h.finishedAt||h.timestamp,Date.parse(h.date)||0),elapsed=(now-t)/DAY;
    const decay=elapsed<1?1:elapsed<2?.65:elapsed<3?.35:elapsed<4?.17:.07;
    for(const it of h.items||[])for(const s of it.sets||[]){
      if(!s.done||s.warmup||s.role==='warmup')continue;
      const ex=lookup.get(s.actualId||it.currentId||it.eid||it.id),weights=CREDIT[ex?.pattern||it.pattern]||{};
      for(const m in weights){fatigue[m]+=weights[m]*decay*(s.rir!==null&&N(s.rir,3)<=1?1.15:1);last[m]=Math.max(last[m],decay);}
    }
  }
  return {fatigue,last};
}
function musclePriority(m,p,focus){return (PRIMARY.has(m)?1.13:.8)*(focus.has(m)?1.35:1)*((p.physique==='athletic'&&['등','어깨','하체'].includes(m))?1.07:1);}
function weeklyQuota(split,p,targets,completed,catalog,readiness,unavailable,index){
  const visits=clamp(p.days,2,6),exposures=fresh();
  for(let i=0;i<visits;i++){
    const t=split.days[(index+i)%split.days.length],seen=new Set();
    for(const pat of t.patterns){
      if(!(CREDIT[pat])||!catalog.some(e=>e.pattern===pat&&V3.allowedExercise(e,p,readiness,unavailable)))continue;
      for(const m in CREDIT[pat])if(CREDIT[pat][m]>=.7)seen.add(m);
    }
    for(const m of seen)exposures[m]++;
  }
  const target=fresh(),remaining=fresh();
  for(const m of MUSCLES){remaining[m]=Math.max(0,N(targets[m])-N(completed[m]));
    target[m]=R(clamp(remaining[m]/Math.max(1,exposures[m]),0,8),2);
  }
  return {target,remaining,exposures};
}
function recentMatch(history,dayName){
  const s=(history||[]).slice().reverse().find(s=>s.splitName===dayName && (s.items||[]).some(it=>(it.sets||[]).some(z=>z.done&&!z.warmup)));
  return new Set((s?.items||[]).map(x=>x.currentId||x.eid||x.id));
}
function chooseSplit(input){
  const p=V3.normalizeProfile(input.profile),r=V3.normalizeReadiness(input.readiness);
  const rankings=V3.rankSplits({...input,profile:p,readiness:r}),byId=new Map(rankings.map(x=>[x.id,x]));
  const memory=input.context?.planMemory||{},now=N(input.context?.now,Date.now());
  const old=byId.get(memory.split),same=memory.profileKey===profileKey(p);
  const sessionsAfter=Math.max(0,N(input.sessionIndex,0)-N(memory.sessionIndex,0));
  const age=now-N(memory.selectedAt,now);
  const eligible=sessionsAfter>=Math.max(3,p.days) && age>=14*DAY;
  const diff=old?rankings[0].score-old.score:0;
  const lock=!!old&&same&&(rankings[0].id===old.id||!eligible||diff<8);
  const picked=lock?old:rankings[0],changed=!!old&&picked.id!==old.id;
  return {split:V3.SPLITS.find(s=>s.id===picked.id),selected:picked,rankings,
    held:lock&&rankings[0].id!==picked.id,changed,scoreGap:diff,
    reason:lock&&rankings[0].id!==picked.id?'하루 상태 변화로 분할이 자주 바뀌지 않도록 기존 분할을 유지했습니다.':
     changed?'기존 분할보다 훈련 빈도·일정 적합성 평가가 충분히 개선되어 재선정했습니다.':'현재 운동 빈도와 목표에 적합한 분할 후보를 선택했습니다.'};
}
function exerciseGoal(e,p){return p.goal==='strength'&&e.kind!=='compound'?'hypertrophy':p.goal;}
function safeMaxSets(e,p,r,response,focus,minutes){
  if(pressure(r)||response[e.m]?.highFatigue)return 2;
  const v=[3,4,5,6][p.level]+(p.level>=2&&focus.has(e.m)&&minutes>=90?1:0);
  return clamp(v,2,7);
}
function planSet(e,ctx,n){
  const tailored={...ctx.p,goal:exerciseGoal(e,ctx.p)};
  return V3.prescribeSets(e,tailored,ctx.r,ctx.loads.get(e.id),n);
}
function seconds(e,sets,ctx){return V3.estimateExerciseSeconds(e,sets,ctx.history,ctx.now)*ctx.pace;}
function stockCredit(items){const out=fresh();for(const it of items){const c=CREDIT[it.pattern]||{},count=working(it);
    for(const m in c)out[m]+=c[m]*count;
  }return out;}
function benefitAt(m,amount,quota,p,focus){
  const q=Math.max(1,quota.target[m]),x=Math.max(0,amount),priority=musclePriority(m,p,focus);
  // Diminishing returns: abstract planning utility, NOT muscle growth prediction.
  const useful=6*priority*q*(1-Math.exp(-Math.min(x,q)*.72/q));
  const excess=Math.max(0,x-q)*(.30+(x-q)*.16)*priority;
  return useful-excess;
}
function baseBenefit(items,ctx){
  const credited=stockCredit(items);let score=0;
  for(const m of MUSCLES)score+=benefitAt(m,credited[m],ctx.quota,ctx.p,ctx.focus);
  return score;
}
function pairCost(a,b){
  if(a.pattern===b.pattern)return 2.1;
  const ca=CREDIT[a.pattern]||{},cb=CREDIT[b.pattern]||{};
  let overlap=0;for(const m in ca)overlap+=ca[m]*(cb[m]||0);
  return overlap*1.4;
}
function interference(items,ctx){
  let score=0;for(let i=0;i<items.length;i++){
    const z=items[i],credit=CREDIT[z.pattern]||{};
    for(const m in credit)score+=credit[m]*Math.max(0,ctx.fatigue.fatigue[m]-2.5)*.65*working(z);
    for(let j=0;j<i;j++)score+=pairCost(z,items[j])*.35;
  }return score;
}
function familiarity(ex,ctx){
 const own=ctx.oldExercises.has(ex.id);
 const plateau=ctx.response?.[ex.m];
 // Consider a change only after a repeated, recovery-adequate plateau.
 return own?(plateau?.stalled&&plateau?.recoveryAdequate?.4:1.1):0;
}
function importance(item,ctx){
  const e=item.exercise,focus=ctx.focus.has(e.m),first=PRIMARY.has(e.m);
  return (focus?5:0)+(first?3:0)+(e.kind==='compound'?2.5:0)+familiarity(e,ctx)+Math.min(4,ctx.quota.target[e.m]||0);
}
function optimizeOrder(items,ctx){
  const ordered=[];const left=items.slice();
  while(left.length){let best=-Infinity,ix=0;
    for(let i=0;i<left.length;i++){
      const it=left[i],prev=ordered[ordered.length-1];
      let value=importance(it,ctx)-(prev?pairCost(prev,it)*2:0);
      if(prev&&prev.exercise.kind==='compound'&&it.exercise.kind==='compound'&&prev.muscle===it.muscle)value-=1.7;
      if(value>best){best=value;ix=i;}
    }ordered.push(left.splice(ix,1)[0]);
  }
  // Local pairwise refinement prevents unnecessary same-muscle sequencing.
  function value(a){return a.reduce((v,it,i)=>v+importance(it,ctx)*(1-(i/Math.max(1,a.length))*.20)-(i?pairCost(a[i-1],it)*2:0),0);}
  for(let pass=0;pass<2;pass++)for(let i=0;i+1<ordered.length;i++){
    const swapped=ordered.slice();[swapped[i],swapped[i+1]]=[swapped[i+1],swapped[i]];
    if(value(swapped)>value(ordered)+.001){[ordered[i],ordered[i+1]]=[ordered[i+1],ordered[i]];}
  }
  return ordered;
}
function sessionScore(items,ctx){
  const body=baseBenefit(items,ctx),overlap=interference(items,ctx);
  const time=sum(items.map(it=>seconds(it.exercise,it.sets,ctx)))/60;
  const recurring=sum(items.map(it=>familiarity(it.exercise,ctx))),
    variety=new Set(items.map(z=>z.pattern)).size;
  const orderCost=sum(items.slice(1).map((z,i)=>pairCost(items[i],z)))*.9;
  const sparsePenalty=items.length<2?6:0;
  // Feasible plans may finish early; do not add low-value sets just to fill time.
  return {total:R(body-overlap-orderCost-time*.19+recurring*.8+variety*.9-sparsePenalty,2),
    trainingUtility:R(body,2),overlapPenalty:R(overlap,2),orderPenalty:R(orderCost,2),timeCost:R(time*.19,2),repeatBonus:R(recurring*.8,2),varietyBonus:R(variety*.9,2)};
}
function candidateExercise(e,ctx){
  const decision=ctx.loads.get(e.id);
  if(!decision||decision.action==='stop')return null;
  const one=pressure(ctx.r)||decision.setsAdjustment<0?1:2;
  const sets=planSet(e,ctx,one);
  const cap=safeMaxSets(e,ctx.p,ctx.r,ctx.response,ctx.focus,ctx.minutes);
  return {id:e.id,name:e.n,muscle:e.m,pattern:e.pattern,gear:e.gear,kind:e.kind,
    exercise:e,sets,maxWorkingSets:cap,loadDecision:decision,reason:decision.reason};
}
function runCandidate(split,variant,ctx){
  const template=split.days[ctx.sessionIndex%split.days.length];
  const patterns=template.patterns.filter(pat=>(CREDIT[pat])&&ctx.catalog.some(e=>e.pattern===pat&&V3.allowedExercise(e,ctx.p,ctx.r,ctx.unavailable)));
  if(!patterns.length)return null;
  const stretch=V3.stretchesFor(patterns,ctx.minutes);
  const budget=ctx.minutes*60-stretch.preSeconds-stretch.postSeconds-ctx.minutes*60*.035;
  const maxExercises=clamp(Math.ceil((ctx.minutes-8)/15),2,7)+(ctx.focus.size>1&&ctx.minutes>=90?1:0);
  const candidates=[];
  for(const pat of patterns){
    const possible=ctx.catalog.filter(e=>e.pattern===pat&&V3.allowedExercise(e,ctx.p,ctx.r,ctx.unavailable));
    possible.sort((a,b)=>{
      const rank=e=>{const familiar=ctx.oldExercises.has(e.id)?(ctx.response?.[e.m]?.stalled&&ctx.response?.[e.m]?.recoveryAdequate?1:4):0,
        simple=SIMPLE.includes(e.id)?3-SIMPLE.indexOf(e.id)*.035:0,
        deficit=(ctx.quota.target[e.m]||0)*.45,
        variety=(variant===1&&e.kind==='isolation'?1.2:variant===2&&e.gear==='machine'?1.2:0),
        fatigue=ctx.fatigue.fatigue[e.m]*.16;
        return familiar+simple+deficit+variety-fatigue-N(e.level)*.28;};
      return rank(b)-rank(a)||a.id.localeCompare(b.id);
    });
    for(const e of possible.slice(0,variant===1?2:1)){
      if(!ctx.loads.has(e.id))ctx.loads.set(e.id,V3.assessLoad(e,ctx.history,ctx.r,{now:ctx.now}));
      const item=candidateExercise(e,ctx);if(item)candidates.push(item);
    }
  }
  const items=[],used=new Set();
  let score=sessionScore(items,ctx).total,est=0;
  for(let iter=0;iter<44;iter++){
    const actions=[];
    // Jointly compare one extra set on an existing movement with a new movement.
    for(let i=0;i<items.length;i++){
      const it=items[i],n=working(it);if(n>=it.maxWorkingSets)continue;
      const proposed={...it,sets:planSet(it.exercise,ctx,n+1)};
      const withNext=items.map((a,j)=>j===i?proposed:a);
      const newTime=sum(withNext.map(z=>seconds(z.exercise,z.sets,ctx)));
      if(newTime>budget||newTime<=est)continue;
      const q=sessionScore(optimizeOrder(withNext,ctx),ctx).total,
        gain=q-score;
      if(gain>.16)actions.push({items:withNext,time:newTime,score:q,eff:gain/((newTime-est)/60+.9),gain,action:'set'});
    }
    if(items.length<maxExercises)for(const it of candidates){
      if(used.has(it.id))continue;
      if(items.some(x=>x.pattern===it.pattern))continue;
      const withNext=[...items,it],newTime=sum(withNext.map(z=>seconds(z.exercise,z.sets,ctx)));
      if(newTime>budget)continue;
      const q=sessionScore(optimizeOrder(withNext,ctx),ctx).total,gain=q-score;
      if(gain>.18)actions.push({items:withNext,time:newTime,score:q,eff:gain/((newTime-est)/60+1.1),gain,action:'exercise'});
    }
    actions.sort((a,b)=>b.eff-a.eff||b.gain-a.gain);
    if(!actions.length)break;
    const chosen=actions[0];items.length=0;items.push(...chosen.items);
    used.clear();for(const it of items)used.add(it.id);
    est=chosen.time;score=chosen.score;
  }
  if(!items.length)return null;
  const ordered=optimizeOrder(items,ctx),scorecard=sessionScore(ordered,ctx);
  const finalSec=sum(ordered.map(it=>seconds(it.exercise,it.sets,ctx)))+stretch.preSeconds+stretch.postSeconds;
  if(finalSec>ctx.minutes*60+1)return null;
  const clean=ordered.map((it,index)=>{
    const count=working(it),fatigue=R(ctx.fatigue.fatigue[it.muscle],1),q=ctx.quota.target[it.muscle];
    return {id:it.id,name:it.name,muscle:it.muscle,pattern:it.pattern,gear:it.gear,kind:it.kind,
      sets:it.sets,estimateSeconds:Math.ceil(seconds(it.exercise,it.sets,ctx)),loadDecision:it.loadDecision,
      volumeReason:`${it.muscle}: 최근 7일 ${R(ctx.weekly[it.muscle],1)}세트 / 목표 ${ctx.targets[it.muscle]}세트, 오늘 배정 ${count}본세트. 회복·중복 자극을 고려했습니다.`,
      reason:`${it.loadDecision.reason} 오늘 ${count}본세트 · 잔여 목표 분배 ${R(q,1)} · 최근 피로 참고값 ${fatigue}. ${index===0?'목표 운동을 우선 배치했습니다.':'운동 간 중복 피로를 줄이도록 순서를 배치했습니다.'}`};
  });
  return {split:split.id,dayName:template.name,splitLabel:split.name,stretch,items:clean,
    score:scorecard.total,scorecard,estimatedSeconds:Math.ceil(finalSec),variant};
}
function planningContext(input={}){
  const p=V3.normalizeProfile(input.profile||{}),r=V3.normalizeReadiness(input.readiness||{}),catalog=input.catalog||[],history=input.history||[];
  const minutes=clamp(Math.round(N(input.minutes,p.duration)),30,120),now=N(input.context?.now,Date.now()),
    unavailable=input.unavailable||[],sessionIndex=clamp(Math.floor(N(input.sessionIndex,0)),0,1e7),
    selected=chooseSplit({profile:p,readiness:r,catalog,history,unavailable,sessionIndex,context:input.context||{}}),
    response=V3.responseModel(history,catalog,{now}),targets=V3.muscleTargets(p,r,response),weekly=V3.weeklyMuscleCredits(history,catalog,{now}),
    focus=focusSet(p),fatigue=recentFatigue(history,catalog,now),pace=clamp(N(input.context?.pace,1),.85,1.4),
    oldExercises=recentMatch(history,selected.split.days[sessionIndex%selected.split.days.length].name);
  return {p,r,catalog,history,minutes,now,unavailable,sessionIndex,selected,response,targets,weekly,focus,fatigue,pace,oldExercises,loads:new Map()};
}
function planDay(input={}){
  const c=planningContext(input),safety={stop:false,flags:[]};
  if(c.r.pain&&!c.r.painArea){safety.stop=true;safety.flags.push('통증 부위 확인 전에는 운동을 자동 처방하지 않습니다.');}
  if(c.r.pain)safety.flags.push('운동에 영향을 주는 통증이 있다면 관련 운동은 피하고 지속될 경우 전문가와 상의하세요.');
  const rankedMap=new Map(c.selected.rankings.map(x=>[x.id,x]));
  const topPerSplit=[];
  if(!safety.stop)for(const split of V3.SPLITS){
    const quota=weeklyQuota(split,c.p,c.targets,c.weekly,c.catalog,c.r,c.unavailable,c.sessionIndex);
    const day=split.days[c.sessionIndex%split.days.length].name;
    const specific={...c,quota,oldExercises:recentMatch(c.history,day)};
    const runs=[];for(const variant of [0,1,2]){
      const candidate=runCandidate(split,variant,specific);
      if(candidate){
        candidate.combined=R(candidate.score+(rankedMap.get(split.id)?.score||0)*.42,2);
        runs.push(candidate);
      }
    }
    runs.sort((a,b)=>b.combined-a.combined||a.estimatedSeconds-b.estimatedSeconds);
    if(runs.length)topPerSplit.push({...runs[0],alternatives:runs.length});
  }
  topPerSplit.sort((a,b)=>b.combined-a.combined||a.split.localeCompare(b.split));
  const memory=input.context?.planMemory||{};
  const prior=topPerSplit.find(x=>x.split===memory.split),best=topPerSplit[0];
  const same=memory.profileKey===profileKey(c.p),age=c.now-N(memory.selectedAt,c.now),
    after=c.sessionIndex-N(memory.sessionIndex,c.sessionIndex),
    mature=age>=14*DAY&&after>=Math.max(3,c.p.days),
    improvement=best&&prior?best.combined-prior.combined:Infinity;
  const hold=!!(prior&&best&&prior!==best&&same&&(!mature||improvement<10));
  // The first optimizer decision is joint across split, exercise, set and order.
  // Once a split is established, require a meaningful improvement before switching.
  const chosen=hold?prior:best,
    changed=!!(prior&&chosen&&prior.split!==chosen.split),
    actualSplit=V3.SPLITS.find(s=>s.id===chosen?.split)||c.selected.split,
    splitChoice=changed?'여러 운동일의 결과가 누적되어 새로운 분할이 충분히 적합하다고 평가됐습니다.':
      hold?'한 번의 컨디션 변화로 전체 분할이 자주 바뀌지 않도록 기존 분할을 유지했습니다.':
      '1~4분할의 운동량·빈도·시간·중복 피로를 동시에 비교했습니다.';
  const stretch=chosen?.stretch||V3.stretchesFor([],c.minutes);
  const sessionTarget=weeklyQuota(actualSplit,c.p,c.targets,c.weekly,c.catalog,c.r,c.unavailable,c.sessionIndex);
  if(!chosen&&!safety.stop)safety.flags.push('사용 가능한 운동·장비·시간에 맞는 안전한 루틴 후보가 없습니다.');
  const comparison=topPerSplit.map(x=>({id:x.split,label:x.splitLabel,score:x.combined,
    splitScore:rankedMap.get(x.split)?.score||0,dayScore:x.score,variant:x.variant,items:x.items.length,
    sets:x.items.reduce((n,z)=>n+working(z),0),durationMinutes:Math.ceil(x.estimatedSeconds/60)}));
  // Include the other split templates in the comparison even if no feasible plan exists.
  for(const s of c.selected.rankings)if(!comparison.some(x=>x.id===s.id))comparison.push({id:s.id,label:s.label,score:-999,unavailable:true});
  const explanations=[splitChoice,
    `${topPerSplit.length}개 분할에서 총 ${topPerSplit.reduce((n,x)=>n+x.alternatives,0)}개 종목·세트·순서 조합을 평가했습니다. 추가 이득이 작으면 남는 시간을 억지로 채우지 않습니다.`,
    '주간 목표 세트, 주동근·보조근 중복, 최근 운동의 간접 피로, 시간, 기존 종목 연속성과 우선순위를 계산했습니다.'];
  if(chosen)explanations.push(`오늘 ${chosen.items.length}종목, ${chosen.items.reduce((x,it)=>x+working(it),0)}본세트를 약 ${Math.ceil(chosen.estimatedSeconds/60)}분으로 구성했습니다.`);
  return {schema:'precision-v4',version:VERSION,profileSnapshot:c.p,readiness:c.r,split:actualSplit.id,
    splitLabel:actualSplit.name,dayName:chosen?.dayName||actualSplit.days[c.sessionIndex%actualSplit.days.length].name,
    splitCandidates:comparison,minutes:c.minutes,estimatedSeconds:chosen?.estimatedSeconds||0,
    estimatedMinutes:chosen?Math.ceil(chosen.estimatedSeconds/60):0,
    unusedMinutes:chosen?R(Math.max(0,c.minutes*60-chosen.estimatedSeconds)/60,1):c.minutes,
    weeklyTarget:c.targets,weeklyDone:c.weekly,weeklyQuota:sessionTarget.target,
    plannedWorkingCredits:chosen?stockCredit(chosen.items):fresh(),items:chosen?.items||[],stretch,safety,concerns:safety.flags,
    explanation:explanations.join(' '),
    optimizer:{engine:VERSION,splitSelection:{split:actualSplit.id,held:hold,changed,improvement:R(improvement,2),reason:splitChoice},
      profileKey:profileKey(c.p),candidateCount:topPerSplit.reduce((n,x)=>n+x.alternatives,0),
      splitComparison:comparison,candidateScores:topPerSplit.slice(0,4).map(x=>({split:x.split,score:x.combined,scorecard:x.scorecard,items:x.items.map(z=>z.id)})),
      scorecard:chosen?.scorecard||null,weeklyQuota:sessionTarget.target,
      fatigue:Object.fromEntries(MUSCLES.map(m=>[m,R(c.fatigue.fatigue[m],1)])),
      changePolicy:'한 번의 피로 변화로 루틴을 바꾸지 않으며, 회복이 충분한 장기 정체 또는 목표 변화에서 재평가',
      heuristic:true,clinicallyValidated:false},
    metadata:{createdAt:c.now,paceFactor:c.pace,scoringType:'bounded-multi-criteria-heuristic',clinicalValidation:false}};
}

function planProgram(input={}){
  const c=planningContext(input),weeks=clamp(Math.round(N(input.weeks,8)),4,12),planned=planDay(input),
    split=V3.SPLITS.find(s=>s.id===planned.split)||c.selected.split;
  const calendar=[],alerts=[];
  if(!c.history.length)alerts.push('첫 1~2주는 시작 중량과 동작 숙련도를 확인하는 적응 기간입니다.');
  if(pressure(c.r))alerts.push('현재 피로·통증 정보 때문에 증량보다 회복을 우선합니다.');
  for(let w=0;w<weeks;w++){
    const phase=w<2?'적응·기준 측정':w>=weeks-2?'성과 점검·재설계':'점진적 발전·회복 조절';
    const sessions=[];
    for(let j=0;j<c.p.days;j++){
      const step=w*c.p.days+j,day=split.days[(c.sessionIndex+step)%split.days.length];
      sessions.push({sequence:step+1,slot:j+1,name:day.name,patterns:day.patterns.slice(),minutes:c.p.duration,
        target:'실제 세트 목표는 당일 기록과 컨디션으로 재계산'});
    }
    const response=c.response,heavy=Object.values(response).some(x=>x.highFatigue);
    calendar.push({week:w+1,phase,sessions,review:w===1||w===weeks-1||(w+1)%4===0,
      guidance:heavy?'피로 누적이 확인되면 세트 수를 줄이고 회복을 확보합니다.':
        w<2?'기술과 기준 중량을 확인하고 무리한 증량을 피합니다.':
        w>=weeks-2?'누적 기록을 비교하고 다음 주기를 재설계합니다.':'목표 반복 달성률과 회복을 확인해 필요할 때만 증량합니다.',
      weeklyTargets:{...c.targets}});
  }
  return {schema:'precision-v4-program',version:VERSION,weeks,split:split.id,splitLabel:split.name,
    candidates:planned.splitCandidates,weeklyTargets:c.targets,calendar,alerts,
    reviewCycle:'매 운동 후 중량을 갱신하고, 약 2~4주마다 운동량·분할·집중 부위를 재평가',
    stability:planned.optimizer?.splitSelection?.reason||c.selected.reason,
    notes:['이 달력은 고정된 중량표가 아닙니다. 당일 시간·회복·실제 운동 성과에 따라 다시 계산합니다.',
      '추가 세트의 이득·중복 자극·회복은 보수적인 규칙 기반 추정치로 실제 근육 성장률을 측정한 값이 아닙니다.']};
}
function validatePlan(plan){
  const v=V3.validatePlan(plan),issues=[...v.issues];
  if(new Set(plan.items.map(x=>x.id)).size!==plan.items.length)issues.push('duplicate-exercise');
  if(plan.items.length>8)issues.push('too-many-movements');
  if(plan.optimizer?.clinicallyValidated!==false)issues.push('missing-model-disclaimer');
  return {ok:issues.length===0,issues};
}
return {...V3,VERSION,rankSplits:V3.rankSplits,selectSplit:(p,cat,h,r,unavail,context)=>{
 const plan=planDay({profile:p,catalog:cat,history:h,readiness:r,unavailable:unavail||[],minutes:p?.duration||60,context:context||{}});
 return {split:V3.SPLITS.find(s=>s.id===plan.split),score:plan.splitCandidates.find(s=>s.id===plan.split)?.score||0,
   candidates:plan.splitCandidates,reason:plan.optimizer.splitSelection.reason,held:plan.optimizer.splitSelection.held};
},planDay,planProgram,validatePlan,chooseSplit,profileKey,recentFatigue,
  scorePlan:(plan)=>plan.optimizer?.scorecard||null};
});
