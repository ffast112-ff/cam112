const CATALOG=[
 {id:'leg_press',n:'레그프레스 머신',en:'leg press machine proper form',m:'하체',pattern:'squat',gear:'machine',level:0,kind:'compound',tips:'등과 엉덩이를 등받이에 붙이고, 무릎이 발끝 방향으로 이동하도록 천천히 굽혔다 펴세요. 무릎을 완전히 잠그지 마세요.'},
 {id:'goblet_squat',n:'고블릿 스쿼트',en:'goblet squat tutorial',m:'하체',pattern:'squat',gear:'dumbbell',level:0,kind:'compound',tips:'덤벨을 가슴 앞에 들고, 복부에 힘을 준 상태에서 앉았다 일어나세요. 가능한 범위에서 발바닥 전체로 밀어주세요.'},
 {id:'body_squat',n:'맨몸 스쿼트',en:'bodyweight squat tutorial',m:'하체',pattern:'squat',gear:'body',level:0,kind:'compound',tips:'발을 어깨 너비로 놓고 무릎과 발끝 방향을 일치시키며 천천히 앉았다 일어나세요.'},
 {id:'split_squat',n:'스플릿 스쿼트',en:'split squat exercise form',m:'하체',pattern:'squat',gear:'body',level:1,kind:'compound',tips:'한쪽 발을 앞으로 놓고 상체를 세운 채 위아래로 내려갔다 올라오세요. 균형이 불안하면 벽을 잡으세요.'},
 {id:'chest_press',n:'체스트프레스 머신',en:'seated chest press machine tutorial',m:'가슴',pattern:'push',gear:'machine',level:0,kind:'compound',tips:'손잡이가 가슴 중앙 높이에 오도록 좌석을 조정하세요. 어깨를 으쓱하지 않고 손잡이를 전방으로 밀었다 천천히 돌아오세요.'},
 {id:'db_press',n:'덤벨 벤치프레스',en:'dumbbell bench press tutorial',m:'가슴',pattern:'push',gear:'dumbbell',level:1,kind:'compound',tips:'벤치에 등을 대고 발을 바닥에 고정하세요. 팔꿈치를 과도하게 벌리지 않고 덤벨을 천천히 내렸다 밀어 올리세요.'},
 {id:'bench_press',n:'바벨 벤치프레스',en:'barbell bench press form beginner',m:'가슴',pattern:'push',gear:'barbell',level:2,kind:'compound',tips:'보조자가 있거나 안전 장치를 활용하세요. 견갑을 안정적으로 고정하고 바벨을 통제하며 내렸다 밀어 올리세요.'},
 {id:'pushup',n:'푸시업',en:'push up exercise form beginner',m:'가슴',pattern:'push',gear:'body',level:0,kind:'compound',tips:'머리부터 발끝까지 일직선을 유지하며 팔꿈치를 적당히 굽혀 몸을 내렸다 밀어 올리세요. 어려우면 무릎을 대세요.'},
 {id:'cable_fly',n:'케이블 플라이',en:'cable chest fly tutorial',m:'가슴',pattern:'chestiso',gear:'cable',level:1,kind:'isolation',tips:'팔꿈치를 약간 굽힌 채 가슴 앞에서 손을 모았다가 천천히 벌리세요. 과도하게 어깨를 뒤로 젖히지 마세요.'},
 {id:'lat_pulldown',n:'랫풀다운 머신',en:'lat pulldown proper form',m:'등',pattern:'pullvertical',gear:'machine',level:0,kind:'compound',tips:'가슴을 약간 세우고 바를 쇄골 쪽으로 당긴 뒤 통제하면서 올리세요. 몸통을 과하게 젖히지 마세요.'},
 {id:'assisted_pullup',n:'어시스트 풀업',en:'assisted pull up machine form',m:'등',pattern:'pullvertical',gear:'machine',level:1,kind:'compound',tips:'보조 중량을 설정하고 어깨를 안정적으로 내리면서 가슴을 바 쪽으로 끌어올리세요.'},
 {id:'pullup',n:'풀업',en:'pull up form tutorial',m:'등',pattern:'pullvertical',gear:'body',level:2,kind:'compound',tips:'반동 없이 견갑 움직임부터 시작하여 턱이 바 위에 접근할 때까지 당기세요. 불편하면 보조 운동으로 바꾸세요.'},
 {id:'seated_row',n:'시티드 로우 머신',en:'seated cable row proper form',m:'등',pattern:'pullhorizontal',gear:'machine',level:0,kind:'compound',tips:'허리를 중립으로 유지하고 팔꿈치를 뒤로 보내며 당기세요. 몸통 반동 없이 천천히 돌아오세요.'},
 {id:'db_row',n:'원암 덤벨 로우',en:'one arm dumbbell row tutorial',m:'등',pattern:'pullhorizontal',gear:'dumbbell',level:1,kind:'compound',tips:'반대쪽 손을 벤치에 짚고 등을 곧게 유지하며 팔꿈치를 골반 쪽으로 당기세요.'},
 {id:'band_row',n:'밴드 로우',en:'resistance band row tutorial',m:'등',pattern:'pullhorizontal',gear:'band',level:0,kind:'compound',tips:'밴드를 고정하고 가슴을 세운 상태에서 손잡이를 배 쪽으로 당긴 뒤 천천히 풀어주세요.'},
 {id:'rld_machine',n:'레그컬 머신',en:'seated leg curl machine form',m:'뒤허벅지',pattern:'hinge',gear:'machine',level:0,kind:'isolation',tips:'골반을 고정하고 무릎을 부드럽게 굽혀 뒤허벅지에 힘을 주세요. 빠른 반동을 피하세요.'},
 {id:'db_rdl',n:'덤벨 루마니안 데드리프트',en:'dumbbell romanian deadlift tutorial',m:'뒤허벅지',pattern:'hinge',gear:'dumbbell',level:1,kind:'compound',tips:'무릎을 약간 굽히고 엉덩이를 뒤로 밀며 덤벨을 허벅지 가까이 내리세요. 허리 대신 둔근과 햄스트링을 사용하세요.'},
 {id:'glute_bridge',n:'글루트 브리지',en:'glute bridge exercise proper form',m:'둔근',pattern:'glutes',gear:'body',level:0,kind:'compound',tips:'바닥에 누워 무릎을 굽힌 뒤 복부에 힘을 주고 엉덩이를 들어 올리세요. 허리를 과도하게 꺾지 마세요.'},
 {id:'hip_thrust',n:'힙 쓰러스트 머신',en:'hip thrust machine proper form',m:'둔근',pattern:'glutes',gear:'machine',level:1,kind:'compound',tips:'패드가 골반에 안정적으로 놓이도록 조절하고 둔근으로 밀어 올리세요. 과한 허리 신전을 피하세요.'},
 {id:'shoulder_press',n:'숄더프레스 머신',en:'shoulder press machine tutorial',m:'어깨',pattern:'verticalpush',gear:'machine',level:0,kind:'compound',tips:'손잡이가 귀 근처에서 시작하도록 좌석을 조절하고, 통증 없는 가동 범위에서 밀어 올리세요.'},
 {id:'db_shoulder',n:'덤벨 숄더프레스',en:'seated dumbbell shoulder press form',m:'어깨',pattern:'verticalpush',gear:'dumbbell',level:1,kind:'compound',tips:'등받이에 기대어 복부에 힘을 주고 덤벨을 통제하며 위로 밀어 올리세요.'},
 {id:'lateral_raise',n:'덤벨 사이드 레터럴 레이즈',en:'dumbbell lateral raise proper form',m:'어깨',pattern:'shoulderiso',gear:'dumbbell',level:0,kind:'isolation',tips:'가벼운 덤벨로 팔꿈치를 약간 굽힌 채 옆으로 들어 올리세요. 승모근으로 으쓱거리지 마세요.'},
 {id:'face_pull',n:'케이블 페이스풀',en:'cable face pull proper form',m:'어깨',pattern:'shoulderiso',gear:'cable',level:1,kind:'isolation',tips:'줄을 얼굴 높이로 당기며 팔꿈치를 바깥으로 이동하세요. 통증이 없는 가벼운 중량으로 수행하세요.'},
 {id:'triceps_push',n:'케이블 트라이셉스 푸시다운',en:'triceps rope pushdown proper form',m:'삼두',pattern:'triceps',gear:'cable',level:0,kind:'isolation',tips:'팔꿈치를 몸통 옆에 고정한 뒤 아래로 밀어 펴세요. 어깨나 몸통을 흔들지 마세요.'},
 {id:'triceps_db',n:'덤벨 킥백',en:'dumbbell triceps kickback form',m:'삼두',pattern:'triceps',gear:'dumbbell',level:0,kind:'isolation',tips:'팔꿈치를 고정한 상태에서 팔을 뒤로 펴세요. 몸을 흔들지 마세요.'},
 {id:'biceps_curl',n:'덤벨 컬',en:'dumbbell biceps curl proper form',m:'이두',pattern:'biceps',gear:'dumbbell',level:0,kind:'isolation',tips:'팔꿈치를 몸통 옆에 두고 손을 들어 올린 뒤 천천히 내리세요. 반동은 최소화하세요.'},
 {id:'cable_curl',n:'케이블 컬',en:'cable biceps curl proper form',m:'이두',pattern:'biceps',gear:'cable',level:0,kind:'isolation',tips:'팔꿈치 위치를 유지하며 손잡이를 위로 당기고 천천히 내리세요.'},
 {id:'calf_raise',n:'스탠딩 카프레이즈',en:'standing calf raise tutorial',m:'종아리',pattern:'calves',gear:'body',level:0,kind:'isolation',tips:'발끝으로 천천히 올라갔다 내려오세요. 균형이 흔들리면 벽을 잡으세요.'},
 {id:'plank',n:'플랭크',en:'plank exercise proper form',m:'복부',pattern:'core',gear:'body',level:0,kind:'core',tips:'팔꿈치와 발끝으로 지탱하고 몸통을 일직선으로 유지하세요. 허리를 처지게 두지 마세요. 반복 횟수 대신 초를 입력해도 됩니다.'},
 {id:'dead_bug',n:'데드버그',en:'dead bug exercise form',m:'복부',pattern:'core',gear:'body',level:0,kind:'core',tips:'누운 상태에서 복부에 힘을 준 채 반대쪽 팔과 다리를 천천히 펴세요. 허리가 뜨지 않도록 하세요.'},
 {id:'walking',n:'트레드밀 걷기',en:'treadmill walking warm up posture',m:'유산소',pattern:'cardio',gear:'machine',level:0,kind:'cardio',tips:'편안한 속도에서 시작하고 숨이 과도하게 차지 않는 정도로 걷습니다.'}
];
const STRETCH={
 march:{n:'제자리 걷기·가벼운 유산소',s:120,en:'marching in place warmup',tips:'숨이 조금 빨라지는 정도로 가볍게 움직이세요.'},
 arm:{n:'팔 돌리기·어깨 관절 가동',s:60,en:'arm circles dynamic warmup',tips:'작은 원에서 큰 원으로 천천히 양쪽 어깨를 움직이세요.'},
 scap:{n:'견갑 움직임 준비운동',s:60,en:'scapular retraction dynamic warm up',tips:'어깨를 편안하게 내리고 어깨뼈를 모았다 풀어주세요.'},
 hip:{n:'고관절 원 그리기',s:60,en:'hip circles dynamic warmup',tips:'허리를 과도하게 꺾지 않고 엉덩이 관절을 부드럽게 움직이세요.'},
 ankle:{n:'발목 가동성 운동',s:60,en:'ankle mobility warmup',tips:'발목을 통증 없이 앞뒤로 부드럽게 움직이세요.'},
 squats:{n:'가벼운 맨몸 스쿼트',s:60,en:'bodyweight squat warmup',tips:'얕고 편안한 범위에서 천천히 앉았다 일어나세요.'},
 leg:{n:'다리 앞뒤 스윙',s:60,en:'leg swings dynamic stretch',tips:'벽을 짚고 반동을 과하게 주지 않으면서 움직이세요.'},
 band:{n:'가벼운 등·팔 당기기',s:60,en:'band pull apart warmup',tips:'가벼운 저항으로 견갑을 모으고 팔을 움직여주세요.'},
 cool_walk:{n:'천천히 걷고 호흡 정리',s:90,en:'cool down slow walking breathing',tips:'강도를 천천히 낮추며 호흡을 정돈하세요.'},
 chest:{n:'가슴 앞쪽 스트레칭',s:45,en:'doorway chest stretch',tips:'통증 없이 편안한 정도로 가슴 앞쪽을 늘려주세요.'},
 lats:{n:'광배근 스트레칭',s:45,en:'latissimus dorsi stretch',tips:'팔을 앞으로 길게 뻗고 등을 부드럽게 늘려주세요.'},
 quad:{n:'허벅지 앞쪽 스트레칭',s:45,en:'standing quadriceps stretch',tips:'벽을 잡고 발목을 가볍게 잡아 허벅지 앞쪽을 늘리세요.'},
 ham:{n:'허벅지 뒤쪽 스트레칭',s:45,en:'hamstring standing stretch',tips:'무릎을 잠그지 않고 불편하지 않을 정도만 움직이세요.'},
 calf:{n:'종아리 스트레칭',s:45,en:'calf stretch wall',tips:'벽을 짚고 뒤꿈치를 바닥에 둔 채 종아리를 부드럽게 늘려주세요.'},
 shoulder:{n:'어깨 뒤쪽 스트레칭',s:45,en:'cross body shoulder stretch',tips:'팔을 가슴 앞으로 가져와 가볍게 당기세요.'},
 glutes:{n:'둔근 스트레칭',s:45,en:'figure four glute stretch',tips:'편안한 자세에서 엉덩이 근육을 부드럽게 늘리세요.'},
 breathing:{n:'복식 호흡 정리',s:45,en:'diaphragmatic breathing cool down',tips:'숨을 천천히 들이쉬고 내쉬며 호흡을 정리하세요.'}
};
const PATTERN={squat:'하체',push:'가슴',chestiso:'가슴',pullvertical:'등',pullhorizontal:'등',hinge:'뒤허벅지',glutes:'둔근',verticalpush:'어깨',shoulderiso:'어깨',triceps:'삼두',biceps:'이두',calves:'종아리',core:'복부',cardio:'유산소'};
const GROUPS=['가슴','등','어깨','하체','뒤허벅지','둔근','이두','삼두','복부','종아리'];
const KEY='fitplan_autocoach_01';
const APP_VERSION='1.9.8';
const PROGRAM_DAY=86400000;
const UPDATE_CONFIG={manifest:'fitplan/latest.json',defaultRepo:'ffast112-ff/cam112'};
const TODAY=()=>new Date().toISOString().slice(0,10);
const DEFAULT_PROFILE={sex:'unspecified',goal:'hypertrophy',physique:'balanced',focus:['등'],level:0,days:3,duration:60,place:'gym',height:175,weight:75,restrictions:[]};
const DEFAULT={schema:19,calibrations:{},calibrationActive:null,planMemory:null,profile:{...DEFAULT_PROFILE},settings:{alert:'both',preAlert:true,keepAwake:true,voice:'on',voiceRate:1,programWeeks:8,githubRepo:'ffast112-ff/cam112'},cycle:null,cycleReports:[],machines:{},onboard:false,history:[],sessionIndex:0,active:null,player:null,created:Date.now()};
const PATTERN_NAME={squat:'무릎 중심 하체',hinge:'뒤허벅지',glutes:'둔근',push:'가슴 밀기',chestiso:'가슴',pullvertical:'수직 당기기',pullhorizontal:'수평 당기기',verticalpush:'어깨 밀기',shoulderiso:'어깨',triceps:'삼두',biceps:'이두',calves:'종아리',core:'복부',cardio:'유산소'};
const PRIMARY=['가슴','등','어깨','하체','뒤허벅지','둔근','이두','삼두','복부','종아리'];
const SIMPLE=['leg_press','chest_press','lat_pulldown','seated_row','rld_machine','shoulder_press','goblet_squat','body_squat','pushup','db_row','db_press','db_shoulder','glute_bridge','plank','dead_bug','walking','biceps_curl','triceps_push','lateral_raise','calf_raise','db_rdl','band_row','cable_curl'];
const SIMPLE_ORDER=new Map(SIMPLE.map((id,i)=>[id,i]));
const repGuide={hypertrophy:[8,12],fatloss:[10,15],fitness:[10,15],strength:[5,8]};
const levels=['완전 초보','초급','중급','고급'];
function deep(x){return JSON.parse(JSON.stringify(x));}
function num(v,def=0){const n=Number(v);return Number.isFinite(n)?n:def;}
function clamp(n,a,b){return Math.max(a,Math.min(b,n));}
function roundTo(n,u=2.5){return Math.max(0,Math.round(n/u)*u);}
function esc(x){return String(x==null?'':x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function exercise(id){return CATALOG.find(e=>e.id===id);}
function workoutSets(it){return (it.sets||[]).filter(s=>!s.warmup);}
function legacyHistory(h){return (h||[]).map(s=>{
 if(s&&(Number(s.schema)>=10||(s.items||[]).some(it=>(it.sets||[]).some(z=>'targetWeight' in z))))return s;
 return {...s,schema:10,items:(s.items||[]).map(it=>({eid:it.eid||it.currentId,currentId:it.currentId||it.eid,pattern:exercise(it.eid||it.currentId)?.pattern||'',sets:(it.sets||[]).map(v=>({warmup:false,done:!!v.done,targetWeight:num(v.weight),targetReps:num(v.reps),actualWeight:num(v.weight),actualReps:num(v.reps),actualId:v.actualId||it.currentId||it.eid,rir:null}))})),feedback:{difficulty:num(s.difficulty,6),weight:num(s.bodyweight),pain:!!s.pain}};
 });}
function load(){try{const a=JSON.parse(localStorage.getItem(KEY)||'null');if(a&&a.profile){
 const p={...DEFAULT_PROFILE,...a.profile,focus:Array.isArray(a.profile.focus)?a.profile.focus:['등'],restrictions:Array.isArray(a.profile.restrictions)?a.profile.restrictions:[]};
 if(a.schema>=10){return {...DEFAULT,...a,schema:19,calibrations:a.calibrations||{},calibrationActive:a.calibrationActive||null,planMemory:a.planMemory||null,profile:p,machines:a.machines||{},settings:{...DEFAULT.settings,...a.settings},history:legacyHistory(a.history)}};
 return {...deep(DEFAULT),profile:p,onboard:!!a.onboard,history:legacyHistory(a.history),sessionIndex:num(a.sessionIndex),oldBackup:a,machines:a.machines||{},settings:{...DEFAULT.settings,...(a.settings||{})}};
 }}catch(e){console.warn('storage',e)}return deep(DEFAULT);}
let state=load();if(!state.settings.githubRepo)state.settings.githubRepo=UPDATE_CONFIG.defaultRepo;let view=state.calibrationActive&&state.active?'calibration':state.player&&state.active?'player':state.onboard?'home':'setup';
refreshCycle();save();
let setupPage=0,modal=null,chartKey='weight',todayMinutes=state.profile.duration,replanRemaining=30,cameraStatus='',cameraPreview='';
let readiness={energy:3,soreness:2,sleep:3,pain:false},feedback={weight:state.profile.weight,difficulty:5,pain:false,soreness:2,note:''},toastId=0,audioCtx=null,wakeHandle=null,lastPlayerCue="",lastCalibrationCue="";
function save(){try{localStorage.setItem(KEY,JSON.stringify(state));}catch(e){console.warn('Cannot save',e)}}
// A program cycle is counted in calendar weeks from the first saved session;
// records continue permanently across periods. Only verified completed sets count.
function cycleWeeks(){return clamp(num(state.settings.programWeeks,8),4,12);}
function sessionTime(s){return num(s.finishedAt||s.timestamp,Date.parse(s.date)||0);}
function cycleStart(){const first=(state.history||[]).map(sessionTime).filter(t=>t>0).sort((a,b)=>a-b)[0];return first||Date.now();}
function sessionStrengths(s){const byId={};for(const it of s.items||[])for(const set of it.sets||[]){
 if(!set.done||set.warmup||set.role==='warmup')continue;
 const id=it.currentId||it.eid||it.id,kg=num(set.actualWeight),reps=num(set.actualReps);
 if(!id||kg<=0||reps<=0||reps>30)continue;
 // Representative estimated strength used only for within-exercise trend, not a 1RM prescription.
 const score=kg*(1+Math.min(15,reps)/30);
 byId[id]=Math.max(byId[id]||0,score);
 }return byId;}
function cycleSummary(c,start,end){const workouts=state.history.filter(s=>sessionTime(s)>=start&&sessionTime(s)<end);
 const halves=[{},{}],halfAt=start+(end-start)/2;let pain=0,hard=0,sets=0;
 for(const s of workouts){if(s.feedback?.pain)pain++;if(num(s.feedback?.difficulty)>=9)hard++;
  const ix=sessionTime(s)<halfAt?0:1,values=sessionStrengths(s);
  for(const id in values)halves[ix][id]=Math.max(halves[ix][id]||0,values[id]);
  for(const it of s.items||[])sets+=(it.sets||[]).filter(x=>x.done&&!x.warmup&&x.role!=='warmup').length;
 }
 let improving=0,declining=0,stable=0;
 for(const id in halves[0])if(halves[1][id]){const diff=halves[1][id]/halves[0][id]-1;
  if(diff>=.025)improving++;else if(diff<=-.025)declining++;else stable++;
 }
 const target=Math.max(1,cycleWeeks()*clamp(num(state.profile.days,3),1,7));
 const adherence=workouts.length/target;
 const cause=pain>0||hard>=Math.max(2,Math.ceil(workouts.length*.4))?'recovery':
  improving>0?'progress':
  workouts.length<Math.max(2,Math.floor(target*.5))?'attendance':
  stable+declining>=2?'plateau':'insufficient';
 const suggestion={recovery:'최근 통증이나 높은 피로 기록이 있어 다음 주기는 회복을 우선합니다.',progress:'중량 수행 지표가 개선되어 기존 분할을 우선 유지하고 점진적으로 조절합니다.',attendance:'운동 빈도가 목표보다 낮아 다음 주기는 실천 가능한 일정부터 유지합니다.',plateau:'여러 종목의 정체가 보여 분할 및 운동량 재평가를 허용합니다.',insufficient:'비교 가능한 기록이 부족하므로 기존 루틴을 유지하며 자료를 더 모읍니다.'}[cause];
 return {number:c.number,start,end,workouts:workouts.length,target,adherence:+adherence.toFixed(2),completedSets:sets,pain,hard,improving,declining,stable,cause,suggestion,generatedAt:Date.now()};
}
function refreshCycle(){if(!state.onboard)return false;
 const weeks=cycleWeeks(),span=weeks*7*PROGRAM_DAY;
 if(!state.cycle||!Number.isFinite(num(state.cycle.start))||state.cycle.weeks!==weeks){
  const start=cycleStart(),elapsed=Math.max(0,Math.floor((Date.now()-start)/span)),n=elapsed+1;
  state.cycle={number:n,start:start+elapsed*span,weeks};return true;
 }
 let changed=false,limit=0;
 while(Date.now()>=state.cycle.start+span&&limit++<200){
  const old=state.cycle,report=cycleSummary(old,old.start,old.start+span);
  if(!(state.cycleReports||[]).some(r=>r.number===old.number&&r.start===old.start)){
   state.cycleReports.push(report);state.cycleReports=state.cycleReports.slice(-30);
  }
  state.cycle={number:old.number+1,start:old.start+span,weeks};
  // Persist a recommendation, but never overwrite the user's exercise history or force a split change.
  state.lastCycleReview=report;
  if(report.cause==='plateau'&&!state.active)state.planMemory=null;
  changed=true;
 }
 return changed;
}
function cycleWidget(){if(!state.onboard)return'';const c=state.cycle;if(!c)return'';
 const week=clamp(Math.floor((Date.now()-c.start)/(7*PROGRAM_DAY))+1,1,c.weeks),last=state.lastCycleReview;
 return `<div class="card"><div class="eyebrow">자동 장기 운동 주기</div><div class="row"><strong>${c.number}차 프로그램 · ${week}/${c.weeks}주차</strong><span class="pill">${c.weeks}주 순환</span></div>
 
 ${last?`<div class="subhead"><strong>지난 ${last.number}차 프로그램 평가</strong><p class="sub">운동 ${last.workouts}/${last.target}회 · 수행 지표 개선 ${last.improving}종목 · 통증 기록 ${last.pain}회</p><p class="sub">${esc(last.suggestion)}</p></div>`:''}
 <button class="btn secondary full mt8" onclick="Fit.programPreview()">현재 주기 전체 보기</button></div>`;
}
function repoParts(input){const v=String(input||'').trim().replace(/^https:\/\/github\.com\//i,'').replace(/\/$/,'');
 return /^[a-zA-Z0-9_.-]+\/[a-zA-Z0-9_.-]+$/.test(v)?v:null;}
function versionParts(v){if(!/^v?\d+\.\d+\.\d+(?:[-+][\w.-]+)?$/.test(String(v||'')))return null;
 return String(v).replace(/^v/,'').split(/[.+-]/).slice(0,3).map(Number);}
function newerVersion(remote,current){const a=versionParts(remote),b=versionParts(current);if(!a||!b)return false;
 for(let i=0;i<3;i++){if(a[i]!==b[i])return a[i]>b[i];}return false;}
function validReleaseUrl(u,repo){try{const p=new URL(u);return p.protocol==='https:'&&p.hostname==='github.com'&&
 p.pathname.startsWith('/'+repo+'/releases/')&&!p.username&&!p.password;}catch(e){return false;}}
let updateCheckInProgress=false,updateCheckedThisLaunch=false,updateStatus='GitHub 버전 확인 대기 중';
async function checkForUpdates(userInitiated=false){
 if(updateCheckInProgress||(!userInitiated&&updateCheckedThisLaunch))return;
 updateCheckedThisLaunch=true;const repo=repoParts(state.settings.githubRepo||UPDATE_CONFIG.defaultRepo);
 if(!repo){updateStatus='GitHub 저장소를 설정하면 시작 시 자동 확인합니다.';if(userInitiated)toast(updateStatus);return;}
 updateCheckInProgress=true;updateStatus='GitHub 최신 버전 확인 중';if(userInitiated)render();
 try{
  const control=new AbortController(),timeout=setTimeout(()=>control.abort(),8000);
  let response;
  try{response=await fetch(`https://raw.githubusercontent.com/${repo}/main/${UPDATE_CONFIG.manifest}?t=${Date.now()}`,{cache:'no-store',signal:control.signal});}finally{clearTimeout(timeout);}
  if(!response.ok)throw Error('HTTP '+response.status);
  const info=await response.json(),latest=String(info.version||'');
  if(!versionParts(latest)||!validReleaseUrl(info.apk_url,repo))throw Error('버전 또는 다운로드 주소 형식이 올바르지 않음');
  if(newerVersion(latest,APP_VERSION)){
   // If canceled this launch, don't show again unless manually requested.
   modal={type:'update',version:latest,url:info.apk_url,notes:String(info.notes||'').slice(0,500)};
   updateStatus=`새 버전 ${latest} 발견`;
  }else updateStatus=`최신 버전입니다 (${APP_VERSION})`;
 }catch(err){updateStatus='확인 실패 · 인터넷 연결과 저장소 latest.json을 확인하세요';console.warn('update check',err);}
 finally{updateCheckInProgress=false;render();if(userInitiated&&!modal)toast(updateStatus);}
}
function setGithubRepo(v){const repo=repoParts(v);if(v&& !repo){toast('owner/repository 형태로 입력하세요');return;}
 state.settings.githubRepo=repo||'';updateCheckedThisLaunch=false;save();render();toast(repo?'저장됐습니다. 버전 확인을 실행할 수 있습니다.':'GitHub 주소가 삭제됐습니다.');}
function openUpdate(){const u=modal?.url;if(!u)return;modal=null;render();
 // Only trusted GitHub release URLs are accepted. Use the OS browser/download UI where supported.
 const link=document.createElement('a');link.href=u;link.target='_blank';link.rel='noopener noreferrer';document.body.appendChild(link);link.click();link.remove();
 toast('브라우저에서 APK를 받은 뒤 설치 승인이 필요합니다.');
}
function toast(message){const box=document.getElementById('toast');if(!box)return;box.textContent=message;box.classList.add('show');clearTimeout(toastId);toastId=setTimeout(()=>box.classList.remove('show'),2600);}
function currentWeight(){const a=state.history.filter(s=>s.feedback?.weight>0);return a.length?a[a.length-1].feedback.weight:state.profile.weight;}
function matchFocus(m){const f=state.profile.focus||[];return f.includes(m)||(f.includes('팔')&&['이두','삼두'].includes(m))||(f.includes('하체')&&['하체','뒤허벅지','둔근','종아리'].includes(m));}
function splitProgram(){
 if(window.FitPlanPrecisionV4){const best=FitPlanPrecisionV4.selectSplit(state.profile,CATALOG,state.history,readiness,[],{planMemory:state.planMemory});
   return {type:{full:1,upperlower:2,ppl:3,four:4}[best.split.id],label:best.split.name,days:best.split.days.map(x=>[x.name,x.patterns]),reason:`4가지 분할의 상세 종목·세트·순서를 함께 비교합니다. 현재 평가 ${Number(best.score).toFixed(1)}점 · ${best.reason||''}`};}
 const d=num(state.profile.days,3),lvl=num(state.profile.level,0),goal=state.profile.goal;
 if(d<=2)return {type:1,label:'1분할 · 전신 A/B',days:[['전신 A',['squat','push','pullvertical','hinge','core','verticalpush']],['전신 B',['hinge','pullhorizontal','push','squat','shoulderiso','core']]],reason:'주 2회에서는 전신을 반복하는 편이 각 근육에 고르게 훈련 기회를 제공합니다.'};
 if(d===3 && lvl<=1)return {type:1,label:'1분할 · 전신 A/B/C',days:[['전신 A',['squat','push','pullvertical','hinge','core','verticalpush']],['전신 B',['pullhorizontal','push','squat','shoulderiso','glutes','core']],['전신 C',['hinge','pullvertical','push','squat','biceps','core']]],reason:'처음에는 주 3회 전신을 반복해 운동을 익히고 회복을 확인합니다.'};
 if(d===3 && lvl>=2)return {type:3,label:'3분할 · 푸시/풀/하체',days:[['푸시',['push','verticalpush','chestiso','shoulderiso','triceps']],['풀',['pullvertical','pullhorizontal','biceps','shoulderiso','core']],['하체',['squat','hinge','glutes','calves','core']]],reason:'훈련 경험을 고려한 3분할입니다. 각 부위의 빈도와 장기 수행 결과를 감시합니다.'};
 if(d===4||lvl<=1)return {type:2,label:'2분할 · 상체/하체 A/B',days:[['상체 A',['push','pullvertical','pullhorizontal','verticalpush','biceps','triceps']],['하체 A',['squat','hinge','glutes','calves','core']],['상체 B',['pullhorizontal','push','verticalpush','pullvertical','shoulderiso','triceps']],['하체 B',['hinge','squat','glutes','core','calves']]],reason:'주 4회 이상은 상·하체를 번갈아 훈련해 빈도와 회복을 균형 있게 배분합니다.'};
 if(d===5&&lvl===2)return {type:3,label:'3분할 · PPL + 상/하체 보완',days:[['푸시',['push','verticalpush','chestiso','triceps']],['풀',['pullvertical','pullhorizontal','biceps','shoulderiso']],['하체',['squat','hinge','glutes','calves','core']],['상체 보완',['pullhorizontal','push','verticalpush','biceps','triceps']],['하체 보완',['hinge','squat','glutes','core']]],reason:'5일간 근육별 운동량을 분산하고 상·하체 보완일을 확보합니다.'};
 if(d>=5&&lvl>=3)return {type:4,label:'4분할 · 가슴/등/하체/어깨·팔',days:[['가슴·삼두',['push','chestiso','triceps','shoulderiso']],['등·이두',['pullvertical','pullhorizontal','biceps','core']],['하체',['squat','hinge','glutes','calves']],['어깨·팔',['verticalpush','shoulderiso','biceps','triceps','core']],['전신 보완',['squat','push','pullhorizontal','hinge','core']]],reason:'고급자의 다양한 훈련량을 나눠 관리합니다. 부족한 부위는 보완일에 배정합니다.'};
 return {type:3,label:'3분할 · 푸시/풀/하체',days:[['푸시 A',['push','verticalpush','chestiso','triceps']],['풀 A',['pullvertical','pullhorizontal','biceps','core']],['하체 A',['squat','hinge','glutes','calves']],['푸시 B',['push','verticalpush','shoulderiso','triceps']],['풀 B',['pullhorizontal','pullvertical','biceps','core']],['하체 B',['hinge','squat','glutes','calves']]],reason:'반복 훈련과 회복을 고려한 순환형 3분할입니다.'};}
function isAllowed(e){if(!e||!SIMPLE_ORDER.has(e.id))return false;const p=state.profile;if(p.place==='home'&&!['body','dumbbell','band'].includes(e.gear))return false;
 if(e.level>Math.max(0,num(p.level))+1)return false;
 if(p.restrictions?.includes('어깨')&&['push','verticalpush','shoulderiso','chestiso'].includes(e.pattern))return false;
 if(p.restrictions?.includes('무릎')&&e.pattern==='squat')return false;
 if(p.restrictions?.includes('허리')&&['hinge'].includes(e.pattern))return false;
 if(p.restrictions?.includes('손목')&&['push','biceps','triceps'].includes(e.pattern))return false;
 if(p.restrictions?.includes('발목')&&['calves','squat'].includes(e.pattern))return false;
 return true;}
function historyFor(id){return state.history.slice(-20).map(s=>({session:s,sets:(s.items||[]).flatMap(it=>workoutSets(it).filter(x=>x.done&&(x.actualId||it.currentId||it.eid)===id))})).filter(v=>v.sets.length);}
function trainingBalance(){const out={};PRIMARY.forEach(g=>out[g]={sets:0,success:0,attempts:0});state.history.slice(-10).forEach(s=>(s.items||[]).forEach(it=>workoutSets(it).forEach(z=>{if(!z.done)return;const e=exercise(z.actualId||it.currentId||it.eid);if(!e||!out[e.m])return;out[e.m].sets++;out[e.m].attempts++;if(num(z.actualReps)>=num(z.targetReps))out[e.m].success++;})));return out;}
function weaknessScores(){const b=trainingBalance();const avg=PRIMARY.reduce((sum,k)=>sum+b[k].sets,0)/PRIMARY.length;const result={};PRIMARY.forEach(k=>{const z=b[k];let f=matchFocus(k)?2.4:0;f+=clamp((avg-z.sets)*.45,-1.2,1.5);if(z.attempts>=4&&z.success/z.attempts<.6)f-=1.6;result[k]=f;});return result;}
function isTimed(e){return e?.pattern==='core'||e?.pattern==='cardio';}
function loadUnit(e){return e.gear==='dumbbell'?1:(e.gear==='machine'||e.gear==='cable')?2.5:2.5;}
function startWeight(e){if(!e||['body','band'].includes(e.gear)||isTimed(e))return 0;
 const bw=clamp(num(currentWeight(),70),35,140),lvl=clamp(num(state.profile.level),0,3);
 const factor={leg_press:.28,chest_press:.17,lat_pulldown:.18,seated_row:.18,rld_machine:.13,shoulder_press:.085,db_press:.045,db_row:.055,db_shoulder:.037,goblet_squat:.07,biceps_curl:.027,lateral_raise:.012,db_rdl:.09,triceps_push:.08,cable_curl:.08};
 const scale=[.5,.65,.83,1][lvl];let v=bw*(factor[e.id]||.08)*scale;
 return Math.max(loadUnit(e),roundTo(v,loadUnit(e)));
}
function suggestedLoad(e,rdy){
 const a=FitPlanAdvanced.machineDecision(state,e,rdy).analysis;
 return {weight:a.weight===null?0:a.weight,reason:a.reason,first:a.action==='calibrate',
   repsBoost:a.action==='add-reps',confidence:a.confidence};
}
function restTime(e,goal,readiness){let base=goal==='strength'&&e.kind==='compound'?150:e.kind==='compound'?95:65;if(readiness.energy<=2||readiness.soreness>=4)base+=20;return base;}
function targetRange(e){if(isTimed(e))return e.pattern==='cardio'?[120,300]:[20,45];if(e.kind==='isolation')return [10,15];return repGuide[state.profile.goal]||[8,12];}
function buildSetPlan(e,count,info,rdy){const [lo,hi]=targetRange(e),lvl=clamp(num(state.profile.level),0,3),sec=isTimed(e),unit=loadUnit(e);
 const sets=[];
 if(!sec&&e.kind==='compound'&&info.weight>0){sets.push({warmup:true,done:false,targetWeight:roundTo(info.weight*.5,unit),targetReps:clamp(lo,6,10),actualWeight:roundTo(info.weight*.5,unit),actualReps:clamp(lo,6,10),rir:null,actualId:e.id});}
 for(let i=0;i<count;i++){
  let w=info.weight,reps=Math.round((lo+hi)/2),label='기본 세트';
  if(sec){w=0;reps=e.pattern==='core'?clamp(25+5*i,20,45):clamp(120+30*i,120,300);label='시간 세트';}
  else if(lvl===2&&count>=3&&info.weight>0){const ramp=[.95,1,1.025,1,1];w=roundTo(info.weight*ramp[Math.min(i,4)],unit);reps=clamp(hi-i*2,lo,hi);label=i===2?'점진 증가':i===0?'적응 본세트':'본세트';}
  else if(lvl>=3&&count>=3&&info.weight>0){const ramp=[.94,1.04,.92,.92,.92];w=roundTo(info.weight*ramp[Math.min(i,4)],unit);reps=i===1?lo:i>=2?hi-1:hi;label=i===1?'탑 세트':i>=2?'백오프':'진입 세트';}
  if(info.repsBoost&&!sec)reps=Math.min(hi+2,reps+1);
  sets.push({warmup:false,done:false,targetWeight:w,targetReps:reps,actualWeight:w,actualReps:reps,rir:null,actualId:e.id,label});
 }
 return sets;}
function estimatedItemTime(it){const e=exercise(it.currentId||it.eid);const main=it.sets.length;const rest=Math.max(0,main-1)*num(it.rest,75);return (main*(isTimed(e)?40:48)+rest+70)/60;}
function makeStretch(patterns,budget,kind){const hasU=patterns.some(x=>['push','pullvertical','pullhorizontal','verticalpush','shoulderiso','chestiso'].includes(x));const hasL=patterns.some(x=>['squat','hinge','glutes','calves'].includes(x));
 const ids=kind==='pre'?['march',...(hasL?['hip','ankle','squats']:[]),...(hasU?['arm','scap']:[]),'leg']:['cool_walk',...(hasU?['chest','lats','shoulder']:[]),...(hasL?['quad','ham','calf']:[]),'breathing'];
 const limit=budget*60,list=[];let used=0;for(const id of ids){const s=STRETCH[id];if(!s)continue;const sec=kind==='pre'&&id==='march'?Math.min(100,limit):s.s;if(used+sec<=limit){list.push({id,n:s.n,secs:sec,done:false});used+=sec;}}
 if(!list.length){const id=kind==='pre'?'march':'breathing';list.push({id,n:STRETCH[id].n,secs:limit,done:false});}
 const left=limit-list.reduce((n,z)=>n+z.secs,0);if(left>0)list[0].secs+=left;return list;}
function generatePlan(minutes,rdy){
 minutes=clamp(Math.round(num(minutes,60)),30,120);
 const result=FitPlanPrecisionV4.planDay({profile:state.profile,readiness:rdy,catalog:CATALOG,
   history:state.history,sessionIndex:state.sessionIndex,minutes,context:{planMemory:state.planMemory,pace:FitPlanAdvanced.pace(state.history).factor}});
 const pace=FitPlanAdvanced.pace(state.history),deload=FitPlanAdvanced.excessiveFatigue(state.history);
 const items=result.items.map(it=>{
   const e=exercise(it.id);
   const machine=e&&!isTimed(e)&&!['body','band'].includes(e.gear)?FitPlanAdvanced.machineDecision(state,e,rdy):null;
   const load=machine?.analysis;
   const unit=machine?.varnt?.increment||2.5;
   const sets=it.sets.map((z,i)=>{
     const calibrated=state.calibrations?.[FitPlanPrecisionV5.calKey(it.id,machine?.machineId||'default')];
     const initial=z.targetWeight===null?0:z.targetWeight;
     const knownLoad=load?.weight!==null&&load?.weight!==undefined?load.weight:(calibrated?.status==='ready'?calibrated.weight:null);
     const adjusted=load?(knownLoad===null?0:Math.max(unit,roundTo(knownLoad*(z.role==='warmup'?.5:z.role==='backoff'?.9:1),unit))):initial;
     return ({
     warmup:!!z.warmup,role:z.role,done:false,machineId:machine?.machineId||'default',
     targetWeight:adjusted,targetReps:z.targetReps,
     actualWeight:adjusted,actualReps:z.targetReps,
     rir:null,actualId:it.id,restSec:z.restSec,
     label:z.role==='backoff'?'백오프':z.warmup?'준비 세트':'본세트',
     requiresCalibration:!!machine&&load.weight===null&&!calibrated?.weight&&!isTimed(e)
   });});
   return {eid:it.id,currentId:it.id,machineId:machine?.machineId||'default',durationSec:0,pattern:it.pattern,muscle:it.muscle,
     reason:it.reason,rest:it.sets.find(z=>!z.warmup)?.restSec||90,
     confidence:it.loadDecision.confidence,sets};
 });
 // Safety gate runs independently of the optimization score. A fresh device requires calibration.
 for(const it of items){const ex=exercise(it.currentId);if(ex&&!isTimed(ex)){const safety=FitPlanPrecisionV5.guardPrescription(it,ex,state,it.machineId);it.safetyNotes=safety.issues;}}
 // Preserve a minimum of one working set; do not add volume when tired.
 if(deload.active)for(const it of items){const work=it.sets.filter(z=>!z.warmup);if(work.length>=3){const idx=it.sets.lastIndexOf(work[work.length-1]);it.sets.splice(idx,1);}}
 // Learn time efficiency from actual session duration without claiming physiological efficiency.
 const estimated=Math.ceil(result.estimatedMinutes*pace.factor);
 if(pace.samples>=3&&estimated>minutes){
  let excess=estimated-minutes;
  for(let pass=0;pass<3&&excess>0;pass++)for(let i=items.length-1;i>=0&&excess>0;i--){
    const it=items[i],work=it.sets.filter(z=>!z.warmup);
    if(work.length<=2)continue;
    const idx=it.sets.lastIndexOf(work[work.length-1]);it.sets.splice(idx,1);excess-=2;
  }
 }
 const stretches=(source)=>source.map(z=>({id:z.id,n:STRETCH[z.id]?.n||z.name,secs:z.seconds,done:false}));
 const cardioMin=FitPlan15.cardioDose(state.profile,minutes,estimated,rdy);
 const cardio=cardioMin>=3?[{id:'walking',n:'트레드밀 가볍게 걷기',secs:cardioMin*60,done:false,intensity:'대화 가능한 강도',mode:'low'}]:[];
 return {schema:46,engineVersion:result.version||'4.0',optimizer:result.optimizer,splitId:result.split,id:Date.now(),date:TODAY(),
   splitName:result.dayName,splitType:{full:1,upperlower:2,ppl:3,four:4}[result.split],
   program:result.splitLabel,programWhy:result.explanation,
   timeLimit:minutes,predictedMinutes:result.estimatedMinutes+cardioMin,adjustedPredictedMinutes:estimated+cardioMin,readiness:{...rdy},
   pre:stretches(result.stretch.pre),items,cardio,post:stretches(result.stretch.post),changes:[],
   weeklyTarget:result.weeklyTarget,weeklyDone:result.weeklyDone,weeklyQuota:result.weeklyQuota,plannedWorkingCredits:FitPlanPrecisionV4.workingMuscleCredits(items),
   concerns:result.concerns,splitCandidates:result.splitCandidates.map(x=>({id:x.id,label:x.label,score:x.score})),
   paceFactor:pace.factor,paceSamples:pace.samples,deload:deload.active,
   deloadReason:deload.reason,
   startAt:Date.now()};
}
function doneCount(s){if(!s)return [0,0];const all=[...(s.pre||[]),...s.items.flatMap(x=>x.sets),...(s.cardio||[]),...(s.post||[])];return [all.filter(x=>x.done).length,all.length];}
function shortDuration(sec){sec=Math.max(0,Math.floor(num(sec)));return String(Math.floor(sec/60)).padStart(2,'0')+':'+String(sec%60).padStart(2,'0');}
function mainCount(s){return s?.items?.reduce((v,it)=>v+workoutSets(it).filter(z=>z.done).length,0)||0;}
function formatWeight(v){return num(v)%1?String(num(v).toFixed(1)):String(num(v));}
function upperName(e){return esc(e?.n||'운동');}
function buttonSelect(items,selected,fn){return `<div class="choices">${items.map(([id,label,sub])=>`<button type="button" class="choice ${String(selected)===String(id)?'active':''}" onclick="Fit.${fn}('${id}')"><strong>${esc(label)}</strong>${sub?`<span class="sub">${esc(sub)}</span>`:''}</button>`).join('')}</div>`;}
function multiSelect(items,selected,fn){return `<div class="chips">${items.map(x=>`<button class="chip ${(selected||[]).includes(x)?'selected':''}" onclick="Fit.${fn}('${x}')">${(selected||[]).includes(x)?'✓ ':''}${esc(x)}</button>`).join('')}</div>`;}
function head(){return `<header class="fp-head"><div class="fp-mark"><span class="barbell-logo">━●━</span><div class="fp-title">Fit<span>Plan</span></div></div></header>`;}
function nav(){return `<nav class="tabbar"><button class="${view==='home'?'active':''}" onclick="Fit.go('home')">⌂<small>홈</small></button><button class="${view==='work'?'active':''}" onclick="Fit.go('work')">▣<small>운동</small></button><button class="${view==='state'?'active':''}" onclick="Fit.go('state')">▥<small>내 상태</small></button><button class="${view==='history'?'active':''}" onclick="Fit.go('history')">◷<small>기록</small></button><button class="${view==='settings'?'active':''}" onclick="Fit.go('settings')">⚙<small>설정</small></button></nav>`;}
function go(v){view=v;modal=null;render();window.scrollTo(0,0);}
function setupView(){const p=state.profile;let content='';
 if(setupPage===0){content=`<div class="eyebrow">STEP 1 · 나만의 운동 목표</div><h1>어떤 몸을<br>만들고 싶나요?</h1><p class="sub">운동을 몰라도 괜찮아요. 목표만 알려주면 모든 계획을 자동으로 구성합니다.</p>
 <div class="field"><label>가장 중요한 운동 목적</label>${buttonSelect([['hypertrophy','근육량 증가'],['strength','힘·근력 향상'],['fatloss','체지방 감량'],['fitness','건강·체력 향상']],p.goal,'goal')}</div>
 <div class="field"><label>원하는 체형</label>${buttonSelect([['balanced','균형 잡힌 몸'],['athletic','탄탄하고 근육질'],['slim','슬림한 몸'],['focus','특정 부위 강조']],p.physique,'physique')}</div>
 <div class="field"><label>집중하고 싶은 부위 · 복수 선택</label>${multiSelect(['가슴','등','어깨','팔','복부','하체'],p.focus,'focus')}</div><div class="hint">앱은 집중 부위를 우선하면서 다른 근육도 균형 있게 훈련합니다.</div>`;}
 else if(setupPage===1){content=`<div class="eyebrow">STEP 2 · 운동 가능한 조건</div><h1>운동 가능한<br>조건을 알려주세요</h1><div class="field"><label>현재 운동 경험</label>${buttonSelect([['0','완전 초보','처음 헬스장에 가요'],['1','초급','운동에 조금 익숙해요'],['2','중급','몇 달 이상 규칙적으로 했어요'],['3','고급','체계적인 중량·세트 관리 경험']],p.level,'level')}</div>
 <div class="grid2"><div class="field"><label>주당 운동 일수</label><select onchange="Fit.numProfile('days',this.value)">${[2,3,4,5,6].map(x=>`<option value="${x}" ${p.days===x?'selected':''}>주 ${x}일</option>`).join('')}</select></div>
 <div class="field"><label>1회 기본 시간</label><select onchange="Fit.numProfile('duration',this.value)">${[30,40,45,60,75,90,120].map(x=>`<option value="${x}" ${p.duration===x?'selected':''}>${x}분</option>`).join('')}</select></div></div>
 <div class="field"><label>운동 장소</label>${buttonSelect([['gym','헬스장'],['home','홈트레이닝']],p.place,'place')}</div><div class="hint">헬스장에서는 체스트프레스, 레그프레스, 랫풀다운 등 흔한 기구를 우선 추천합니다.</div>`;}
 else{content=`<div class="eyebrow">STEP 3 · 현재 신체 상태</div><h1>안전하게<br>시작해 볼까요?</h1><div class="grid2"><div class="field"><label>키 (cm)</label><input type="number" min="100" max="240" value="${p.height}" onchange="Fit.numProfile('height',this.value)"></div><div class="field"><label>몸무게 (kg)</label><input type="number" min="20" max="300" step="0.1" value="${p.weight}" onchange="Fit.numProfile('weight',this.value)"></div></div>
 <div class="field"><label>근력 통계 비교 기준 (선택)</label>${buttonSelect([['male','남성'],['female','여성'],['unspecified','통계 사용 안 함']],p.sex,'sex')}</div>
 <div class="field"><label>주의가 필요한 통증·관절 부위</label>${multiSelect(['어깨','허리','무릎','손목','발목','기타'],p.restrictions,'restriction')}</div>
 <div class="callout">현재 통증이나 부상이 있다면 무리한 동작을 피하고 필요한 경우 전문가의 지도를 받으세요. 키·체중만으로 근력을 알 수 없으므로 첫 중량은 시험 중량으로 안내합니다.</div>
 <div class="card"><div class="eyebrow">자동 추천 분할</div><h2>${esc(splitProgram().label)}</h2><p class="sub">주 ${p.days}일 · 기본 ${p.duration}분 · ${levels[clamp(num(p.level),0,3)]}</p></div>`;}
 return `${head()}<div class="progressrail"><div style="width:${(setupPage+1)/3*100}%"></div></div><section>${content}<div class="actions-row">${setupPage?'<button class="btn secondary" onclick="Fit.setupBack()">이전</button>':''}<button class="btn primary grow" onclick="${setupPage===2?'Fit.setupFinish()':'Fit.setupNext()'}">${setupPage===2?'FitPlan 시작하기':'다음 단계 →'}</button></div></section>`;}
function setupNext(){if(setupPage===0&&state.profile.focus.length===0){toast('집중 부위를 하나 이상 선택하세요');return;}setupPage=Math.min(2,setupPage+1);render();window.scrollTo(0,0);}
function setupBack(){setupPage=Math.max(0,setupPage-1);render();window.scrollTo(0,0);}
function setupFinish(){if(num(state.profile.height)<100||num(state.profile.weight)<20){toast('신체 정보를 확인하세요');return;}state.onboard=true;state.active=null;refreshCycle();todayMinutes=state.profile.duration;save();go('home');toast('맞춤 운동 프로그램 준비 완료');}
function changeProfile(k,v){state.profile[k]=v;save();render();}
function numProfile(k,v){let n=num(v);if(k==='height')n=clamp(n,100,240);if(k==='weight')n=clamp(n,20,300);state.profile[k]=n;if(k==='duration')todayMinutes=n;save();render();}
function toggleProfile(k,v){const a=state.profile[k]||[];state.profile[k]=a.includes(v)?a.filter(x=>x!==v):a.concat(v);save();render();}
function homeView(){const p=state.profile,program=splitProgram(),split=program.days[state.sessionIndex%program.days.length];const active=state.active;const hist=state.history;const last=hist[hist.length-1];
 return `${head()}<div class="eyebrow">오늘의 FitPlan</div><h1>${active?'진행 중인 운동':'오늘도 한 단계 더'}</h1><p class="sub">${esc(program.label)} · ${esc(split[0])} · 순환 루틴 ${state.sessionIndex+1}회차</p>
 <div class="grid3 mt16"><div class="stat"><div class="tiny muted">기본 시간</div><strong>${p.duration}분</strong></div><div class="stat"><div class="tiny muted">운동 수준</div><strong>${levels[clamp(num(p.level),0,3)]}</strong></div><div class="stat"><div class="tiny muted">운동 완료</div><strong>${hist.length}회</strong></div></div>
 ${active?`<div class="card hero"><div class="eyebrow">진행 중인 루틴</div><h2>${esc(active.splitName)}</h2><p class="sub">${doneCount(active).join(' / ')}개 진행 · ${active.items.length}개 운동 종목 · 목표 ${active.timeLimit}분</p><button class="btn primary full" onclick="Fit.go('work')">운동 이어하기 →</button></div>`:
 `<div class="card hero"><div class="eyebrow">자동 추천 루틴</div><h2>${esc(split[0])}</h2><button class="btn primary full" onclick="Fit.go('ready')">운동 계획 생성하기 →</button></div>`}
 ${cycleWidget()}
 
 ${last?`<div class="sectionhead"><h2>최근 운동 결과</h2></div><div class="card"><div class="row"><strong>${esc(last.splitName)}</strong><span class="pill">${last.durationMin}분</span></div><p class="sub mt8">체감 난이도 ${last.feedback?.difficulty||last.difficulty||'-'}/10 · 완료 ${mainCount(last)}개 본세트</p></div>`:''}
 <button class="btn outline full mt12" onclick="Fit.programPreview()">▦ 주간·장기 계획 보기</button>
 `;}
function readyView(){const p=state.profile;return `${head()}<div class="eyebrow">오늘의 조건 입력</div><h1>오늘은 얼마나<br>운동할 수 있나요?</h1><p class="sub">기본 시간은 ${p.duration}분이지만 오늘만 변경할 수 있어요.</p>
 <div class="card"><div class="row"><strong>오늘 운동 가능한 시간</strong><strong class="accent bigger" id="min-label">${todayMinutes}분</strong></div>
 <input type="range" min="30" max="120" step="5" value="${todayMinutes}" oninput="Fit.liveMinutes(this.value)" onchange="Fit.setMinutes(this.value)"><div class="row tiny muted"><span>30분</span><span>60분</span><span>90분</span><span>120분</span></div></div>
 <div class="card"><div class="field"><label>오늘 에너지 상태</label><div class="rate-pills">${[1,2,3,4,5].map(x=>`<button class="rate ${readiness.energy===x?'sel':''}" onclick="Fit.ready('energy',${x})">${x}</button>`).join('')}</div><div class="row tiny muted"><span>많이 피곤함</span><span>활력 넘침</span></div></div>
 <div class="field"><label>근육통·피로 누적</label><div class="rate-pills">${[1,2,3,4,5].map(x=>`<button class="rate ${readiness.soreness===x?'sel':''}" onclick="Fit.ready('soreness',${x})">${x}</button>`).join('')}</div><div class="row tiny muted"><span>거의 없음</span><span>매우 심함</span></div></div>
 <div class="field"><label>지난밤 수면·회복 상태</label><div class="rate-pills">${[1,2,3,4,5].map(x=>`<button class="rate ${readiness.sleep===x?'sel':''}" onclick="Fit.ready('sleep',${x})">${x}</button>`).join('')}</div><div class="row tiny muted"><span>매우 나쁨</span><span>매우 좋음</span></div></div>
 <div class="tile"><div class="txt"><strong>운동에 영향을 주는 통증이 있나요?</strong><div class="sub">통증이 있다면 해당 동작의 자동 증량을 보류합니다.</div></div><input class="toggle" type="checkbox" ${readiness.pain?'checked':''} onchange="Fit.ready('pain',this.checked)"></div>
 ${readiness.pain?`<div class="field"><label>통증이 있는 부위</label><select onchange="Fit.ready('painArea',this.value)"><option value="">부위 선택</option>${['가슴','등','어깨','하체','뒤허벅지','둔근','이두','삼두','복부','종아리'].map(x=>`<option value="${x}" ${readiness.painArea===x?'selected':''}>${x}</option>`).join('')}</select><p class="sub">부위를 선택하지 않으면 안전을 위해 중량 운동 생성을 중단합니다.</p></div>`:''}</div>
 <button class="btn primary full mt16" onclick="Fit.createPlan()">운동 계획 만들기</button><button class="btn secondary full mt8" onclick="Fit.go('home')">돌아가기</button>`;}
function liveMinutes(v){const el=document.getElementById('min-label');if(el)el.textContent=v+'분';todayMinutes=num(v,60);}
function setMinutes(v){todayMinutes=clamp(num(v,60),30,120);render();}
function setReady(k,v){readiness[k]=k==='pain'?!!v:k==='painArea'?String(v):num(v,3);if(k==='pain'&&!v)readiness.painArea=null;render();}
function createPlan(){if(state.active){go('work');return;}
 if(readiness.pain&&!readiness.painArea){toast('통증 부위를 선택하세요. 통증이 심하면 운동을 중단하세요.');return;}
 const plan=generatePlan(todayMinutes,readiness);
 if(!plan.items.length){toast('현재 조건으로 안전한 운동을 만들 수 없습니다. 통증·제한 사항을 확인하세요.');return;}
 const newKey=plan.optimizer?.profileKey||FitPlanPrecisionV4.profileKey(state.profile);
 const old=state.planMemory;
 if(!old||old.split!==plan.splitId||old.profileKey!==newKey)state.planMemory={split:plan.splitId,profileKey:newKey,sessionIndex:state.sessionIndex,selectedAt:Date.now()};
 state.active=plan;replanRemaining=30;save();go('work');toast('운동 계획이 준비됐어요');}
function stretchCard(kind,s){const title=kind==='pre'?'준비운동':'정리운동',total=s.length,done=s.filter(z=>z.done).length;
 return `<div class="card phase-card"><div class="row"><div><div class="eyebrow">${kind==='pre'?'WARM UP':'COOL DOWN'}</div><h2>${title} <span class="pill">${done}/${total}</span></h2></div><button class="btn small primary" onclick="Fit.play('${kind}')">▶ 재생</button></div>
 <div class="stretch-grid">${s.map((a,i)=>`<div class="stretchrow"><button class="circle-check ${a.done?'done':''}" onclick="Fit.stretch('${kind}',${i})" aria-label="${esc(a.n)} 완료">${a.done?'✓':'○'}</button><div class="grow"><strong>${esc(a.n)}</strong><div class="sub">${shortDuration(a.secs)} · ${esc(STRETCH[a.id]?.tips||'')}</div></div><button class="btn tiny secondary" onclick="Fit.guideStretch('${a.id}')">방법</button></div>`).join('')}</div></div>`;}
function weeklyVolumeCard(s){if(!s.weeklyTarget)return '';
 const actualPlan=FitPlanPrecisionV4.workingMuscleCredits(s.items);
 const relevant=[...new Set([...s.items.map(it=>it.muscle),...(state.profile.focus||[]).flatMap(m=>m==='팔'?['이두','삼두']:m==='하체'?['하체','뒤허벅지','둔근']: [m])])].filter(m=>s.weeklyTarget[m]>0).slice(0,6);
 const rows=relevant.map(m=>{const t=num(s.weeklyTarget[m],0),done=num(s.weeklyDone?.[m],0),today=num(actualPlan?.[m],0);
  return `<div class="volume-row"><span>${esc(m)}</span><span class="sub">최근 7일 ${done.toFixed(1)} + 오늘 예정 ${today.toFixed(1)} / 주간 목표 ${t}세트</span></div>`;}).join('');
 return `<div class="card"><div class="row"><strong>근육별 주간 훈련량 자동 배분</strong><span class="pill">본세트 기준</span></div>
 <p class="sub mt8">종목마다 3세트로 고정하지 않고 목표·수준·회복·시간을 반영합니다. 보조근 사용은 일부만 계산합니다.</p>${rows}
 <p class="tiny muted mt8">수치는 개인별 최적 운동량으로 검증된 값이 아닌 조절용 시작 목표입니다. 실제 기록에 따라 변경됩니다.</p></div>`;}
function optimizerCard(s){if(!s.optimizer)return '';
 const o=s.optimizer,c=o.scorecard||{},comparisons=o.splitComparison||[],
  review=o.splitSelection||{},rankings=comparisons.slice().sort((a,b)=>b.score-a.score);
 return `<div class="card precision-v4-card"><div class="row"><strong>V4 루틴 처방 근거</strong><span class="pill">${esc(o.candidateCount)}개 후보 평가</span></div>
  <p class="sub mt8">${esc(review.reason||'운동 분할과 오늘의 운동량을 함께 계산했습니다.')}</p>
  <div class="meta-grid mt12"><div><span>오늘 선택된 분할</span><strong>${esc(s.program)}</strong></div>
  <div><span>종목 · 본세트</span><strong>${s.items.length}종목 · ${s.items.reduce((n,it)=>n+it.sets.filter(z=>!z.warmup).length,0)}세트</strong></div></div>
  <details class="v4-details"><summary>분할 후보 비교 및 세부 계산 보기</summary>
  <p class="sub mt8">분할·종목·세트·운동 순서를 함께 평가합니다. 평가 점수는 앱 내부 상대 지표이며 실제 근육 성장이나 의학적 효과를 뜻하지 않습니다.</p>
  ${rankings.map((x,i)=>`<div class="row mt8"><span>${i+1}. ${esc(x.label)}</span><strong>${x.unavailable?'적합한 후보 없음':Number(x.score).toFixed(1)+'점'}</strong></div>`).join('')}
  <div class="subhead"><strong>선정안 평가 상세</strong><p class="sub">목표 훈련량 적합도 ${num(c.trainingUtility).toFixed(1)} · 중복·회복 부담 ${num(c.overlapPenalty).toFixed(1)} · 연속 동작 간섭 ${num(c.orderPenalty).toFixed(1)} · 예상 시간 비용 ${num(c.timeCost).toFixed(1)}</p></div>
  <p class="sub">운동 기록이 쌓이면 다음 운동일마다 재계산하되, 단 하루 피로로 기존 분할을 자주 바꾸지 않습니다.</p></details></div>`;
}
function replanCard(s){return `<div class="card"><div class="row"><div><strong>남은 시간에 맞춰 재계획</strong><p class="sub">운동 중에도 변경 가능 · 완료한 세트는 유지</p></div><span class="pill">잔여 예상 ${FitPlan15.estimatePending(s)}분</span></div>
 <div class="field mt12"><label>지금부터 운동 가능한 시간 <strong id="replan-label">${replanRemaining}분</strong></label><input type="range" min="10" max="120" step="5" value="${replanRemaining}" oninput="Fit.liveRemaining(this.value)"></div>
 <button class="btn secondary full" onclick="Fit.replanNow()">↺ 남은 시간으로 다시 구성</button>
 ${s.lastReplan?`<p class="sub mt8">최근 조정: ${s.lastReplan.action} · 세트 ${s.lastReplan.removedSets}개 제외 / ${s.lastReplan.addedSets}개 추가 · 잔여 예상 ${s.lastReplan.after}분</p>`:''}</div>`;}
function cardioBlock(s){if(!(s.cardio||[]).length)return '';
 const done=s.cardio.filter(x=>x.done).length;
 return `<div class="card phase-card"><div class="row"><div><div class="eyebrow">CARDIO</div><h2>유산소 <span class="pill">${done}/${s.cardio.length}</span></h2></div><button class="btn small primary" onclick="Fit.play('cardio')">▶ 재생</button></div>
 ${s.cardio.map((x,i)=>`<div class="stretchrow"><button class="circle-check ${x.done?'done':''}" onclick="Fit.cardioCheck(${i})">${x.done?'✓':'○'}</button><div class="grow"><strong>${esc(x.n)}</strong><div class="sub">${shortDuration(x.secs)} · ${esc(x.intensity)} · 통증이나 어지러움이 있으면 중단</div></div></div>`).join('')}</div>`;}
function cardioCheck(i){const s=state.active?.cardio?.[i];if(!s)return;s.done=!s.done;save();render();}
function liveRemaining(v){replanRemaining=clamp(num(v,30),10,120);const node=document.getElementById('replan-label');if(node)node.textContent=replanRemaining+'분';}
function replanNow(){if(!state.active)return;
 // Rebuild the unfinished sequence after user exits the player; never alter checked sets.
 if(state.player){state.player=null;}
 const out=FitPlan15.replan(state.active,replanRemaining,state.profile,state.active.readiness||readiness);
 state.active.timeLimit=Math.max(state.active.timeLimit,Math.round((Date.now()-state.active.startAt)/60000)+replanRemaining);
 save();render();toast('남은 시간에 맞춰 '+out.action+'했습니다. 완료 기록은 유지됩니다.');}
function itemCard(it,index){const e=exercise(it.currentId)||exercise(it.eid);if(!e)return '';
 const c=it.sets.filter(z=>z.done).length,N=it.sets.length,allDone=c===N;
 return `<div class="card exercise-card ${allDone?'exercise-finished':''}"><div class="row"><div><div class="eyebrow">EXERCISE ${index+1} · ${esc(e.m)} · ${esc(e.gear)}</div><h2>${esc(e.n)} ${allDone?'<span class="checkmark">✓</span>':''}</h2></div><span class="pill ${allDone?'good':''}">${c}/${N}세트</span></div>
 ${(it.safetyNotes||[]).length?`<div class="callout">${it.safetyNotes.map(esc).join(' · ')}</div>`:''}${FitPlanPrecisionV5.usesLoad(e)&&FitPlanPrecisionV5.calibrationStatus(state,e,it.machineId).needed?`<button class="btn secondary full mt8" onclick="Fit.beginCalibration(${index})">◎ 처음 쓰는 기구 · 적정 무게 시험 시작</button>`:''}${it.halted?'<div class="callout">통증·자세 문제로 남은 세트를 중단했습니다.</div>':''}${!['body','band'].includes(e.gear)?`<div class="sub mt8">기구: ${esc(FitPlanAdvanced.machineRecord(state,e).variants.find(x=>x.id===it.machineId)?.name||'기본 기구')} <button class="btn tiny outline" onclick="Fit.machineFor(${index})">변경</button></div>`:''}<div class="row mt12 action-links"><button class="btn tiny secondary" onclick="Fit.guide('${e.id}')">▷ 운동 방법·영상</button><button class="btn tiny outline" onclick="Fit.alternatives(${index})">↔ 기구 사용 중</button></div>
 <table class="sets"><thead><tr><th>완료</th><th>세트</th><th>권장 kg</th><th>권장 횟수</th><th>실제 kg</th><th>실제 횟수</th><th>남는 횟수(RIR)</th></tr></thead><tbody>${it.sets.map((s,j)=>{
 const label=s.warmup?'준비':`${it.sets.slice(0,j+1).filter(z=>!z.warmup).length}세트`,timed=isTimed(e);
 return `<tr class="${s.done?'set-checked':''}"><td><button class="circle-check ${s.done?'done':''}" aria-label="${label} 완료" onclick="Fit.checkSet(${index},${j})">${s.done?'✓':'○'}</button></td><td>${label}</td><td>${s.requiresCalibration?'측정 필요':s.targetWeight?formatWeight(s.targetWeight):'—'}</td><td>${s.targetReps}${timed?'초':'회'}</td><td><input inputmode="decimal" type="number" step="0.5" min="0" value="${s.actualWeight}" aria-label="실제 중량" onchange="Fit.editSet(${index},${j},'actualWeight',this.value)"></td><td><input inputmode="numeric" type="number" step="1" min="0" value="${s.actualReps}" aria-label="실제 횟수" onchange="Fit.editSet(${index},${j},'actualReps',this.value)"></td><td><input inputmode="numeric" type="number" step="1" min="0" max="6" placeholder="선택" value="${s.rir===null?'':s.rir}" aria-label="남은 반복 횟수" onchange="Fit.editSet(${index},${j},'rir',this.value)"></td></tr>`;}).join('')}</tbody></table>
 <div class="tiny muted mt8">휴식 ${it.rest}초</div></div>`;}
function workView(){const s=state.active;if(!s)return `${head()}<div class="eyebrow">운동</div><h1>오늘의 운동 준비</h1><div class="card"><p>오늘 가능한 시간을 선택하면 루틴을 자동 생성합니다.</p><button class="btn full primary mt16" onclick="Fit.go('ready')">운동 계획 만들기 →</button></div>`;
 const [done,total]=doneCount(s),p=Math.round(done/Math.max(1,total)*100);
 return `${head()}<div class="eyebrow">TODAY · ${esc(s.program)}</div><h1>${esc(s.splitName)}</h1>
 <div class="card summary-card"><div class="row"><div><span class="muted tiny">운동 목표 시간</span><h2>${s.timeLimit}분</h2></div><div><span class="muted tiny">본운동 종목</span><h2>${s.items.length}개</h2></div><div><span class="muted tiny">전체 진행률</span><h2>${done}/${total}</h2></div></div><div class="progressrail"><div style="width:${p}%"></div></div>
 <button class="btn primary full playbig" onclick="Fit.play('all')">▶ 운동 시작 · 이어하기</button></div>
 ${weeklyVolumeCard(s)}${optimizerCard(s)}${v5QualityCard(s)}${stretchCard('pre',s.pre)}${replanCard(s)}<div class="sectionhead"><h2>본운동</h2><button class="btn tiny primary" onclick="Fit.play('main')">▶ 시작</button></div>
 
 ${s.deload?`<div class="callout"><strong>회복·피로 조절 주간</strong><p>${esc(s.deloadReason)}</p></div>`:''}${s.paceSamples>=3?`<div class="callout">기록 기반 예상 소요 약 ${s.adjustedPredictedMinutes}분 · 개인별 운동 속도 학습 (${s.paceSamples}회)</div>`:''}
 ${(s.concerns||[]).length?`<div class="callout">${s.concerns.map(x=>esc(x)).join(' · ')}</div>`:''}
 ${s.items.map((it,i)=>itemCard(it,i)).join('')}
 ${cardioBlock(s)}
 ${stretchCard('post',s.post)}
 <div class="card"><div class="row"><strong>오늘 운동 정리</strong><span class="pill">${mainCount(s)}개 본세트 기록</span></div><p class="sub mt8">완료하지 못한 세트도 그대로 남기고 운동을 종료할 수 있습니다. 이후 자동 계획은 실제 완료한 결과만 반영해요.</p>
 <button class="btn primary full mt12" onclick="Fit.endWorkout()">운동 마치기 · 평가</button></div>`;}
function setStretchDone(kind,index){const a=state.active?.[kind]?.[index];if(!a)return;a.done=!a.done;save();render();}
function editSet(index,j,k,value){const a=state.active?.items?.[index]?.sets?.[j];if(!a||!['actualWeight','actualReps','rir'].includes(k))return;const n=num(value,0);a[k]=k==='rir'?clamp(n,0,6):clamp(n,0,k==='actualWeight'?1000:1000);save();}
function adjustFollowing(it,idx){
 const s=it.sets[idx],e=exercise(it.currentId);
 if(!s||!e||s.warmup||!s.done)return;
 const next=it.sets.slice(idx+1).find(z=>!z.done&&!z.warmup);
 if(s.requiresCalibration&&num(s.actualWeight)>0){
   s.targetWeight=s.actualWeight;s.requiresCalibration=false;
   const rec=FitPlanAdvanced.machineRecord(state,e),variant=rec.variants.find(x=>x.id===it.machineId)||rec.variants[0];
   const step=variant.increment||2.5;
   const lift=(!s.pain&&s.rir!==null&&s.rir>=5&&num(s.actualReps)>=num(s.targetReps))?step:0;
   it.sets.filter(z=>!z.done&&z.requiresCalibration).forEach(z=>{z.targetWeight=s.actualWeight+lift;z.actualWeight=s.actualWeight+lift;z.requiresCalibration=false;});
   it.reason='첫 시험 세트의 실제 중량을 기준으로 남은 세트의 목표를 설정했습니다. 너무 힘들었다면 중량을 낮추세요.';
   return;
 }
 if(!next)return;
 const z=FitPlanPrecisionV4.adjustNextSet(e,s,{...next,restSec:next.restSec||it.rest},
   {done:true,reps:s.actualReps,rir:s.rir,form:s.form,pain:s.pain},{allowIntraSessionIncrease:false});
 if(!z)return;
 if(z.targetWeight!==null&&z.targetWeight!==next.targetWeight){next.targetWeight=z.targetWeight;next.actualWeight=z.targetWeight;}
 next.restSec=z.restSec||next.restSec;
 if(z.reason)it.reason=z.reason;
}
function checkSet(index,j){const it=state.active?.items?.[index],s=it?.sets?.[j];if(!it||!s)return;
 const ex=exercise(it.currentId);if(!s.done&&FitPlanPrecisionV5.calibrationStatus(state,ex,it.machineId).needed){beginCalibration(index);return;}
 if(!s.done&&num(s.actualReps)<=0){toast('실제로 수행한 횟수 또는 초를 입력하세요');return;}
 if(!s.done&&!isTimed(exercise(it.currentId))&&!['body','band'].includes(exercise(it.currentId)?.gear)&&num(s.actualWeight)<=0){toast('처음 사용하는 기구는 가벼운 시험 세트 후 실제 중량(kg)을 입력하세요');return;}
 s.done=!s.done;if(s.done){s.actualId=it.currentId;s.machineId=it.machineId||'default';}if(s.done)adjustFollowing(it,j);save();render();}

function machineFor(index){const it=state.active?.items?.[index],e=exercise(it?.currentId);if(!e)return;
 const rec=FitPlanAdvanced.machineRecord(state,e);modal={type:'machineChoose',index,e,rec};render();}
function selectMachine(index,id){const it=state.active?.items?.[index],e=exercise(it?.currentId);if(!it||!e)return;
 const rec=FitPlanAdvanced.machineRecord(state,e);if(!rec.variants.some(x=>x.id===id))return;
 rec.active=id;it.machineId=id;
 const decision=FitPlanAdvanced.machineDecision(state,e,readiness),base=decision.analysis.weight;
 for(const set of it.sets){if(set.done)continue;const newW=base===null?0:Math.max(decision.varnt.increment,roundTo(base*(set.warmup?.5:set.role==='backoff'?.9:1),decision.varnt.increment));
   set.targetWeight=newW;set.actualWeight=newW;set.requiresCalibration=base===null&&!isTimed(e)&&!['body','band'].includes(e.gear);set.machineId=id;
 }
 modal=null;save();if(state.player&&view==='player'&&FitPlanPrecisionV5.calibrationStatus(state,e,id).needed){beginCalibration(index);return;}render();toast('기구별 중량 기록을 분리했습니다');}
function addMachine(eid){const e=exercise(eid);if(!e)return;
 const label=document.getElementById('machine-name-'+eid)?.value?.trim(),inc=Number(document.getElementById('machine-step-'+eid)?.value),seat=document.getElementById('machine-seat-'+eid)?.value?.trim()||'',notes=document.getElementById('machine-notes-'+eid)?.value?.trim()||'';
 if(!label||!Number.isFinite(inc)||inc<.25||inc>25){toast('기구 별명과 증량 단위(0.25~25kg)를 입력해 주세요');return;}
 const rec=FitPlanAdvanced.machineRecord(state,e);const id='m'+Date.now().toString(36);rec.variants.push({id,name:label.slice(0,40),increment:inc,seat:seat.slice(0,40),notes:notes.slice(0,120)});rec.active=id;save();render();toast('새 기구를 등록했습니다. 해당 기구의 중량은 별도로 학습합니다.');}
function machineView(){return `${head()}<div class="eyebrow">MY EQUIPMENT</div><h1>내 헬스장 기구</h1><p class="sub">같은 운동이라도 기구마다 무게가 다르게 느껴질 수 있어요. 각각의 무게·증량 단위·좌석 위치를 따로 기록합니다.</p>
 ${CATALOG.filter(e=>SIMPLE_ORDER.has(e.id)&&!['body','band'].includes(e.gear)).map(e=>{const rec=FitPlanAdvanced.machineRecord(state,e);return `<div class="card"><div class="row"><h2>${esc(e.n)}</h2><span class="pill">${rec.variants.length}개</span></div>
 <div class="field mt8"><label>사용할 기구</label><select onchange="Fit.setMachineDefault('${e.id}',this.value)">${rec.variants.map(v=>`<option value="${v.id}" ${v.id===rec.active?'selected':''}>${esc(v.name)} · ${v.increment}kg 단위</option>`).join('')}</select></div>
 ${rec.variants.filter(v=>v.id===rec.active).map(v=>`<p class="sub">좌석/손잡이: ${esc(v.seat||'미기록')} · ${esc(v.notes||'메모 없음')}</p>`).join('')}
 <div class="field mt8"><label>새 기구 별명</label><input id="machine-name-${e.id}" placeholder="예: 창가 체스트프레스"></div>
 <div class="grid2"><div class="field"><label>증량 단위(kg)</label><input id="machine-step-${e.id}" inputmode="decimal" type="number" value="${e.gear==='dumbbell'?1:2.5}" min="0.25" max="25" step="0.25"></div><div class="field"><label>좌석·손잡이 위치</label><input id="machine-seat-${e.id}" placeholder="예: 좌석 4"></div></div>
 <div class="field"><label>기구 메모</label><input id="machine-notes-${e.id}" placeholder="예: 오른쪽 벽 머신"></div><button class="btn secondary full mt8" onclick="Fit.addMachine('${e.id}')">+ 새 기구 등록</button></div>`}).join('')}
 <button class="btn primary full" onclick="Fit.go('settings')">설정으로 돌아가기</button>`;}
function guide(id){const e=exercise(id);if(!e)return;modal={type:'guide',e};render();}
function guideStretch(id){const e=STRETCH[id];if(!e)return;modal={type:'stretch',e,id};render();}
function alternatives(index){const it=state.active?.items?.[index];if(!it)return;
 const original=exercise(it.currentId);const used=new Set(state.active.items.map(x=>x.currentId));
 const options=CATALOG.filter(e=>e.id!==it.currentId&&isAllowed(e)&&e.pattern===original.pattern&&!used.has(e.id)).sort((a,b)=>SIMPLE_ORDER.get(a.id)-SIMPLE_ORDER.get(b.id));
 modal={type:'alternatives',index,options};render();}
function replaceExercise(index,id){const it=state.active?.items?.[index],e=exercise(id);if(!it||!isAllowed(e))return;
 const old=exercise(it.currentId);if(!old||old.pattern!==e.pattern){toast('같은 움직임 패턴의 운동만 대체할 수 있습니다');return;}
 const n=suggestedLoad(e,readiness);it.currentId=e.id;it.reason=`${old.n} 대신 ${e.n} 선택. 완료된 세트는 유지하고 남은 세트만 변경합니다.`;
 it.rest=restTime(e,state.profile.goal,readiness);
 it.sets.forEach(s=>{if(!s.done){s.targetWeight=n.weight;s.actualWeight=n.weight;s.actualId=e.id;s.requiresCalibration=n.first;}});
 modal=null;save();render();toast('남은 세트의 운동을 대체했습니다');}
function openVideo(en){const url='https://www.youtube.com/results?search_query='+encodeURIComponent(en||'beginner exercise form');
 try{window.location.href=url;}catch(e){modal={type:'url',url};render();}}
function endWorkout(){if(!state.active)return;const count=mainCount(state.active);if(count<1){toast('본운동을 최소 1세트 이상 수행한 뒤 평가하세요');return;}
 feedback={weight:currentWeight(),difficulty:5,pain:false,soreness:2,note:''};go('finish');}
function exerciseEffort(i,v){const it=state.active?.items?.[i];if(!it)return;it.effort=v;save();render();}
function exerciseReview(i,field,value){
 const it=state.active?.items?.[i];if(!it)return;
 if(field==='rir')it.reviewRir=value===''?null:clamp(num(value),0,6);
 if(field==='form')it.reviewForm=['good','uncertain','poor'].includes(value)?value:'uncertain';
 if(field==='pain')it.reviewPain=!!value;
 save();
}
function applyExerciseReviews(session){
 for(const it of session.items||[]){
  const done=(it.sets||[]).filter(x=>x.done&&!x.warmup);if(!done.length)continue;
  const rir=it.reviewRir;const form=it.reviewForm||'uncertain';const pain=!!it.reviewPain;
  // Late-stage feedback belongs to exercise-level records, not invented per-set observations.
  it.review={rir,form,pain,effort:it.effort||null};
  const last=done[done.length-1];
  if(rir!==null&&rir!==undefined)last.rir=rir;
  if(form!=='uncertain')last.form=form;
  if(pain)last.pain=true;
 }
}
function setFeedback(k,v){feedback[k]=['weight','difficulty','soreness'].includes(k)?num(v):k==='pain'?!!v:String(v);if(k==='difficulty'||k==='soreness'||k==='pain')render();}
function finishView(){const s=state.active;if(!s)return homeView();const [done,total]=doneCount(s),mins=Math.max(1,Math.round((Date.now()-s.startAt)/60000));
 return `${head()}<div class="eyebrow">WORKOUT REVIEW</div><h1>오늘 운동은<br>어땠나요?</h1><p class="sub">수행 결과와 체감 난도를 함께 분석해 다음 운동의 중량·세트 수를 자동 조절합니다.</p>
 <div class="grid3 mt16"><div class="stat"><div class="tiny muted">실제 경과</div><strong>${mins}분</strong></div><div class="stat"><div class="tiny muted">운동 종목</div><strong>${s.items.length}개</strong></div><div class="stat"><div class="tiny muted">진행 상황</div><strong>${done}/${total}</strong></div></div>
 <div class="card"><div class="field"><label>오늘 운동 전체 난이도 (1=매우 쉬움, 10=매우 어려움)</label><div class="rate-pills">${[1,2,3,4,5,6,7,8,9,10].map(x=>`<button class="rate small-rate ${feedback.difficulty===x?'sel':''}" onclick="Fit.feedback('difficulty',${x})">${x}</button>`).join('')}</div><p class="sub mt8">${feedback.difficulty<=2?'매우 쉬웠어요':feedback.difficulty<=4?'쉬웠어요':feedback.difficulty<=6?'적당했어요':feedback.difficulty<=8?'어려웠어요':'매우 어려웠어요'}</p></div>
 <div class="field"><label>종목별 종료 평가 (다음 운동에 반영)</label>
 ${(s.items||[]).map((it,i)=>{const completed=it.sets?.filter(x=>x.done&&!x.warmup).length||0;if(!completed)return '';const e=exercise(it.currentId)||exercise(it.eid);return `<div class="player-setup-card mt12"><strong>${esc(e?.n||'운동')} · ${completed}세트 완료</strong>
 <div class="seg mt8">${[[1,'쉬움'],[2,'적당'],[3,'어려움']].map(([v,l])=>`<button class="${it.effort===v?'active':''}" onclick="Fit.exerciseEffort(${i},${v})">${l}</button>`).join('')}</div>
 <label class="player-setup-field">마지막 세트 반복 여유 (선택)<select onchange="Fit.exerciseReview(${i},'rir',this.value)"><option value="">선택하지 않음</option>${[0,1,2,3,4,5,6].map(v=>`<option value="${v}" ${it.reviewRir===v?'selected':''}>${v===6?'6회 이상':v+'회'}</option>`).join('')}</select></label>
 <label class="player-setup-field">자세 평가<select onchange="Fit.exerciseReview(${i},'form',this.value)"><option value="uncertain">평가하지 않음</option><option value="good" ${it.reviewForm==='good'?'selected':''}>안정적</option><option value="poor" ${it.reviewForm==='poor'?'selected':''}>불안정</option></select></label>
 <label class="player-setup-field">통증 발생 <input type="checkbox" ${it.reviewPain?'checked':''} onchange="Fit.exerciseReview(${i},'pain',this.checked)"></label></div>`;}).join('')}</div>
 <div class="field"><label>오늘 몸무게 (kg) · 선택 입력</label><input type="number" min="20" max="300" step="0.1" value="${feedback.weight}" onchange="Fit.feedback('weight',this.value)"><p class="sub mt8">가능하면 일정한 조건에서 측정해 장기 추세를 확인하세요.</p></div>
 <div class="field"><label>운동 후 근육 피로도</label><div class="rate-pills">${[1,2,3,4,5].map(x=>`<button class="rate ${feedback.soreness===x?'sel':''}" onclick="Fit.feedback('soreness',${x})">${x}</button>`).join('')}</div></div>
 <div class="tile"><div class="txt"><strong>운동 중 통증이 있었나요?</strong><div class="sub">통증이 있었다면 해당 부위의 증량을 제한합니다.</div></div><input type="checkbox" class="toggle" ${feedback.pain?'checked':''} onchange="Fit.feedback('pain',this.checked)"></div>
 <div class="field"><label>오늘 메모 (선택)</label><textarea rows="2" onchange="Fit.feedback('note',this.value)" placeholder="운동 중 불편했던 점, 기구 상태 등">${esc(feedback.note||'')}</textarea></div></div>
 <button class="btn full primary mt16" onclick="Fit.saveWorkout()">분석 저장 · 다음 루틴에 반영</button><button class="btn full secondary mt8" onclick="Fit.go('work')">운동 화면으로 돌아가기</button>`;}
function saveWorkout(){const a=state.active;if(!a||!mainCount(a)){toast('완료한 본세트가 없습니다');return;}
 applyExerciseReviews(a);if(a.items.some(it=>it.reviewPain))feedback.pain=true;const s=deep(a);s.finishedAt=Date.now();s.durationMin=Math.max(1,Math.round((s.finishedAt-s.startAt)/60000));s.feedback=deep(feedback);s.bodyweight=s.feedback.weight;s.difficulty=s.feedback.difficulty;
 try{state.lastReview=FitPlanPrecisionV4.reviewSession(s,state.history,CATALOG,state.profile,readiness);}catch(err){console.warn('V3 review error',err);}
 state.history.push(s);state.sessionIndex++;if(state.history.length===1)state.cycle=null;refreshCycle();state.active=null;state.player=null;state.profile.weight=feedback.weight||state.profile.weight;
 if(state.history.length>700)state.history=state.history.slice(-700);
 save();view='state';render();window.scrollTo(0,0);toast('운동이 저장됐어요. 다음 루틴이 자동 변경됩니다.');}
/* V5 quality and recovery indicators use completed records, not unverified muscle-growth claims. */
function v5QualityCard(s){
 const rec=FitPlanPrecisionV5.recoveryGuide(state.history,s.readiness||readiness);
 const pending=s.items.filter(it=>FitPlanPrecisionV5.calibrationStatus(state,exercise(it.currentId),it.machineId).needed);
 const rated=s.items.map(it=>({it,e:exercise(it.currentId),q:FitPlanPrecisionV5.exerciseQuality(state.history,it.currentId,it.machineId)}));
 return `<div class="card"><div class="eyebrow">V5 · 운동 품질과 중량 측정</div><h2>초보자도 따라가는 자동 코치</h2>
 <p class="sub">${esc(rec.reason)} · 첫 시험 필요 ${pending.length}종목</p>
 ${rated.map(x=>`<div class="row mt8"><span>${esc(x.e?.n||'운동')}</span><span class="pill">${esc(x.q.label)}${x.q.score!==null?' · 안정적 목표 달성 '+x.q.score+'%':''}</span></div>`).join('')}
 <p class="tiny muted mt8">자세 평가는 직접 입력한 값입니다. 카메라 자동 자세 판독이 아닙니다. 시험 세트는 본운동 세트 수에 포함하지 않습니다.</p></div>`;
}
function beginCalibration(index){
 const it=state.active?.items?.[index],e=exercise(it?.currentId);if(!it||!e||!FitPlanPrecisionV5.usesLoad(e))return;
 if(it.halted){toast('통증이나 자세 문제로 중단된 종목입니다.');return;}
 const rec=FitPlanAdvanced.machineRecord(state,e),v=rec.variants.find(x=>x.id===it.machineId)||rec.variants[0];
 const old=state.calibrationActive;
 if(!old||old.exerciseId!==e.id||old.machineId!==v.id||!['active','paused'].includes(old.status)){
   state.calibrationActive={...FitPlanPrecisionV5.begin(state.profile,e,v.id,v.increment,v.minimum),index};
 }else if(old.status==='paused'&&old.reason&&!old.reason.includes('자세가 안정적인지')){
   // Resume after a break, retaining all previous trial records.
   old.status='active';old.phase='instructions';old.dayStartedAt=Date.now();
 }
 view='calibration';save();render();
}
function calibrationView(){
 const c=state.calibrationActive;if(!c)return workView();
 const e=exercise(c.exerciseId),it=state.active?.items?.[c.index];
 if(!e||!it)return `<div class="shell"><h2>측정 정보를 불러오지 못했습니다.</h2><button onclick="Fit.calibrationAbort()">돌아가기</button></div>`;
 const attempt=c.attempts.length+1,ready=['ready','provisional'].includes(c.status),stopped=c.status==='stopped';
 const hints=FitPlanPrecisionV5.stepsFor(e);
 let body='';
 if(c.phase==='instructions'&&c.status==='active'){
 body=`<div class="card"><div class="eyebrow">STEP ${attempt} · 적정 중량 탐색</div><h2>시험 중량 설정</h2>
 <div class="callout"><strong>앱의 시험 후보 ${formatWeight(c.weight)}kg · ${c.targetReps}회</strong><p class="mt8">${esc(c.attempts.length?c.reason:c.first.note)}</p></div>
 <details class="v4-details"><summary>자세·기구 사용법 보기</summary><ol class="guide-steps">${hints.map(x=>`<li>${esc(x)}</li>`).join('')}</ol></details>
 <label class="player-setup-field">실제 사용할 중량(kg)<input id="cal-weight" inputmode="decimal" type="number" min="0.25" max="1000" step="0.25" value="${c.weight||''}"></label>
 <p class="tiny muted">기구에 없는 중량은 더 가벼운 단계로 설정하세요.</p>
 <button class="btn primary full mt12" onclick="Fit.calibrationStart()">▶ 시험 세트 시작</button></div>`;
 }else if(c.phase==='perform'){
 body=`<div class="player-tag">시험 세트 진행</div><h1 class="player-title">${esc(e.n)}</h1>
 <div class="player-clock" id="calibration-clock">00:00</div>
 <div class="player-set-summary">${formatWeight(c.weight)}kg · 목표 ${c.targetReps}회</div>
 <p class="tiny muted">통증이나 자세 불안정이 발생하면 중단하세요.</p>
 <button class="btn primary full mt12" onclick="Fit.calibrationEnd()">✓ 시험 완료 · 상태 평가</button>`;
 }else if(c.phase==='feedback'){
 body=`<div class="card"><div class="eyebrow">시험 ${attempt}회차 평가</div><h2>${formatWeight(c.weight)}kg 수행 결과</h2>
 <label class="player-setup-field">실제 완료한 횟수<input id="cal-reps" type="number" inputmode="numeric" min="0" max="80" step="1" value="${c.targetReps}"></label>
 <label class="player-setup-field">더 할 수 있었을 것 같은 횟수 (RIR)
 <select id="cal-rir"><option value="" selected>선택해 주세요</option>${[0,1,2,3,4,5,6,8,10,12,15].map(x=>`<option value="${x}">${x===15?'15회 이상':x+'회'} 더 가능</option>`).join('')}</select></label>
 <label class="player-setup-field">운동 자세
 <select id="cal-form"><option value="good">안정적 · 동작 범위 유지</option><option value="uncertain">잘 모르겠음</option><option value="poor">반동·자세 무너짐</option></select></label>
 <div class="tile"><div class="txt"><strong>운동 중 통증이 있었음</strong><div class="sub">통증 발생 시 자동 중단</div></div><input class="toggle" id="cal-pain" type="checkbox"></div>
 <button class="btn primary full mt12" onclick="Fit.calibrationSubmit()">평가 저장 · 다음 중량 계산</button></div>`;
 }else if(c.phase==='rest'&&c.status==='active'){
 const remaining=Math.max(0,Math.ceil((c.restUntil-Date.now())/1000));
 body=`<div class="card"><div class="eyebrow">시험 사이 휴식</div><h2>다음 시험을 준비하세요</h2>
 <div class="player-clock" id="calibration-clock">${shortDuration(remaining)}</div><p>${esc(c.reason)}</p>
 
 <button class="btn primary full mt12" onclick="Fit.calibrationContinue()">휴식 완료 · 다음 시험</button></div>`;
 }else{
 body=`<div class="card"><h2>${stopped?'시험 중단':c.status==='paused'?'측정 일시 중지':ready?'적정 시작 중량 확인':'시험 결과 확인'}</h2>
 <div class="callout">${esc(c.reason||'')}</div>
 ${ready?`<h1 class="big-num">${formatWeight(c.weight)}kg</h1><p class="sub">현재 기구에서 사용할 임시 기준 중량입니다. 본세트에서는 시험 평가 없이 완료 체크만 진행합니다.</p>
 <button class="btn primary full mt12" onclick="Fit.calibrationApply()">✓ 기준 중량 저장 · 본운동 시작</button>`:
 `<p class="sub">${c.status==='paused'?'시험 기록을 보존했습니다. 충분히 회복한 다음 운동일에 이어서 진행할 수 있습니다.':'통증·자세 문제를 먼저 점검하세요.'}</p>${c.status==='paused'?'<button class="btn secondary full mt12" onclick="Fit.calibrationResume()">이어서 탐색</button>':''}<button class="btn secondary full mt12" onclick="Fit.calibrationAbort()">해당 운동 중단 · 돌아가기</button>`}</div>`;
 }
 return `<div class="player-page"><header class="player-head"><div><div class="eyebrow">최초 중량 측정</div><strong>${esc(e.n)} · ${attempt}회차</strong></div><button class="player-close" onclick="Fit.calibrationAbort()">✕</button></header>
 <div class="player-progress"><div style="width:${c.status==='ready'?100:Math.min(92,15+c.attempts.length*10)}%"></div></div>
 <div class="player-body"><h1 class="player-title">내 적정 무게 찾기</h1>${body}
 ${c.attempts.length?`<details class="v4-details"><summary>이전 시험 ${c.attempts.length}회 기록</summary>${c.attempts.map((t,i)=>`<p class="sub">${i+1}차 · ${formatWeight(t.weight)}kg × ${t.reps}회 · 여유 ${t.rir}회 · ${esc(t.form==='good'?'자세 안정':t.form==='poor'?'자세 무너짐':'확신 없음')}</p>`).join('')}</details>`:''}</div>
 </div>`;
}
function calibrationResume(){const c=state.calibrationActive;if(!c||c.status!=='paused')return;c.status='active';c.phase='instructions';c.dayStartedAt=Date.now();save();render();}
function calibrationStart(){const c=state.calibrationActive;if(!c||c.phase!=='instructions')return;
 const raw=document.getElementById('cal-weight')?.value?.trim(),w=Number(raw);
 if(!raw||!Number.isFinite(w)||w<=0||w>1000){showPlayerWarning('시험할 기구의 실제 중량(kg)을 먼저 설정해 주세요.');return;}
 c.weight=w;c.phase='perform';c.startedTrialAt=Date.now();save();coachSpeak(`시험 세트. ${w}킬로그램으로 ${c.targetReps}회 목표. 자세를 먼저 확인하세요.`);render();}
function calibrationEnd(){const c=state.calibrationActive;if(!c||c.phase!=='perform')return;c.phase='feedback';save();render();}
function calibrationSubmit(){const c=state.calibrationActive;if(!c||c.phase!=='feedback')return;
 const raw=document.getElementById('cal-reps')?.value,rr=document.getElementById('cal-rir')?.value,form=document.getElementById('cal-form')?.value,pain=!!document.getElementById('cal-pain')?.checked;
 if(rr===''||!raw){showPlayerWarning('실제 횟수와 남은 반복 여유를 입력해 주세요.');return;}
 try{const next=FitPlanPrecisionV5.evaluateTrial(c,{weight:c.weight,reps:Number(raw),rir:Number(rr),form,pain});state.calibrationActive=next;
   if(next.status==='active'){next.phase='rest';next.restUntil=Date.now()+90000;next.restAlarmPlayed=false;}
   if(next.status==='stopped')state.active.items[c.index].halted=true;
   save();render();
 }catch(e){showPlayerWarning('입력한 횟수와 난도를 다시 확인해 주세요.');}}
function calibrationContinue(){const c=state.calibrationActive;if(!c||c.phase!=='rest')return;
 if(Date.now()<c.restUntil){toast('몸의 피로가 충분히 줄었는지 확인하고 진행하세요.');}
 c.phase='instructions';save();render();}
function calibrationApply(){const c=state.calibrationActive;if(!c||!['ready','provisional'].includes(c.status))return;
 const it=state.active?.items?.[c.index],e=exercise(c.exerciseId);if(!it||!e)return;
 state.calibrations=state.calibrations||{};
 state.calibrations[c.key]=FitPlanPrecisionV5.finishCalibration(c);
 it.calibrationTrials=(it.calibrationTrials||[]).concat(c.attempts.map(x=>({...x,machineId:c.machineId,exerciseId:c.exerciseId,testOnly:true})));
 const w=c.weight;for(const s of it.sets){if(s.done)continue;
   if(s.warmup){s.done=true;s.label='중량 탐색으로 준비 완료';s.calibrationTest=true;
      s.actualWeight=c.attempts[0]?.weight||w;s.actualReps=c.attempts[0]?.reps||c.targetReps;s.actualId=e.id;s.machineId=it.machineId;}
   else {s.targetWeight=w;s.actualWeight=w;s.requiresCalibration=false;}
 }
 it.reason=`${c.attempts.length}회 시험 세트로 찾은 ${formatWeight(w)}kg을 최초 본세트 기준으로 사용합니다. ${c.status==='provisional'?'다음에 재확인이 필요합니다.':'실제 수행 결과에 따라 다음 운동에서 재조정합니다.'}`;
 state.calibrationActive=null;save();
 if(state.player){const p=state.player,seq=playerSequence(p.mode),next=seq.findIndex(x=>!x.ref.done);
  if(next<0){state.player=null;view='work';render();return;}
  p.step=next;p.stage='prepare';p.paused=false;view='player';startPlayerStep();
 }else view='work';
 save();render();toast('적정 시작 중량을 저장했습니다');}
function calibrationAbort(){const c=state.calibrationActive;
 if(c&&state.active?.items?.[c.index])state.active.items[c.index].halted=true;
 state.calibrationActive=null;state.player=null;view='work';save();render();toast('해당 종목의 자동 진행을 중단했습니다.');}
function playerSequence(mode){const a=state.active;if(!a)return [];const sequence=[];
 if(['all','pre'].includes(mode))a.pre.forEach((x,i)=>sequence.push({phase:'pre',kind:'stretch',index:i,title:x.n,secs:x.secs,ref:x}));
 if(['all','main'].includes(mode))a.items.forEach((it,i)=>it.sets.forEach((x,j)=>{if(it.halted&&!x.done)return;const e=exercise(x.done&&x.actualId?x.actualId:it.currentId);sequence.push({phase:'main',kind:isTimed(e)?'timed':'set',index:i,set:j,title:e?.n||'운동',secs:isTimed(e)?x.targetReps:0,rest:it.rest,ref:x,e});}));
 if(['all','cardio'].includes(mode))(a.cardio||[]).forEach((x,i)=>sequence.push({phase:'cardio',kind:'stretch',index:i,title:x.n,secs:x.secs,ref:x}));
 if(['all','post'].includes(mode))a.post.forEach((x,i)=>sequence.push({phase:'post',kind:'stretch',index:i,title:x.n,secs:x.secs,ref:x}));
 return sequence;}
function playerCurrent(){const p=state.player;if(!p)return null;return playerSequence(p.mode)[p.step]||null;}
function play(mode){if(!state.active)return;if(!['all','pre','main','cardio','post'].includes(mode))return;
 initAudio();const steps=playerSequenceFor(mode);const step=steps.findIndex(x=>!x.ref.done);
 if(step<0){toast('선택한 구간을 모두 완료했습니다');return;}
 state.player={mode,step,stage:'doing',paused:false,startedAt:Date.now(),deadline:0,remaining:0,restSeconds:0,warned10:false,pausedAt:0,restPauseMs:0};
 startPlayerStep();save();if(!state.calibrationActive)view='player';render();window.scrollTo(0,0);syncAwake();}
function playerSequenceFor(mode){const old=state.player;state.player={mode};const result=playerSequence(mode);state.player=old;return result;}
function startPlayerStep(){const p=state.player,cur=playerCurrent();if(!p||!cur)return;
 // Every strength set requires a brief pre-timer setup screen. Stretching starts immediately.
 p.stage=cur.phase==='main'?'prepare':'doing';
 if(cur.phase==='main'&&FitPlanPrecisionV5.calibrationStatus(state,cur.e,state.active.items[cur.index].machineId).needed){beginCalibration(cur.index);return;}
 p.startedAt=Date.now();p.paused=false;p.remaining=0;p.warned10=false;p.pausedAt=0;
 p.deadline=(p.stage==='doing'&&cur.secs)?Date.now()+cur.secs*1000:0;save();
 if(cur.phase==='main')coachSpeak(cur.title+' '+(cur.ref.warmup?'준비 세트':'본세트')+' 시작 전. 무게와 횟수를 확인하세요.');
 else coachSpeak(cur.title+' '+Math.ceil(cur.secs/60)+'분. 시작합니다.');
}
function showPlayerWarning(message){modal={type:'playerWarning',message};render();}
function startPreparedSet(){
 const p=state.player,cur=playerCurrent();if(!p||!cur||p.stage!=='prepare'||cur.phase!=='main')return;
 const e=cur.e,s=cur.ref;
 const weightRequired=!isTimed(e)&&!['body','band'].includes(e?.gear);
 const weightInput=document.getElementById('prep-weight');
 const repsInput=document.getElementById('prep-reps');
 const enteredWeight=weightRequired?Number(weightInput?.value):0;
 const reps=Number(repsInput?.value);
 if(weightRequired&&(!weightInput||weightInput.value.trim()===''||!Number.isFinite(enteredWeight)||enteredWeight<=0)){
  showPlayerWarning('무게를 설정해 주세요. 운동 시작 전에 실제 기구의 중량(kg)을 입력해야 합니다.');return;
 }
 if(!Number.isFinite(reps)||reps<=0||!Number.isInteger(reps)){
  showPlayerWarning('목표 횟수 또는 시간을 설정해 주세요.');return;
 }
 s.actualWeight=weightRequired?clamp(enteredWeight,0,1000):0;
 s.targetReps=clamp(reps,1,1000);
 // The user's selected weight is a working-set input, not a proven strength estimate.
 p.stage='doing';p.paused=false;p.startedAt=Date.now();p.remaining=0;p.warned10=false;p.pausedAt=0;
 p.deadline=cur.secs?Date.now()+s.targetReps*1000:0;
 save();initAudio();coachSpeak(cur.title+' '+(weightRequired?s.actualWeight+'킬로그램 ':'')+s.targetReps+(isTimed(e)?'초':'회')+' 시작합니다.');render();
}
function playerNext(){const p=state.player;if(!p)return;
 if(p.stage==='rest'&&p.restStartedAt){
   const prev=playerCurrent();const now=Date.now();const pauseMs=(p.restPauseMs||0)+(p.paused&&p.pausedAt?now-p.pausedAt:0);
   const actualSec=Math.max(0,Math.round((now-p.restStartedAt-pauseMs)/1000));
   if(prev?.phase==='main'){const it=state.active.items[prev.index];const set=it.sets[prev.set];set.restActualSec=Math.min(600,actualSec);if(actualSec>600)set.restOverrunSec=actualSec-600;it.restActualSec=(it.restActualSec||0)+set.restActualSec;}
   p.restStartedAt=0;p.restPauseMs=0;p.pausedAt=0;
 }
 const seq=playerSequence(p.mode);const i=seq.findIndex((x,j)=>j>p.step&&!x.ref.done);
 if(i<0){finishSegment();return;}
 const prior=p.stage==='rest'?seq[p.step]:null;
 const upcoming=seq[i];
 p.step=i;startPlayerStep();
 // The same exercise continues automatically after rest. A new exercise always waits for Start.
 if(prior&&prior.phase==='main'&&upcoming.phase==='main'&&prior.index===upcoming.index&&p.stage==='prepare'&&!state.calibrationActive){
   // Same machine continues at the weight just used; do not silently assume the pin changed.
   if(num(prior.ref.actualWeight)>0){upcoming.ref.actualWeight=prior.ref.actualWeight;upcoming.ref.targetWeight=prior.ref.actualWeight;}
   if(num(upcoming.ref.targetReps)<=0)upcoming.ref.targetReps=prior.ref.targetReps;
   p.stage='doing';p.paused=false;p.startedAt=Date.now();p.remaining=0;p.pausedAt=0;
   p.deadline=upcoming.secs?Date.now()+num(upcoming.ref.targetReps)*1000:0;
   p.autoStarted=true;
   coachSpeak(upcoming.title+' 다음 세트를 시작합니다. '+(num(upcoming.ref.actualWeight)>0?upcoming.ref.actualWeight+'킬로그램, ':'')+upcoming.ref.targetReps+'회 목표입니다.');
 }else p.autoStarted=false;
 save();render();}
function finishSegment(){const mode=state.player?.mode;state.player=null;save();beep();
 if(['all','main'].includes(mode)&&state.active&&mainCount(state.active)>0){view='finish';feedback={weight:currentWeight(),difficulty:5,pain:false,soreness:2,note:''};render();toast('오늘 운동 완료! 종료 평가를 입력하세요.');}
 else{view='work';render();toast('선택한 운동 구간을 완료했습니다.');}}
function playerComplete(){
 const p=state.player,cur=playerCurrent();if(!p||!cur)return;
 if(p.stage==='rest'){playerNext();return;}
 if(p.stage!=='doing')return;
 if(cur.phase==='main'){
  // Working sets finish with one tap. Detailed effort/technique feedback is collected at session end.
  p.stage='review';p.remaining=playerClock();p.deadline=0;p.paused=false;p.pausedAt=0;
  confirmCompletedSet(true);return;
 }
 cur.ref.done=true;if(!p._expiredAlarm)beep();p._expiredAlarm=false;save();playerNext();
}
function confirmCompletedSet(quick=false){
 const p=state.player,cur=playerCurrent();if(!p||!cur||p.stage!=='review'||cur.phase!=='main')return;
 const it=state.active.items[cur.index],s=it.sets[cur.set],e=cur.e;
 const repsField=document.getElementById('result-reps');
 const rirField=document.getElementById('result-rir');
 const reps=quick?Number(s.targetReps):Number(repsField?.value);
 if(!Number.isFinite(reps)||reps<=0||!Number.isInteger(reps)){
  showPlayerWarning('실제 수행한 횟수 또는 시간을 입력해 주세요.');return;
 }
 if(!isTimed(e)&&!['body','band'].includes(e?.gear)&&num(s.actualWeight)<=0){
  p.stage='prepare';save();render();
  showPlayerWarning('무게를 설정해 주세요.');return;
 }
 s.actualReps=clamp(reps,1,1000);
 if(FitPlan15.isUnilateral(e.id)){const left=quick?reps:Number(document.getElementById('result-left')?.value),right=quick?reps:Number(document.getElementById('result-right')?.value);
 if(!Number.isInteger(left)||left<=0||!Number.isInteger(right)||right<=0){showPlayerWarning('좌우 각각 수행한 횟수를 입력해 주세요.');return;}
 s.sideRecords={left,right};s.actualReps=Math.min(left,right);}
 s.rir=!quick&&rirField&&rirField.value!==''?clamp(num(rirField.value),0,6):null;
 s.form=quick?'uncertain':(document.getElementById('result-form')?.value||'uncertain');
 s.pain=!quick&&!!document.getElementById('result-pain')?.checked;
 s.durationSec=Math.max(1,Math.round((Date.now()-p.startedAt)/1000));
 it.durationSec=(it.durationSec||0)+s.durationSec;
 s.done=true;s.actualId=it.currentId;s.machineId=it.machineId||'default';
 if(s.pain||s.form==='poor'){
  it.halted=true;
  state.player=null;view='work';save();
  modal={type:'playerWarning',message:'통증이나 자세 불안정이 기록되어 이 운동의 남은 세트를 중단했습니다. 해당 부위가 불편하면 운동을 무리해서 이어가지 마세요. 다른 운동도 통증이 있으면 중단하고 전문가에게 확인하세요.'};render();return;
 }
 // Do not infer intra-session load changes from unassessed sets.
 save();
 const seq=playerSequence(p.mode);
 const next=seq.findIndex((x,j)=>j>p.step&&!x.ref.done);
 if(next<0){finishSegment();return;}
 const n=seq[next];
 if(cur.phase==='main'&&n.phase==='main'&&n.index===cur.index){
  const planned=num(state.active.items[cur.index].sets[cur.set]?.restSec||state.active.items[cur.index].rest,90);
  const nextExercise=next.index!==cur.index;
  p.stage='rest';p.restSeconds=FitPlanTimerV6.recommendRest({planned,goal:state.profile.goal,kind:cur.e?.kind,rir:s.rir,form:s.form,changedExercise:nextExercise,readiness:state.active.readiness||readiness});
  p.remaining=p.restSeconds;p.deadline=Date.now()+p.restSeconds*1000;
  p.restStartedAt=Date.now();p.restPauseMs=0;p.pausedAt=0;p.warned10=false;p.paused=false;
  s.restPlannedSec=p.restSeconds;save();coachSpeak('세트 완료. '+p.restSeconds+'초 휴식합니다.');render();
 }else playerNext();
}
function playerClock(){const p=state.player;if(!p)return 0;
 if(p.stage==='prepare'||p.stage==='review')return 0;
 if(p.paused)return p.remaining;
 if(p.stage==='rest'||playerCurrent()?.secs)return Math.max(0,Math.ceil((p.deadline-Date.now())/1000));
 return Math.max(0,Math.floor((Date.now()-p.startedAt)/1000));}
function pausePlayer(){const p=state.player;if(!p||['prepare','review'].includes(p.stage))return;
 const cur=playerCurrent(),timed=p.stage==='rest'||cur?.secs;
 if(!p.paused){p.remaining=playerClock();p.paused=true;p.pausedAt=Date.now();p.deadline=0;}
 else{const now=Date.now();if(p.stage==='rest'&&p.pausedAt)p.restPauseMs=(p.restPauseMs||0)+(now-p.pausedAt);
  p.paused=false;p.pausedAt=0;p.startedAt=timed?now:now-p.remaining*1000;p.deadline=timed?now+p.remaining*1000:0;}
 save();render();}
function extendRest(seconds){const p=state.player;if(!p||p.stage!=='rest')return;
 const extra=Math.round(num(seconds));if(![15,30,60].includes(extra))return;
 const remaining=p.paused?p.remaining:playerClock();if(remaining+extra>600){toast('휴식은 한 번에 최대 10분까지 설정할 수 있습니다.');return;}
 p.remaining=remaining+extra;if(!p.paused)p.deadline=Date.now()+p.remaining*1000;
 p.restSeconds+=extra;p.warned10=false;save();render();toast('휴식을 '+extra+'초 연장했습니다.');}
function timerSummary(){const a=state.active,p=state.player;if(!a||!p)return null;
 const elapsed=Math.max(0,Math.floor((Date.now()-a.startAt)/1000));
 const seq=playerSequence(p.mode);const uncompleted=seq.filter((x,i)=>i>=p.step&&!x.ref.done);
 const pending=uncompleted.reduce((total,step)=>total+(step.secs|| (step.ref.warmup?35:step.kind==='set'?45:40))+(step.phase==='main'&&!step.ref.done?num(step.rest,70):0),0);
 const eta=new Date(Date.now()+Math.max(0,pending)*1000);
 return {elapsed,eta:eta.toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit'}),remaining:Math.round(pending/60)};
}
function skipRest(){const p=state.player;if(!p||p.stage!=='rest')return;playerNext();}
function exitPlayer(){const p=state.player;if(!p)return;
 if(!p.paused){p.remaining=playerClock();p.paused=true;p.pausedAt=Date.now();p.deadline=0;}save();view='work';render();}
function resumePlayer(){if(!state.player)return;view='player';render();syncAwake();tick();}
function playerView(){const p=state.player,cur=playerCurrent();if(!p||!cur)return workView();
 const seq=playerSequence(p.mode),done=seq.filter(x=>x.ref.done).length;
 const rest=p.stage==='rest',preparing=p.stage==='prepare',reviewing=p.stage==='review',clock=playerClock(),summary=timerSummary();
 const phase={pre:'준비운동',main:'본운동',cardio:'유산소',post:'정리운동'}[cur.phase];
 const next=seq.slice(p.step+1).find(x=>!x.ref.done),isMain=cur.phase==='main';
 const it=isMain?state.active.items[cur.index]:null,e=cur.e;
 const setNumber=isMain?it.sets.slice(0,cur.set+1).filter(x=>!x.warmup).length:0;
 const setLabel=isMain?(cur.ref.warmup?'준비 세트':setNumber+'세트'):(cur.index+1)+'번째 동작';
 const weightRequired=isMain&&!isTimed(e)&&!['body','band'].includes(e?.gear);
 const weightLabel=weightRequired?(cur.ref.actualWeight>0?formatWeight(cur.ref.actualWeight)+'kg':'설정 필요'):'맨몸/시간';
 const desc=rest?'휴식 종료 시 같은 운동의 다음 세트가 자동 시작됩니다.':cur.kind==='stretch'?'타이머 종료 시 다음 동작으로 자동 이동합니다.':cur.kind==='timed'?'목표 시간 동안 자세를 유지하세요.':'완료 후 아래 버튼을 눌러 세트를 기록하세요.';
 let body='';
 if(preparing){
  // A dedicated pre-timer screen: never start a weight-bearing exercise without a chosen weight.
  body=`<div class="player-tag">세트 시작 전 설정</div><h1 class="player-title">${esc(cur.title)}</h1>
   <div class="player-count">${cur.index+1}/${state.active.items.length} · ${setLabel}</div>
   <div class="player-setup-card">
   ${weightRequired?`<div class="field"><label>사용하는 기구</label><select onchange="Fit.chooseMachine(${cur.index},this.value)">${FitPlanAdvanced.machineRecord(state,e).variants.map(v=>`<option value="${v.id}" ${it.machineId===v.id?'selected':''}>${esc(v.name)}</option>`).join('')}</select></div>`:''}
   ${weightRequired?`<label class="player-setup-field">실제 사용할 무게 (kg)<input id="prep-weight" type="number" inputmode="decimal" min="0.1" max="1000" step="0.5" placeholder="무게 필수 입력" value="${num(cur.ref.actualWeight)>0?cur.ref.actualWeight:''}"></label>`:``}
   <label class="player-setup-field">${isTimed(e)?'목표 시간 (초)':'목표 반복 횟수 (회)'}<input id="prep-reps" type="number" inputmode="numeric" min="1" max="1000" step="1" value="${num(cur.ref.targetReps)||''}"></label>
   ${cur.ref.requiresCalibration?`<div class="callout calibration-guide"><strong>첫 중량 측정</strong><div>① 기구를 가장 가벼운 단계에 맞춰 자세를 확인하세요.</div><div>② 실제 사용할 무게를 입력하세요. 빈칸에서는 시작할 수 없습니다.</div><div>③ 운동 후 수행한 횟수와 반복 여유를 기록하면 다음 세트를 조절합니다.</div><small>기구의 무게 핀은 직접 바꿔야 합니다.</small></div>`:''}
   <button class="btn primary full mt12" onclick="Fit.startPreparedSet()">▶ 설정 완료 · 운동 시작</button></div>`;
 }else if(reviewing){
  body=`<div class="player-tag">세트 저장 중</div>`;
 }else{
  const mainSets=isMain?it.sets.filter(x=>!x.warmup):[];
  const activeSetIndex=isMain?mainSets.indexOf(cur.ref):-1;
  const setDots=isMain?`<div class="mint-rounds" aria-label="세트 진행">${mainSets.map((x,j)=>`<span class="mint-round ${x.done?'done':j===activeSetIndex?'current':''}">${x.done?'✓':j+1}</span>`).join('')}</div>`:'';
  const timeBase=rest?Math.max(1,num(p.restSeconds,90)):Math.max(1,num(cur.secs,0));
  const progressValue=rest||cur.secs?Math.max(0,Math.min(1,clock/timeBase)):0;
  const ringLength=2*Math.PI*108;
  const ringDash=ringLength*progressValue;
  const ring=rest||cur.secs?`<div class="mint-ring"><svg viewBox="0 0 250 250" aria-hidden="true"><circle cx="125" cy="125" r="108" class="mint-track"/><circle id="mint-progress" cx="125" cy="125" r="108" class="mint-arc" stroke-dasharray="${ringDash} ${ringLength}" transform="rotate(-90 125 125)"/></svg><div class="mint-ring-core"><div class="mint-clock-label">${rest?'휴식 남은 시간':'운동 경과'}</div><div class="mint-ring-clock" id="player-clock">${shortDuration(clock)}</div></div></div>`:
  `<div class="mint-ring"><div class="mint-ring-core"><div class="mint-clock-label">운동 경과</div><div class="mint-ring-clock" id="player-clock">${shortDuration(clock)}</div></div></div>`;
  body=`<div class="mint-player streamlined-player">
   <h1 class="player-title">${esc(cur.title)}</h1>
   ${ring}
   <div class="mint-target"><strong>${weightLabel}</strong><span>${cur.ref.targetReps}${isTimed(e)?'초':'회'}</span></div>
   ${rest?`<div class="mint-rest-actions"><button onclick="Fit.extendRest(30)">휴식 +30초</button></div>`:''}
   ${!rest&&isMain?`<button class="btn primary full mt12" onclick="Fit.playerComplete()">✓ 세트 완료</button>`:''}
   ${rest?'':!isMain?`<button class="btn primary full mt12" onclick="Fit.playerComplete()">동작 완료</button>`:''}
   <div class="mint-controlbar"><button class="mint-outline" onclick="Fit.pausePlayer()">${p.paused?'▶ 계속':'Ⅱ 일시정지'}</button>
   ${rest?`<button class="mint-outline" onclick="Fit.skipRest()">휴식 건너뛰기</button>`:''}</div></div>`;
 }
 return `<div class="player-page"><header class="player-head"><div><div class="eyebrow">${phase}</div><strong>${rest?'휴식 중':preparing?'운동 준비':'운동 중'}</strong></div><button class="player-close" onclick="Fit.exitPlayer()">✕</button></header>
 <div class="player-progress"><div style="width:${Math.round(done/Math.max(1,seq.length)*100)}%"></div></div>
 <div class="timer-session-stats"><span>전체 경과 <b id="session-elapsed">${shortDuration(summary?.elapsed||0)}</b></span></div>
 <div class="player-body">${body}</div>
 </div>`;
}
// Countdown notifications use wall-clock seconds and deduplicate each second.
// After foregrounding, missed countdown seconds are NOT replayed in a burst.
function countdownCue(kind,deadline,remaining){
 const key=kind+':'+deadline+':'+remaining;
 if(remaining<1||remaining>5)return;
 if(kind==='calibration'){
   if(lastCalibrationCue===key)return;
   lastCalibrationCue=key;
 }else{
   if(lastPlayerCue===key)return;
   lastPlayerCue=key;
 }
 if(state.settings.preAlert)beep('countdown');
}
function tick(){
 if(view==='calibration'){
   const c=state.calibrationActive,el=document.getElementById('calibration-clock');
   if(c&&el){
     if(c.phase==='rest'){
       const remaining=Math.max(0,Math.ceil((c.restUntil-Date.now())/1000));
       el.textContent=shortDuration(remaining);
       if(remaining>0)countdownCue('calibration',c.restUntil,remaining);
       else if(c.restUntil&&!c.restAlarmPlayed){c.restAlarmPlayed=true;beep('end');save();}
     }else if(c.phase==='perform')el.textContent=shortDuration((Date.now()-c.startedTrialAt)/1000);
   }
   return;
 }
 const p=state.player;if(!p||view!=='player')return;
 const elapsed=document.getElementById('session-elapsed');if(elapsed&&state.active)elapsed.textContent=shortDuration(Math.max(0,Math.floor((Date.now()-state.active.startAt)/1000)));
 if(p.paused||!['doing','rest'].includes(p.stage))return;
 const remaining=playerClock();
 const countingDown=p.stage==='rest'||!!playerCurrent()?.secs;
 if(countingDown&&p.deadline&&Date.now()>=p.deadline){
   // One prominent final alarm at zero, including when the next set auto-starts.
   beep('end');
   if(p.stage==='rest'){
     coachSpeak('휴식이 끝났습니다.');playerNext();
   }else{p._expiredAlarm=true;playerComplete();}
   return;
 }
 if(countingDown&&p.deadline)countdownCue('player-'+p.stage,p.deadline,remaining);
 const el=document.getElementById('player-clock');if(el)el.textContent=shortDuration(remaining);
 const arc=document.getElementById('mint-progress');
 if(arc){const duration=Math.max(1,num(p.stage==='rest'?p.restSeconds:playerCurrent()?.secs,90));
 const circumference=2*Math.PI*108;const fraction=Math.max(0,Math.min(1,remaining/duration));
 arc.setAttribute('stroke-dasharray',(circumference*fraction)+' '+circumference);}
}
setInterval(tick,400);
function coachSpeak(message){
 if(state.settings.voice!=='on')return false;
 if(!('speechSynthesis' in window)||typeof window.SpeechSynthesisUtterance!=='function')return false;
 try{const synth=window.speechSynthesis;synth.cancel();const utter=new SpeechSynthesisUtterance(String(message));utter.lang='ko-KR';utter.rate=clamp(num(state.settings.voiceRate,1),.7,1.3);utter.volume=.9;
 synth.speak(utter);return true;}catch(e){console.warn('TTS unavailable',e);return false;}
}
function voiceTest(){const ok=coachSpeak('핏플랜 음성 코치가 준비되었습니다.');toast(ok?'음성 재생을 요청했습니다. 소리가 나오는지 확인해 주세요.':'이 기기에서는 웹 음성 안내가 지원되지 않습니다. 타이머와 알림은 사용 가능합니다.');}
function cameraGuide(){cameraStatus='';cameraPreview='';modal={type:'camera'};render();}
function captureMachinePhoto(el){const f=el.files&&el.files[0];if(!f){cameraStatus='선택한 사진이 없습니다.';return;}if(!f.type.startsWith('image/')){cameraStatus='이미지 파일만 선택하세요.';return;}
 cameraStatus='사진을 불러왔습니다. 기구는 아래 목록에서 직접 확인해 주세요.';
 const reader=new FileReader();reader.onload=()=>{cameraPreview=typeof reader.result==='string'?reader.result:'';render();};reader.onerror=()=>{cameraStatus='사진을 열지 못했습니다. 아래 목록에서 기구를 선택하세요.';render();};reader.readAsDataURL(f);
}
function confirmCameraMachine(){const id=document.getElementById('camera-choice')?.value;const e=exercise(id);if(e){cameraPreview='';modal={type:'guide',e};render();}}
function initAudio(){try{const A=window.AudioContext||window.webkitAudioContext;if(A){if(!audioCtx)audioCtx=new A();if(audioCtx.state==='suspended')audioCtx.resume();}}catch(e){}}
// Short countdown tick (5,4,3,2,1) and distinct, louder end-of-timer alarm.
// Keep the existing settings (sound / vibration / both / off).
function beep(kind=false){
 const alert=state.settings.alert;if(alert==='off')return;
 const finalAlarm=kind==='end',shortCue=kind===true||kind==='countdown';
 if(alert==='sound'||alert==='both'){
   try{
     initAudio();if(audioCtx){
       const now=audioCtx.currentTime+0.012;
       const tones=finalAlarm?[{at:0,d:.20,f:980},{at:.25,d:.20,f:1180},{at:.51,d:.36,f:1380}]:
         [{at:0,d:shortCue?.11:.20,f:shortCue?740:880}];
       tones.forEach(t=>{
         const osc=audioCtx.createOscillator(),gain=audioCtx.createGain();
         osc.type=finalAlarm?'triangle':'sine';osc.frequency.setValueAtTime(t.f,now+t.at);
         const volume=finalAlarm?.26:shortCue?.075:.11;
         gain.gain.setValueAtTime(.0001,now+t.at);
         gain.gain.exponentialRampToValueAtTime(volume,now+t.at+.012);
         gain.gain.exponentialRampToValueAtTime(.0001,now+t.at+t.d);
         osc.connect(gain);gain.connect(audioCtx.destination);
         osc.start(now+t.at);osc.stop(now+t.at+t.d+.01);
       });
     }
   }catch(e){console.warn('audio cue unavailable',e);}
 }
 if(alert==='vibrate'||alert==='both'){
   try{if(navigator.vibrate)navigator.vibrate(finalAlarm?[220,100,220,100,360]:shortCue?65:[160,90,160]);}catch(e){}
 }
}
async function syncAwake(){try{if(!state.settings.keepAwake||view!=='player'){if(wakeHandle){await wakeHandle.release();wakeHandle=null;}return;}
 if(navigator.wakeLock&&!wakeHandle&&document.visibilityState==='visible'){wakeHandle=await navigator.wakeLock.request('screen');wakeHandle.addEventListener('release',()=>{wakeHandle=null;});}}
 catch(e){console.log('화면 유지가 이 WebView에서 지원되지 않을 수 있습니다.',e);}}
// Wall-clock deadlines persist while the view is hidden; WebView can suspend JS callbacks.
// On return, immediately reconcile expired countdowns. Audible/vibration alerts while
// fully backgrounded are NOT guaranteed without a native foreground service.
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden'){save();}else{syncAwake();tick();}});
window.addEventListener('pageshow',()=>{if(state.player&&view==='player')tick();});
function svgGraph(a,title,unit){if(!a.length)return '<div class="empty">아직 기록이 없습니다. 운동 완료 후 그래프가 생성됩니다.</div>';
 const vals=a.map(x=>num(x.v)),min=Math.min(...vals),max=Math.max(...vals),gap=Math.max(1,max-min),minY=min-gap*.2,maxY=max+gap*.2;
 const pt=a.map((x,i)=>({x:25+(a.length===1?.5:i/(a.length-1))*300,y:146-(num(x.v)-minY)/(maxY-minY)*112}));
 return `<div class="card chart-card"><div class="row"><strong>${title}</strong><span class="pill">최근 ${a.length}회</span></div><svg viewBox="0 0 350 180" aria-label="${esc(title)} 변화 그래프" role="img"><line x1="25" y1="145" x2="325" y2="145" stroke="#415467"/><line x1="25" y1="85" x2="325" y2="85" stroke="#344457" stroke-dasharray="3 5"/><line x1="25" y1="25" x2="325" y2="25" stroke="#344457" stroke-dasharray="3 5"/><polyline points="${pt.map(p=>`${p.x},${p.y}`).join(' ')}" stroke="#6bdbaa" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>${pt.map((p,i)=>`<circle r="3.7" cx="${p.x}" cy="${p.y}" fill="#aaf8dd"/><text x="${p.x}" y="${Math.max(13,p.y-10)}" fill="#b8f4dc" text-anchor="middle" font-size="10">${esc(a[i].v)}${unit}</text>`).join('')}<text x="25" y="172" font-size="10" fill="#aabbcd">${esc(a[0].d)}</text><text x="325" y="172" text-anchor="end" font-size="10" fill="#aabbcd">${esc(a[a.length-1].d)}</text></svg></div>`;}
function dateLabel(s){return esc((s.date||'').slice(5)||'날짜 미상');}

function advancedStateInsights(){const m=FitPlanAdvanced.metrics(state.history),pace=FitPlanAdvanced.pace(state.history),fatigue=FitPlanAdvanced.excessiveFatigue(state.history);
 const balance=FitPlanAdvanced.weeklyMuscles(state,CATALOG).filter(x=>['가슴','등','어깨','하체','뒤허벅지','둔근'].includes(x.muscle));
 const responses=FitPlanAdvanced.personalResponse(state.history,CATALOG);
 const options=CATALOG.filter(e=>['chest_press','lat_pulldown','leg_press','seated_row','shoulder_press','biceps_curl'].includes(e.id));
 const forecasts=options.map(e=>{const rec=FitPlanAdvanced.machineRecord(state,e);return {e,f:FitPlanAdvanced.forecast(state.history,e.id,rec.active)};});
 return `<div class="sectionhead"><h2>운동 효율·회복 분석</h2></div><div class="card"><div class="grid2"><div class="stat"><div class="tiny muted">목표 반복 달성률</div><strong>${m.completion===null?'측정 중':m.completion+'%'}</strong></div><div class="stat"><div class="tiny muted">시간당 완료 본세트</div><strong>${m.setsPerHour===null?'측정 중':m.setsPerHour+'세트'}</strong></div></div>
 <p class="sub mt8">시간당 세트는 운동 기록 관리 지표이며 실제 근육 성장 효율을 뜻하지 않습니다. 시간 예측 학습: ${pace.samples}회 · 보정 ×${pace.factor.toFixed(2)}</p>
 <p class="sub mt8">회복 평가: ${esc(fatigue.reason)}</p></div>
 <div class="sectionhead"><h2>4주 평균 근육별 운동량</h2></div><div class="card">${balance.map(x=>`<div class="barrow"><span>${x.muscle}</span><div class="bartrack"><div class="barfill" style="width:${Math.round(limPercent(x.ratio)*100)}%"></div></div><span>${x.actual.toFixed(1)}/${x.target}</span></div>`).join('')}
 <p class="sub mt8">숫자는 운동 종류에 따른 추정 세트 환산량/주이며 근육 크기 측정값이 아닙니다. 기록이 적으면 비교 정확도가 낮습니다.</p></div>
 <div class="sectionhead"><h2>개인별 반응 학습</h2></div><div class="card">${responses.filter(x=>x.samples>0).slice(0,7).map(x=>`<div class="subhead"><strong>${x.muscle}</strong> · ${x.samples}세트 · ${x.sessions}회 운동<div class="sub">${esc(x.proposal)}</div></div>`).join('')||'<p class="sub">운동 결과가 누적되면 개인별 반응이 표시됩니다.</p>'}</div>
 <div class="sectionhead"><h2>4주 수행 추세 범위</h2></div><div class="card">${forecasts.map(({e,f})=>`<div class="subhead"><strong>${esc(e.n)}</strong><div class="sub">${f.ready?`참고 범위 ${f.lower}~${f.upper}kg · ${f.samples}일 기록`:`${esc(f.reason)}`}</div></div>`).join('')}
 <p class="sub mt8">추세 기반 탐색적 예측이며 근육량·최대 근력·미래 성과를 보장하지 않습니다. 동일 기구의 기록만 사용합니다.</p></div>`;
}
function limPercent(x){return Math.max(0,Math.min(1,Number(x)||0));}
function extendedStateInsights(){const h=state.history,asym=FitPlan15.asymmetry(h),ad=FitPlan15.adherence(h,state.profile);
 const trained=CATALOG.filter(e=>SIMPLE_ORDER.has(e.id)).map(e=>({e,c:FitPlan15.confidence(h,e.id)})).filter(x=>x.c.samples>0).sort((a,b)=>b.c.samples-a.c.samples).slice(0,5);
 return `<div class="sectionhead"><h2>장기 목표 · 처방 신뢰도</h2></div><div class="card"><div class="row"><strong>최근 4주 운동 수행</strong><span class="pill">${ad.done}/${ad.expected}회</span></div><div class="progressrail"><div style="width:${Math.round(ad.ratio*100)}%"></div></div><p class="sub">주 ${state.profile.days}일 기준 · ${num(state.settings.programWeeks,8)}주 장기 계획. 출석률은 신체 성장률과 다릅니다.</p><div class="subhead"><strong>운동별 처방 신뢰도</strong>${trained.length?trained.map(x=>`<div class="row mt8"><span>${esc(x.e.n)}</span><span class="pill">${esc(x.c.level)} (${x.c.samples}회)</span></div>`).join(''):'<p class="sub">아직 비교 가능한 기록이 없습니다.</p>'}</div><div class="subhead"><strong>좌우 수행 비교</strong><p class="sub">${asym.samples?`좌우 기록 ${asym.samples}세트 · 15% 초과 차이 ${asym.uneven}세트`: '좌우 개별 세트를 기록하면 추이가 나타납니다.'}</p>${asym.uneven?'<p class="sub">반복적인 차이가 있으면 무리하게 중량을 높이지 말고 자세를 점검하세요.</p>':''}</div></div>`;}
function v5MuscleQuality(){
 const d={};for(const session of state.history.slice(-20))for(const it of session.items||[])for(const set of it.sets||[]){
  if(!set.done||set.warmup)continue;
  const ex=exercise(set.actualId||it.currentId||it.eid);if(!ex)continue;
  const a=d[ex.m]||(d[ex.m]={count:0,ok:0,pain:0});a.count++;
  if(set.form==='good'&&!set.pain&&num(set.actualReps)>=num(set.targetReps))a.ok++;
  if(set.pain||set.form==='poor')a.pain++;
 }
 const rows=Object.entries(d).filter(([k,v])=>v.count>=2).sort((a,b)=>b[1].count-a[1].count).slice(0,8);
 return `<div class="sectionhead"><h2>V5 · 부위별 수행 품질</h2></div><div class="card">${rows.length?rows.map(([m,v])=>`<div class="volume-row"><span>${esc(m)}</span><span class="sub">기록 ${v.count}세트 · 안정적 목표 달성 ${Math.round(100*v.ok/v.count)}%${v.pain?' · 통증/자세 문제 '+v.pain+'회':''}</span></div>`).join(''):'<p class="sub">세트별 자세와 실제 반복을 기록하면 부위별 품질 변화가 표시됩니다.</p>'}
 <p class="sub mt8">기록한 자세·목표 달성 여부를 보여주는 지표입니다. 카메라 분석이나 실제 근육 성장 측정은 아닙니다.</p></div>`;
}
function stateView(){const hist=state.history,b=trainingBalance(),last=hist[hist.length-1],weights=hist.filter(s=>num(s.feedback?.weight||s.bodyweight)>0).slice(-12).map(s=>({d:dateLabel(s),v:num(s.feedback?.weight||s.bodyweight)}));
 const diffs=hist.slice(-12).map(s=>({d:dateLabel(s),v:num(s.feedback?.difficulty||s.difficulty)}));
 const durations=hist.slice(-12).map(s=>({d:dateLabel(s),v:num(s.durationMin)}));
 const sets=hist.slice(-12).map(s=>({d:dateLabel(s),v:mainCount(s)}));
 const data=chartKey==='weight'?weights:chartKey==='difficulty'?diffs:chartKey==='duration'?durations:sets;
 const unit=chartKey==='weight'?'kg':chartKey==='difficulty'?'점':chartKey==='duration'?'분':'세트';
 const name={weight:'몸무게 변화',difficulty:'운동 체감 난이도',duration:'운동 소요 시간',sets:'완료 본세트'}[chartKey];
 const max=Math.max(1,...PRIMARY.map(g=>b[g].sets));const weak=PRIMARY.filter(g=>b[g].attempts>=4&&b[g].success/b[g].attempts<.6);
 return `${head()}<div class="eyebrow">MY TRAINING STATUS</div><h1>내 몸 상태</h1><p class="sub">운동 기록과 신체 변화를 분석하고 다음 루틴을 계속 조정합니다.</p>
 <div class="grid2 mt16"><div class="stat"><div class="tiny muted">최근 몸무게</div><strong>${currentWeight()}kg</strong></div><div class="stat"><div class="tiny muted">운동 완료</div><strong>${hist.length}회</strong></div></div>
 <div class="sectionhead"><h2>나의 변화 그래프</h2></div><div class="seg">${[['weight','체중'],['difficulty','난이도'],['duration','운동 시간'],['sets','본세트']].map(([id,label])=>`<button class="${chartKey===id?'active':''}" onclick="Fit.graph('${id}')">${label}</button>`).join('')}</div>
 ${svgGraph(data,name,unit)}<div class="sectionhead"><h2>부위별 최근 운동량</h2></div><div class="card">${PRIMARY.map(g=>`<div class="barrow"><span>${g}</span><div class="bartrack"><div class="barfill" style="width:${Math.round(b[g].sets/max*100)}%"></div></div><span>${b[g].sets}세트</span></div>`).join('')}</div>
 ${state.lastReview?.changed?.length?`<div class="sectionhead"><h2>다음 운동 자동 조정</h2></div><div class="card">${state.lastReview.changed.map(z=>`<div class="subhead"><strong>${esc(z.name)}</strong><div class="sub">${z.from===null?'측정 전':z.from+'kg'} → ${z.to===null?'중단/측정 필요':z.to+'kg'} · 기록 신뢰도 ${esc(z.confidence)}</div><p class="sub">${esc(z.reason)}</p></div>`).join('')}</div>`:''}
 <div class="sectionhead"><h2>FitPlan 자동 코치 분석</h2></div><div class="card"><div class="eyebrow">TRAINING INTELLIGENCE</div>${hist.length<3?`<p>운동 기록이 더 쌓이면 부위별 훈련량과 목표 달성률을 비교합니다. 앞으로 ${3-hist.length}회 정도의 기초 기록이 유용합니다.</p>`:weak.length?`<p><strong>${weak.slice(0,3).join(' · ')}</strong> 부위는 최근 목표 반복 달성률이 낮습니다.</p><p class="sub mt8">근력 부족이라고 단정하지 않고, 피로와 회복·운동 종목 난도를 함께 검토합니다.</p>`:`<p>현재 기록에서 반복적인 목표 미달 부위는 뚜렷하지 않습니다. 집중 부위와 주간 운동량의 균형을 유지합니다.</p>`}
 ${last?`<p class="sub mt8">최근 운동: ${esc(last.splitName)} · 난이도 ${last.feedback?.difficulty||last.difficulty}/10</p>`:''}</div>
 ${cycleWidget()}${advancedStateInsights()}${extendedStateInsights()}${v5MuscleQuality()}
 <div class="callout">체중은 운동 직후 수분 변화로 달라질 수 있습니다. 가능하면 같은 시간대·조건에서 측정한 장기 추세를 참고하세요.</div>`;}
function historyView(){const hist=state.history.slice().reverse();return `${head()}<div class="eyebrow">HISTORY</div><h1>운동 기록</h1><p class="sub">오프라인 저장 · 완료한 세트만 다음 운동 처방에 활용</p>
 <div class="mt16">${hist.length?hist.map((s,i)=>{const sets=s.items.reduce((n,it)=>n+workoutSets(it).filter(x=>x.done).length,0),vol=s.items.reduce((n,it)=>n+workoutSets(it).filter(x=>x.done).reduce((sum,x)=>sum+num(x.actualWeight)*num(x.actualReps),0),0);
 return `<div class="card history-card"><div class="row"><div><div class="eyebrow">${dateLabel(s)}</div><h2>${esc(s.splitName)}</h2></div><span class="pill">${s.durationMin}분</span></div><div class="grid3 mt12"><div><span class="tiny muted">본세트</span><strong>${sets}</strong></div><div><span class="tiny muted">운동량</span><strong>${Math.round(vol)}kg</strong></div><div><span class="tiny muted">난이도</span><strong>${num(s.feedback?.difficulty||s.difficulty)}/10</strong></div></div><button class="btn tiny outline mt12" onclick="Fit.historyDetail(${i})">운동별 상세 기록 보기 →</button></div>`;}).join(''):'<div class="empty">첫 운동을 저장하면 이곳에 기록이 쌓입니다.</div>'}</div>`;}
function historyDetail(index){const s=state.history.slice().reverse()[index];if(!s)return;modal={type:'history',s};render();}
function settingsView(){const p=state.profile;return `${head()}<div class="eyebrow">SETTINGS</div><h1>FitPlan 설정</h1>
 <div class="card"><h2>내 운동 프로필</h2><div class="tile"><div class="txt"><strong>운동 목표</strong><div class="sub">${{hypertrophy:'근육량 증가',strength:'근력 향상',fitness:'건강·체력',fatloss:'체지방 감량'}[p.goal]} · ${esc(p.focus.join(', '))}</div></div></div>
 <div class="tile"><div class="txt"><strong>기본 계획</strong><div class="sub">주 ${p.days}일 · ${p.duration}분 · ${esc(splitProgram().label)}</div></div></div><div class="tile"><div class="txt"><strong>운동 수준</strong><div class="sub">${levels[clamp(num(p.level),0,3)]} · 목표에 맞춰 분할 자동 선정</div></div></div>
 <button class="btn secondary full mt12" onclick="Fit.editProfile()">프로필 다시 설정</button></div>
 <div class="sectionhead"><h2>실행 설정</h2></div><div class="card"><div class="field"><label>타이머 종료 알림</label><select onchange="Fit.alert(this.value)">${[['both','진동 + 소리'],['vibrate','진동만'],['sound','소리만'],['off','알림 끄기']].map(([a,b])=>`<option value="${a}" ${state.settings.alert===a?'selected':''}>${b}</option>`).join('')}</select></div>
 <div class="tile"><div class="txt"><strong>종료 5초 전부터 매초 알림</strong><div class="sub">5·4·3·2·1초 짧은 알림 · 종료 시 큰 알림</div></div><input class="toggle" type="checkbox" ${state.settings.preAlert?'checked':''} onchange="Fit.preAlert(this.checked)"></div>
 <div class="tile"><div class="txt"><strong>운동 중 화면 항상 켜기</strong><div class="sub">기기 WebView 지원 시 화면 자동 꺼짐 방지</div></div><input class="toggle" type="checkbox" ${state.settings.keepAwake?'checked':''} onchange="Fit.awake(this.checked)"></div><p class="sub mt8">화면을 껐다 켜도 실제 시각으로 남은 시간을 복원합니다. 다만 화면이 꺼져 있거나 앱이 백그라운드에 있으면 소리·진동 알림이 울리지 않을 수 있습니다. 확실한 백그라운드 알림에는 네이티브 서비스가 필요합니다.</p></div>
 <div class="sectionhead"><h2>음성 코치 · 장기 계획</h2></div><div class="card"><div class="field"><label>한국어 음성 안내</label><select onchange="Fit.voice(this.value)"><option value="on" ${state.settings.voice==='on'?'selected':''}>사용 (지원되는 기기)</option><option value="off" ${state.settings.voice==='off'?'selected':''}>사용 안 함</option></select><button class="btn secondary full mt8" onclick="Fit.voiceTest()">▶ 음성 테스트</button><p class="sub">Android WebView에서 TTS를 지원하지 않을 경우 음성 안내가 나오지 않을 수 있습니다.</p></div><div class="field"><label>자동 장기 계획 기간</label><select onchange="Fit.programWeeks(this.value)">${[4,8,12].map(w=>`<option value="${w}" ${state.settings.programWeeks===w?'selected':''}>${w}주</option>`).join('')}</select></div></div>
 <div class="sectionhead"><h2>GitHub 업데이트</h2></div><div class="card"><div class="field"><label>배포 저장소 (owner/repository)</label><input id="github-repo" type="text" placeholder="ffast112-ff/cam112" value="${esc(state.settings.githubRepo||'')}"><button class="btn secondary full mt8" onclick="Fit.githubRepo(document.getElementById('github-repo').value)">저장소 저장</button></div><p class="sub mt8">현재 ${APP_VERSION} · ${esc(updateStatus)}</p><button class="btn outline full mt8" onclick="Fit.checkUpdate()">지금 버전 확인</button></div>
 <div class="sectionhead"><h2>헬스장 기구 기록</h2></div><div class="card"><button class="btn outline full" onclick="Fit.cameraGuide()">▣ 사진 촬영·기구 선택 안내 (시험 기능)</button><p class="sub">같은 운동이라도 서로 다른 머신의 중량은 별도 추적합니다. 자리·손잡이 위치와 증량 단위도 기록하세요.</p><button class="btn primary full mt12" onclick="Fit.go('machines')">내 기구 프로필 관리 →</button></div>
 <div class="sectionhead"><h2>기록 백업·복원</h2></div><div class="card"><p class="sub">기록은 앱 저장공간에 저장됩니다. 앱 삭제·데이터 초기화 전에 백업을 외부에 복사하세요.</p><button class="btn outline full mt12" onclick="Fit.backup()">전체 데이터 백업 보기</button><button class="btn secondary full mt8" onclick="Fit.restoreDialog()">백업 데이터 복원</button><button class="btn danger full mt12" onclick="Fit.resetDialog()">모든 기록 초기화</button></div>
 <p class="tiny muted mt16">운동 중 통증이나 자세 불안정이 생기면 중단하세요.</p>`;}
function modalView(){if(!modal)return'';
 let content='';
 if(modal.type==='guide'){const e=modal.e,practice=FitPlan15.practiceCount(state.history,e.id),steps=FitPlanPrecisionV5.stepsFor(e);content=`<div class="eyebrow">운동 방법 · ${esc(e.m)}</div><h2>${esc(e.n)}</h2><div class="callout">${practice>=6?'숙련 기록이 있어 핵심만 안내합니다. 언제든 상세 설명을 확인할 수 있습니다.':'처음이라면 다음 순서를 차례대로 따라 하세요.'}</div><ol class="guide-steps">${(practice>=6?steps.slice(0,2):steps).map(x=>`<li>${esc(x)}</li>`).join('')}</ol><div class="callout">${esc(e.tips)}</div><div class="meta-grid"><div><span>운동 패턴</span><strong>${esc(PATTERN_NAME[e.pattern]||e.pattern)}</strong></div><div><span>필요 장비</span><strong>${esc(e.gear)}</strong></div></div><p class="sub mt12">중량은 안전하게 통제할 수 있는 범위로 조정하고, 통증이 나면 중단하세요.</p><button class="btn primary full mt12" onclick="Fit.video('${esc(e.en)}')">▷ 자세 영상 온라인 검색</button>`;}
 else if(modal.type==='stretch'){const s=modal.e;content=`<div class="eyebrow">스트레칭 안내</div><h2>${esc(s.n)}</h2><div class="callout">${esc(s.tips)}</div><p class="sub">무리하지 않는 가동 범위에서 천천히 진행하세요.</p><button class="btn primary full mt12" onclick="Fit.video('${esc(s.en)}')">▷ 스트레칭 영상 온라인 검색</button>`;}
 else if(modal.type==='camera'){content=`<h2>기구 사진으로 확인</h2><p class="sub">촬영 기능은 기기 지원 여부에 따라 다릅니다. 현재 버전은 사진의 기구를 AI가 자동 판독하지 않습니다. 운동 이름을 직접 선택해 정확히 확인하세요.</p><input type="file" accept="image/*" capture="environment" onchange="Fit.captureMachinePhoto(this)"><p class="sub mt8">${esc(cameraStatus||'사진을 선택하거나 아래 목록에서 기구를 골라주세요.')}</p>${cameraPreview?`<img alt="기구 촬영 미리보기" src="${cameraPreview}" style="max-width:100%;max-height:140px;border-radius:12px">`:''}<div class="field"><label>운동기구 직접 확인</label><select id="camera-choice">${CATALOG.filter(e=>SIMPLE_ORDER.has(e.id)&&e.gear==='machine').map(e=>`<option value="${e.id}">${esc(e.n)}</option>`).join('')}</select></div><button class="btn primary full" onclick="Fit.confirmCameraMachine()">기구 사용법 확인 →</button>`;}
 else if(modal.type==='machineChoose'){const {index,e,rec}=modal;content=`<h2>${esc(e.n)} · 기구 선택</h2><p class="sub">기구별 중량은 별도로 학습합니다. 이미 체크한 세트는 유지됩니다.</p>${rec.variants.map(v=>`<button class="alt-choice" onclick="Fit.selectMachine(${index},'${v.id}')"><strong>${esc(v.name)}</strong><span>${v.increment}kg 단위 · ${esc(v.seat||'좌석 미기록')}</span></button>`).join('')}<button class="btn secondary full mt12" onclick="Fit.go('machines')">새 기구 등록</button>`;}
 else if(modal.type==='alternatives'){content=`<div class="eyebrow">기구 사용 중 · 자동 대체</div><h2>비슷한 운동으로 교체</h2><p class="sub">주동근과 움직임 패턴이 유사한 운동을 추천합니다. 기존 완료 세트는 유지됩니다.</p>${modal.options.length?modal.options.map(e=>`<button class="alt-choice" onclick="Fit.replace(${modal.index},'${e.id}')"><strong>${esc(e.n)}</strong><span>${esc(e.m)} · ${esc(e.gear)}</span></button>`).join(''):'<div class="callout">사용할 수 있는 비슷한 기구가 없습니다. 다른 장비를 선택하거나 이 운동은 건너뛰세요.</div>'}`;}
 else if(modal.type==='program'){const p=modal.program;content=`<h2>${state.cycle?.number||1}차 · ${num(state.settings.programWeeks,8)}주 자동 운동 프로그램</h2><p class="sub">선정 분할 ${esc(p.splitLabel)} · 전체 계획을 세운 뒤 매 운동일 실제 기록·컨디션으로 다시 계산합니다.</p>
 <div class="callout">${esc(p.stability||'장기적인 성과가 확인될 때 분할을 재평가합니다.')}</div>
 <div class="subhead"><strong>분할별 예상 적합성</strong>${(p.candidates||[]).map(z=>`<div class="row mt8"><span>${esc(z.label)}</span><strong>${z.unavailable?'부적합':Number(z.score).toFixed(1)+'점'}</strong></div>`).join('')}</div>
 ${p.calendar.map(w=>`<details class="v4-details" ${w.week===1?'open':''}><summary>${w.week}주차 · ${esc(w.phase)} ${w.review?'· 점검':''}</summary><p class="sub mt8">${esc(w.guidance)}</p><div class="sub">${w.sessions.map(s=>esc(s.name)).join(' → ')}</div></details>`).join('')}
 <p class="sub mt12">${(p.notes||[]).map(esc).join(' ')}</p>`;}
 else if(modal.type==='update'){content=`<div class="eyebrow">GitHub 업데이트</div><h2>새 버전 ${esc(modal.version)} 출시</h2><p class="sub mt8">현재 버전 ${APP_VERSION} · 다운로드 후 Android 설치 승인이 필요합니다.</p>${modal.notes?`<div class="callout">${esc(modal.notes)}</div>`:''}<button class="btn primary full mt12" onclick="Fit.openUpdate()">GitHub에서 업데이트 받기</button><button class="btn secondary full mt8" onclick="Fit.closeModal()">이번 실행에서는 취소</button><p class="sub mt8">취소해도 다음 앱 실행 때 최신 버전을 다시 확인합니다.</p>`;}
 else if(modal.type==='history'){const s=modal.s;content=`<div class="eyebrow">${dateLabel(s)} · ${s.durationMin}분</div><h2>${esc(s.splitName)}</h2>${(s.items||[]).map(it=>`<div class="subhead"><strong>${esc(exercise(it.eid)?.n||it.eid)}</strong><div class="sub">${workoutSets(it).map(z=>`${z.done?'✓':'○'} ${num(z.actualWeight)}kg × ${num(z.actualReps)}${isTimed(exercise(it.eid))?'초':'회'}`).join(' · ')}</div></div>`).join('')}`;}
 else if(modal.type==='backup'){content=`<h2>전체 데이터 백업</h2><p class="sub">아래 내용을 전부 복사해 안전한 곳에 저장하세요. 개인 운동 기록이 포함됩니다.</p><textarea readonly id="backup-area" rows="12">${esc(JSON.stringify(state))}</textarea><button class="btn primary full mt12" onclick="Fit.copyBackup()">백업 내용 복사</button>`;}
 else if(modal.type==='restore'){content=`<h2>백업 복원</h2><p class="sub">과거 FitPlan에서 저장한 JSON 백업을 붙여넣으세요. 기존 기록을 교체합니다.</p><textarea id="restore-area" rows="10" placeholder="{ ... }"></textarea><button class="btn primary full mt12" onclick="Fit.restore()">백업 복원하기</button>`;}
 else if(modal.type==='playerWarning'){content=`<div class="eyebrow">운동 시작 전 확인</div><h2>무게 설정 필요</h2><p class="sub mt12">${esc(modal.message)}</p><button class="btn primary full mt12" onclick="Fit.closeModal()">확인</button>`;}
 else if(modal.type==='reset'){content=`<h2>정말 모든 기록을 삭제할까요?</h2><p class="sub">프로필·운동 기록·운동 진행 상태가 모두 삭제됩니다. 되돌릴 수 없습니다.</p><button class="btn danger full mt12" onclick="Fit.resetConfirm()">전체 삭제</button>`;}
 else if(modal.type==='url'){content=`<h2>영상 주소</h2><p class="sub">외부 영상 사이트를 열 수 없다면 주소를 복사해 브라우저에 붙여넣으세요.</p><textarea readonly>${esc(modal.url)}</textarea>`;}
 return `<div class="modal-bg"><div class="modal"><div class="row"><div class="eyebrow">FITPLAN</div><button class="btn tiny secondary" onclick="Fit.closeModal()">닫기 ✕</button></div>${content}</div></div>`;}
function programPreview(){refreshCycle();save();const program=FitPlanPrecisionV4.planProgram({profile:state.profile,catalog:CATALOG,history:state.history,readiness,weeks:num(state.settings.programWeeks,8),sessionIndex:state.sessionIndex,context:{planMemory:state.planMemory}});modal={type:'program',program};render();}
function backup(){modal={type:'backup'};render();}
function copyBackup(){const e=document.getElementById('backup-area');if(!e)return;e.select();try{document.execCommand('copy');toast('복사했습니다');}catch(x){toast('길게 눌러 전체를 복사해 주세요');}}
function restoreDialog(){modal={type:'restore'};render();}
function restore(){const text=document.getElementById('restore-area')?.value||'';let obj;try{obj=JSON.parse(text);if(!obj.profile||!Array.isArray(obj.history))throw Error();}catch(e){toast('올바른 FitPlan 백업 JSON이 아닙니다');return;}
 try{localStorage.setItem(KEY,JSON.stringify(obj));state=load();refreshCycle();save();todayMinutes=state.profile.duration;modal=null;view=state.onboard?'home':'setup';render();toast('백업을 복원했습니다');}catch(e){toast('복원에 실패했습니다');}}
function resetDialog(){modal={type:'reset'};render();}
function resetConfirm(){localStorage.removeItem(KEY);state=deep(DEFAULT);todayMinutes=state.profile.duration;modal=null;setupPage=0;view='setup';save();render();}
function render(){const e=document.getElementById('app');if(!e)return;let page='';try{
 if(view==='calibration')page=calibrationView();else if(view==='setup')page=setupView();else if(view==='home')page=homeView();else if(view==='ready')page=readyView();else if(view==='work')page=workView();else if(view==='player')page=playerView();else if(view==='finish')page=finishView();else if(view==='state')page=stateView();else if(view==='history')page=historyView();else if(view==='settings')page=settingsView();else if(view==='machines')page=machineView();else page=homeView();
 e.innerHTML=`<div class="shell">${page}<div class="footerpad"></div></div>${state.onboard&&!['setup','player','ready','finish','calibration'].includes(view)?nav():''}${modal?modalView():''}`;
 if(view==='player'||view==='calibration')syncAwake();
 }catch(error){console.error('FitPlan render error',error);e.innerHTML='<div class="shell"><h2>화면을 불러오지 못했습니다.</h2><p>운동 기록은 저장되어 있습니다. 아래 버튼으로 다시 시도하세요.</p><button onclick="location.reload()">다시 실행</button></div>';}}
window.Fit={githubRepo:setGithubRepo,checkUpdate:()=>checkForUpdates(true),openUpdate,beginCalibration,calibrationResume,calibrationStart,calibrationEnd,calibrationSubmit,calibrationContinue,calibrationApply,calibrationAbort,voice:v=>{state.settings.voice=v;save();render();},voiceTest,programWeeks:v=>{state.settings.programWeeks=clamp(num(v,8),4,12);refreshCycle();save();render();},cameraGuide,captureMachinePhoto,confirmCameraMachine,liveRemaining,replanNow,cardioCheck,machineFor,selectMachine,addMachine,setMachineDefault:(eid,id)=>{const e=exercise(eid);if(!e)return;const rec=FitPlanAdvanced.machineRecord(state,e);if(rec.variants.some(x=>x.id===id)){rec.active=id;save();render();}},chooseMachine:(index,id)=>{selectMachine(index,id);view='player';render();},exerciseEffort,exerciseReview,programPreview,go,setupNext,setupBack,setupFinish,goal:v=>changeProfile('goal',v),physique:v=>changeProfile('physique',v),level:v=>changeProfile('level',num(v)),sex:v=>changeProfile('sex',v),place:v=>changeProfile('place',v),focus:v=>toggleProfile('focus',v),restriction:v=>toggleProfile('restrictions',v),numProfile,liveMinutes,setMinutes,ready:setReady,createPlan,play,stretch:setStretchDone,editSet,checkSet,guide,guideStretch,alternatives,replace:replaceExercise,video:openVideo,endWorkout,feedback:setFeedback,saveWorkout,graph:v=>{chartKey=v;render();},historyDetail,editProfile:()=>{if(state.active){toast('진행 중인 운동을 종료한 후 수정하세요');return;}setupPage=0;go('setup');},alert:v=>{state.settings.alert=v;save();render();},preAlert:v=>{state.settings.preAlert=!!v;save();render();},awake:v=>{state.settings.keepAwake=!!v;save();syncAwake();render();},backup,copyBackup,restoreDialog,restore,resetDialog,resetConfirm,closeModal:()=>{modal=null;render();},playerComplete,startPreparedSet,confirmCompletedSet,pausePlayer,skipRest,extendRest,exitPlayer,resumePlayer};
window.FitEngine={splitProgram,generatePlan,suggestedLoad,trainingBalance,playerSequenceFor,doneCount,exercise,state:()=>state,precision:()=>FitPlanPrecisionV4,precisionV5:()=>FitPlanPrecisionV5,timer:()=>FitPlanTimerV6,timerClock:playerClock,cycleSummary,refreshCycle,newerVersion,repoParts};
render();
// One automatic check per cold launch; no data from the user's profile/history is transmitted.
if(state.onboard)setTimeout(()=>checkForUpdates(false),900);
