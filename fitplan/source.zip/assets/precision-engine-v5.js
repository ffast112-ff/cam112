/* FitPlan Precision V5: supervised first-use calibration and training-quality guardrails.
 * Offline, deterministic heuristics. These numbers are cautious starting *candidates*,
 * not predictions of strength or a substitute for coaching/medical assessment.
 */
(function(root,factory){
  const api=factory(root.FitPlanPrecisionV4||(typeof require==='function'?require('./precision-engine-v4.js'):null));
  if(typeof module==='object'&&module.exports)module.exports=api;
  root.FitPlanPrecisionV5=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(V4){
 'use strict';
 if(!V4)throw Error('V5 requires V4');
 const VERSION='5.0.0', DAY=86400000;
 const C={leg_press:.22,chest_press:.105,lat_pulldown:.12,seated_row:.12,rld_machine:.085,
  shoulder_press:.055,db_press:.028,db_row:.038,db_shoulder:.022,goblet_squat:.04,
  biceps_curl:.018,lateral_raise:.008,db_rdl:.04,triceps_push:.045,cable_curl:.035,
  hip_thrust:.12,assisted_pullup:.08,bench_press:.08};
 // Strength Level bodyweight-stratified estimated one-repetition maximum standards (kg).
 // Source: strengthlevel.com, male/female by-bodyweight tables checked 2026-11-11.
 // Statistical benchmarks from self-selected lifters, NOT prescriptions. These entries
 // are mapped only to matching movements, never to leg press or shoulder machine.
 const STANDARDS={
  lat_pulldown:{url:'https://strengthlevel.com/strength-standards/lat-pulldown/kg',
   male:{70:[42,57,77,99],80:[47,64,85,108],90:[52,70,92,116],95:[55,73,95,120],100:[57,76,98,123],110:[62,81,104,130],120:[66,86,110,136]},
   female:{70:[25,36,49,64],80:[27,38,52,68],90:[29,41,55,71],95:[30,42,56,72],100:[31,43,57,74],110:[33,45,59,76],120:[35,47,62,79]}},
  chest_press:{url:'https://strengthlevel.com/strength-standards/chest-press/kg',
   male:{70:[33,53,80,112],80:[39,61,89,123],90:[45,68,98,132],95:[47,71,102,137],100:[50,74,105,142],110:[55,81,113,150],120:[60,87,120,158]},
   female:{70:[12,23,38,57],80:[14,25,41,60],90:[15,27,43,63],95:[15,27,44,64],100:[16,28,45,65],110:[17,30,46,67],120:[18,31,48,69]}},
  seated_row:{url:'https://strengthlevel.com/strength-standards/seated-cable-row/kg',
   male:{70:[40,57,78,102],80:[47,65,87,112],90:[53,72,96,122],95:[56,76,100,127],100:[59,79,104,131],110:[65,86,111,139],120:[70,92,118,147]},
   female:{70:[24,35,50,66],80:[26,38,53,71],90:[29,41,57,75],95:[30,43,58,76],100:[31,44,60,78],110:[33,47,63,82],120:[35,49,66,85]}}
 };
 function standardOneRM(profile,e){
   const d=STANDARDS[e?.id],sex=profile?.sex;
   if(!d||!['male','female'].includes(sex))return null;
   const data=d[sex],bw=N(profile?.weight,NaN),lv=clamp(N(profile?.level,0),0,3);
   if(!Number.isFinite(bw)||bw<70||bw>120)return null; // no unsupported extrapolation
   const anchors=Object.keys(data).map(Number).sort((a,b)=>a-b);
   const hi=anchors.find(x=>x>=bw)||anchors[anchors.length-1];
   const lo=anchors.slice().reverse().find(x=>x<=bw)||anchors[0];
   const v=lo===hi?data[lo][lv]:data[lo][lv]+(data[hi][lv]-data[lo][lv])*(bw-lo)/(hi-lo);
   return {oneRM:v,source:d.url,level:lv,sex,bodyweight:bw};
 }
 const N=(x,d=0)=>x===null||x===undefined||x===''?d:(Number.isFinite(Number(x))?Number(x):d);
 const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
 const rnd=(x,u)=>Math.max(u,Math.round(x/u)*u);
 const calKey=(eid,mid)=>`${eid}::${mid||'default'}`;
 const usesLoad=e=>e&&!['body','band'].includes(e.gear)&&!['core','cardio'].includes(e.pattern);
 const testReps=e=>e.kind==='isolation'?10:8;
 function startingLoad(profile,e,increment,minimum){
   if(!usesLoad(e))return {required:false,weight:0,targetReps:testReps(e),note:'별도의 kg 설정 없이 자세·반복 시간을 먼저 평가합니다.'};
   const step=clamp(N(increment,e.gear==='dumbbell'?1:2.5),.25,25);
   const bw=clamp(N(profile?.weight,70),30,160);
   const lvl=clamp(N(profile?.level,0),0,3);
   const stat=standardOneRM(profile,e);
   // Around 50% of a *population* 1RM reference is an adaptation trial,
   // not an eight-repetition working set. Adjust only from observed performance.
   const base=stat?stat.oneRM*.50:bw*(C[e.id]||(e.kind==='isolation'?.025:.065))*[.75,.85,.95,1.05][lvl];
   const lower=Math.max(step,N(minimum,step));
   // Round down instead of rounding a conservative trial upwards.
   const proposal=Math.max(lower,Math.floor(Math.max(step,base)/step)*step);
   const note=stat?
    `Strength Level의 체중 ${bw}kg·${['입문','초급','중급','고급'][lvl]} 1RM 참고값 약 ${Math.round(stat.oneRM)}kg의 50%로 계산한 최초 적응 시험입니다. 통계는 개인의 실제 능력이나 해당 머신의 저항을 보장하지 않습니다. 자세가 불편하면 낮추고 시험 후 조절하세요.`:
    '이 종목·신체 조건에 대응하는 검증된 Strength Level 표가 없으므로 보수적 시험 후보를 제안합니다. 기구 최소 중량과 실제 수행을 우선하세요.';
   return {required:true,weight:proposal,minimum:lower,step,targetReps:testReps(e),
     source:stat?'strength-level':'conservative-fallback',benchmark1RM:stat?.oneRM||null,benchmarkUrl:stat?.source||null,
     note};
 }
 function previousValid(history,eid,mid){
   let last=0,weight=0,count=0;
   for(const sess of history||[])for(const it of sess.items||[])for(const s of it.sets||[]){
     if(!s.done||s.warmup||s.pain||s.form==='poor'||(s.actualId||it.currentId||it.eid)!==eid||(s.machineId||it.machineId||'default')!==mid)continue;
     if(N(s.actualWeight)<=0||N(s.actualReps)<=0)continue;
     count++;const t=N(sess.finishedAt,Date.parse(sess.date)||0);
     if(t>=last){last=t;weight=N(s.actualWeight);}
   }
   return {count,last,weight};
 }
 function calibrationStatus(state,e,mid,now=Date.now()){
   if(!usesLoad(e))return {needed:false,source:'bodyweight'};
   const key=calKey(e.id,mid);
   const v=state.calibrations?.[key];
   if(v&&((v.status==='ready'&&now-N(v.at,0)<=60*DAY)||(v.status==='provisional'&&now-N(v.at,0)<=18*3600000)))return {needed:false,source:'calibration',weight:v.weight,confidence:v.confidence||'medium'};
   const prev=previousValid(state.history,e.id,mid);
   if(prev.count>=2&&now-prev.last<=28*DAY)return {needed:false,source:'existing-records',weight:prev.weight,confidence:'medium'};
   return {needed:true,source:v?'stale-calibration':prev.count?'stale-history':'first-use',last:prev.weight||null};
 }
 function begin(profile,e,mid,increment,minimum){
   const first=startingLoad(profile,e,increment,minimum);
   return {schema:5,key:calKey(e.id,mid),exerciseId:e.id,machineId:mid||'default',
     status:'active',phase:'instructions',startedAt:Date.now(),targetReps:first.targetReps,
     step:first.step||1,minimum:first.minimum||first.step||1,weight:first.weight,
     first,attempts:[],confirmations:0,maxDailyTrials:8,dayStartedAt:Date.now(),lowEasy:null,highHard:null,kind:e.kind||'compound',reason:'최초 중량 확인'};
 }
 function evaluateTrial(cal,input){
   if(!cal||cal.status!=='active')throw Error('calibration not active');
   const w=N(input.weight), reps=N(input.reps), rir=N(input.rir,NaN),form=input.form||'uncertain',pain=!!input.pain;
   if(!Number.isFinite(w)||w<=0||!Number.isInteger(reps)||reps<0||reps>80||
      !Number.isInteger(rir)||rir<0||rir>15||!['good','uncertain','poor'].includes(form))throw Error('invalid trial results');
   const t={weight:w,reps,rir,form,pain,targetReps:cal.targetReps,time:Date.now()};
   const next={...cal,attempts:[...(cal.attempts||[]),t],phase:'instructions',weight:w};
   // Pain and unstable technique must not be interpreted as grounds to add load.
   if(pain||form==='poor'){
     next.status='stopped';next.reason=pain?'통증이 발생해 해당 운동의 측정을 중단했습니다.':'자세가 무너져 증량을 중단했습니다. 가벼운 중량에서 자세를 점검하세요.';
     return next;
   }
   if(form==='uncertain'){
     next.status='paused';next.reason='자세가 안정적인지 확인되지 않아 오늘 측정을 보류했습니다. 기구 사용법을 확인한 뒤 이어가세요.';
     return next;
   }
   const goodReps=reps>=cal.targetReps;
   const nearTarget=goodReps&&rir>=2&&rir<=3;
   const step=Math.max(.25,N(cal.step,2.5));
   const quantize=(value)=>Math.max(cal.minimum||step,Math.round(value/step)*step);
   const prevEasy=N(cal.lowEasy,0);
   const prevHard=N(cal.highHard,0);
   if(nearTarget){
     next.status='ready';next.phase='complete';next.weight=w;next.confidence=cal.attempts.length>=2?'medium':'low';
     next.reason='목표 횟수를 자세 안정·통증 없음·반복 여유 2~3회로 완료해 첫 기준 중량을 저장할 수 있습니다.';
     return next;
   }
   if(!goodReps||rir<=1){
     next.highHard=prevHard>0?Math.min(prevHard,w):w;
     // Bracket the load using the highest previously easy trial if available.
     const bracket=prevEasy>0&&prevEasy<w;
     const candidate=bracket?quantize((prevEasy+w)/2):quantize(w*(rir===0?.85:.92));
     next.weight=Math.min(w-step,Math.max(cal.minimum||step,candidate));
     next.reason=bracket?'직전 가벼운 중량과 이번 무거운 중량 사이에서 소폭 낮춰 다시 확인합니다.':'어려운 결과가 나와 중량을 소폭 낮춰 확인합니다.';
   }else{
     // '6회 이상' is not an exact RIR measure. Differentiate 6,8,10,12,15+ explicitly.
     const factors={4:1.06,5:1.10,6:1.16,7:1.20,8:1.25,9:1.30,10:1.35,11:1.40,12:1.45,13:1.50,14:1.55,15:1.60};
     let factor=factors[Math.min(15,Math.max(4,rir))]||1.06;
     // Absolute 2x cap is a ceiling, NOT an automatic recommendation. Smaller
     // isolation movements must be progressed more cautiously than compounds.
     factor=Math.min(factor,cal.kind==='isolation'?1.15:1.40,2);
     const capByBracket=prevHard>0&&prevHard>w?Math.min(prevHard-step,w*factor):w*factor;
     let candidate=quantize(capByBracket);
     candidate=Math.max(w+step,Math.min(candidate,Math.floor((w*2)/step)*step));
     if(prevHard>0&&candidate>=prevHard)candidate=Math.max(w,prevHard-step);
     next.lowEasy=Math.max(prevEasy,w);
     next.weight=candidate;
     next.reason=`${rir===15?'15회 이상':rir+'회'} 여유가 남아 ${w}kg에서 ${candidate}kg으로 시험 중량을 높입니다. 한 번에 2배는 상한일 뿐 자동 적용하지 않습니다.`;
   }
   // Trials are not limited to four. If accumulated fatigue risks misleading
   // results, preserve the trials and resume on a subsequent day.
   const today=next.attempts.filter(x=>new Date(x.time).toDateString()===new Date().toDateString()).length;
   if(today>=Math.max(6,N(cal.maxDailyTrials,8))){
     next.status='paused';next.phase='paused';
     next.reason+=' 오늘 시험이 누적되어 측정을 잠시 멈춥니다. 기록은 보존되고 다음 운동일에 이어서 탐색합니다.';
   }
   return next;
 }
 function finishCalibration(cal){
   if(!['ready','provisional'].includes(cal.status))throw Error('calibration not ready');
   return {status:cal.status==='ready'?'ready':'provisional',weight:cal.weight,
     confidence:cal.status==='ready'?'medium':'low',at:Date.now(),tests:cal.attempts.slice(),
     note:cal.reason};
 }
 function guardPrescription(item,e,state,mid){
   const c=calibrationStatus(state,e,mid),issues=[];
   if(c.needed)issues.push('새 기구의 시작 중량은 시험 세트로 확인해야 합니다.');
   const rec=state.calibrations?.[calKey(e.id,mid)];
   const last=previousValid(state.history,e.id,mid);
   let capped=0;
   for(const set of item.sets||[]){
     if(set.done||set.warmup||!usesLoad(e)||!N(set.targetWeight))continue;
     const ref=N(rec?.weight,last.weight);
     if(ref>0&&N(set.targetWeight)>ref*1.15){
       // Preserve safe upper bound; quantization is reconciled at pre-set confirmation.
       const step=Math.max(.25,N(state.machines?.[e.id]?.variants?.find(v=>v.id===mid)?.increment,2.5));
       const max=Math.max(step,Math.floor(ref*1.15/step)*step);
       if(max<set.targetWeight){set.targetWeight=max;set.actualWeight=max;capped++;}
     }
   }
   if(capped)issues.push(`중량 급증 가능성이 있어 ${capped}개 세트를 보수적으로 제한했습니다.`);
   return {issues,calibration:c};
 }
 function exerciseQuality(history,id,mid){
   const samples=[];
   for(const sess of (history||[]).slice(-16))for(const it of sess.items||[])for(const s of it.sets||[]){
    if(!s.done||s.warmup||(s.actualId||it.currentId||it.eid)!==id||(s.machineId||it.machineId||'default')!==mid)continue;
    samples.push({reps:N(s.actualReps),target:N(s.targetReps),rir:s.rir,pain:!!s.pain,form:s.form||'uncertain'});
   }
   const good=samples.filter(x=>x.form==='good'&&!x.pain&&x.reps>=x.target).length;
   const risky=samples.filter(x=>x.pain||x.form==='poor').length;
   return {samples:samples.length,success:good,issues:risky,score:samples.length?Math.round(100*good/samples.length):null,
      label:samples.length>=6&&risky===0&&good/samples.length>=.8?'익숙함':samples.length>=2?'학습 중':'첫 운동'};
 }
 function recoveryGuide(history,readiness){
   const f=(history||[]).slice(-4).map(h=>({difficulty:N(h.feedback?.difficulty,5),sore:N(h.feedback?.soreness,2),pain:!!h.feedback?.pain}));
   const strain=f.filter(x=>x.pain||(x.difficulty>=8&&x.sore>=4)).length;
   if(readiness?.pain)return {level:'stop',reason:'통증 부위의 운동을 중단하고 상태를 확인하세요.'};
   if(strain>=3&&f.length>=3)return {level:'reduce',reason:'최근 높은 난이도·근육 피로가 반복되어 운동량 축소를 권장합니다.'};
   if(N(readiness?.sleep,3)<=2||N(readiness?.energy,3)<=2)return {level:'caution',reason:'회복 상태가 낮아 새로운 증량을 보류합니다.'};
   return {level:'normal',reason:'기록된 회복 신호에서 추가 제한이 확인되지 않았습니다.'};
 }
 function stepsFor(e){
  const common=['기구의 중량·좌석·손잡이 설정을 확인합니다.','가볍게 2~3회 움직여 통증이 없는지 확인합니다.',e.tips||'반동 없이 통제 가능한 범위에서 움직입니다.','반동이나 통증이 생기면 즉시 중단합니다.'];
  if(e.id==='chest_press')return ['손잡이가 가슴 중앙 높이에 오도록 좌석을 조절합니다.','양발을 바닥에 두고 등과 엉덩이를 등받이에 붙입니다.','어깨가 으쓱하지 않도록 통제하며 부드럽게 밀었다 돌아옵니다.','통증이나 어깨 불안정이 느껴지면 중단합니다.'];
  if(e.id==='leg_press')return ['좌석을 조절해 허리가 뜨지 않도록 지지합니다.','발을 발판에 안정적으로 놓고 무릎·발끝 방향을 맞춥니다.','가능한 가동 범위에서 천천히 밀고 무릎은 강하게 잠그지 않습니다.','허리나 무릎에 통증이 생기면 중단합니다.'];
  return common;
 }
 return {VERSION,calKey,usesLoad,standardOneRM,startingLoad,calibrationStatus,begin,evaluateTrial,
   finishCalibration,guardPrescription,exerciseQuality,recoveryGuide,stepsFor};
});
