/* FitPlan 1.5 operational expansion. Offline heuristics; not a diagnostic tool.
   Camera images are NOT automatically classified: the user confirms the equipment.
   Speech depends on WebView/system speechSynthesis support. */
(function(root){'use strict';
const toNum=(x,d=0)=>{const n=Number(x);return Number.isFinite(n)?n:d;};
const clamp=(n,a,b)=>Math.min(b,Math.max(a,n));
const GUIDES={
 leg_press:['등·엉덩이를 등받이에 붙이기','발을 발판에 어깨 너비로 놓기','무릎이 발 방향으로 움직이도록 조절','무릎을 잠그지 않고 천천히 펴기'],
 chest_press:['좌석을 손잡이가 가슴 중간 높이에 오도록 맞추기','등과 엉덩이를 등받이에 붙이기','손목을 꺾지 않고 편안한 범위에서 밀기','어깨가 으쓱하지 않도록 천천히 돌아오기'],
 lat_pulldown:['무릎 패드가 허벅지를 안정적으로 잡게 조절','어깨 너비보다 약간 넓게 그립 잡기','가슴을 세우고 바를 윗가슴 방향으로 당기기','반동 없이 팔을 천천히 펴기'],
 seated_row:['발 받침과 가슴 패드를 편안하게 조절','척추 중립 자세로 손잡이 잡기','팔꿈치를 뒤로 보내며 당기기','상체를 흔들지 않고 천천히 되돌리기'],
 shoulder_press:['손잡이가 귀 부근에서 시작하도록 좌석 조절','등받이에 몸을 안정적으로 붙이기','통증 없는 범위에서 수직으로 밀기','허리를 과도하게 젖히지 않기'],
 rld_machine:['패드가 발목 위에 오도록 조절','무릎과 회전축을 기구의 축과 맞추기','골반과 허벅지를 고정하기','반동 없이 무릎을 굽혔다 천천히 펴기'],
 db_press:['무리 없는 가벼운 덤벨 고르기','벤치에 등을 붙이고 발을 바닥에 고정','팔꿈치를 과도하게 벌리지 않고 밀기','덤벨은 통제하며 천천히 내리기'],
 db_row:['한쪽 손과 무릎을 벤치에 안정적으로 지지','등을 중립으로 유지','팔꿈치를 골반 방향으로 당기기','좌우 각각 같은 횟수로 기록하기'],
 goblet_squat:['덤벨을 가슴 앞에 안정적으로 들기','발바닥 전체로 지면 누르기','통증 없는 범위에서 앉기','무릎과 발끝 방향을 맞춰 일어나기'],
 body_squat:['발을 어깨 너비로 벌리기','상체를 안정적으로 유지','통증 없는 범위에서 앉았다 일어나기'],
 walking:['안전 클립 등 기구 안전장치 확인','처음에는 걷기 편한 속도 설정','손잡이에 오래 기대지 않기','숨이 지나치게 차면 속도 낮추기']
};
function stepsFor(e){return GUIDES[e.id]||[e.tips||'동작을 천천히 확인하세요.','가벼운 저항과 안정된 자세부터 시작하세요.','통증이 생기면 중단하세요.'];}
function isUnilateral(id){return ['db_row','split_squat','biceps_curl','triceps_db','db_shoulder','lateral_raise'].includes(id);}
function practiceCount(history,eid){return (history||[]).filter(session=>(session.items||[]).some(it=>(it.sets||[]).some(s=>s.done&&!s.warmup&&(s.actualId||it.currentId||it.eid)===eid&&s.form==='good'&&!s.pain))).length;}
function confidence(history,eid,machine){
 const samples=(history||[]).filter(s=>(s.items||[]).some(it=>(it.sets||[]).some(x=>x.done&&!x.warmup&&(x.actualId||it.currentId||it.eid)===eid&&(!machine||(x.machineId||it.machineId||'default')===machine)&&!x.pain&&x.form!=='poor'&&toNum(x.actualReps)>0))).length;
 if(samples>=6)return {level:'높음',samples,reason:'6회 이상의 비교 가능한 운동일 기록'};
 if(samples>=3)return {level:'보통',samples,reason:'3~5회 운동일 기록'};
 return {level:'낮음',samples,reason:'기록 부족 · 가벼운 시험 세트 권장'};
}
function cardioDose(profile,minutes,estimated,ready){
 if(ready?.pain||toNum(ready?.energy,3)<=2||toNum(ready?.soreness,2)>=4)return 0;
 if(minutes<45)return 0;
 const spare=Math.max(0,minutes-estimated);
 const goal=profile.goal;
 const target=goal==='fitness'||goal==='fatloss'?(minutes>=90?16:minutes>=60?10:6):(minutes>=90?8:0);
 return clamp(Math.floor(spare-2),0,target);
}
function estimatePending(plan){if(!plan)return 0;
 let sec=0;
 for(const it of plan.items||[]){const pending=(it.sets||[]).filter(s=>!s.done);if(!pending.length)continue;
 sec+=55;pending.forEach(s=>sec+=(s.warmup?45:55)+(s.restSec||it.rest||80));}
 for(const z of [...(plan.pre||[]),...(plan.post||[])])if(!z.done)sec+=toNum(z.secs);
 for(const z of plan.cardio||[])if(!z.done)sec+=toNum(z.secs);
 return Math.ceil(sec/60);
}
function replan(plan,minutesLeft,profile,readiness){
 const before=estimatePending(plan),remain=clamp(Math.round(toNum(minutesLeft,30)),10,120);
 if(!Array.isArray(plan.changes))plan.changes=[];
 const protectedStretch=Math.ceil(([...(plan.pre||[]),...(plan.post||[])].filter(s=>!s.done).reduce((x,s)=>x+toNum(s.secs),0))/60);
 let removals=0,extras=0,action='유지';
 const pending=()=>estimatePending(plan);
 // Lower priority accessories first; preserve completed sets. Keep ≥1 pending working set when possible.
 if(pending()>remain){
   const items=(plan.items||[]).map((it,i)=>({it,i,focus:(profile.focus||[]).includes(it.muscle)||['하체','팔'].some(g=>(profile.focus||[]).includes(g)&&['하체','뒤허벅지','둔근','종아리','이두','삼두'].includes(it.muscle))}));
   items.sort((a,b)=>Number(a.focus)-Number(b.focus)||b.i-a.i);
   for(let pass=0;pass<5&&pending()>remain;pass++)for(const {it} of items){
     if(pending()<=remain)break;
     const current=it.sets.filter(s=>!s.done&&!s.warmup);
     if(current.length<2)continue;
     const target=current[current.length-1];it.sets.splice(it.sets.indexOf(target),1);removals++;
   }
   if(pending()>remain){ // Remove optional cardio first, never hide an already completed segment.
     const count=(plan.cardio||[]).filter(x=>!x.done).length;
     if(count){plan.cardio=plan.cardio.filter(x=>x.done);removals+=count;}
   }
   if(pending()>remain&&remain>protectedStretch+3){
     for(const {it} of items)if(pending()>remain){const working=it.sets.filter(s=>!s.done&&!s.warmup);
       if(working.length===1){it.sets.splice(it.sets.indexOf(working[0]),1);removals++;}}
   }
   action='단축';
 }else if(pending()+8<remain&&toNum(readiness?.energy,3)>=3&&toNum(readiness?.soreness,2)<=3&&!readiness?.pain){
   const best=(plan.items||[]).filter(it=>it.sets.some(s=>s.done||!s.warmup)).sort((a,b)=>Number((profile.focus||[]).includes(b.muscle))-Number((profile.focus||[]).includes(a.muscle)));
   for(const it of best){if(extras>=2||pending()+4>remain)break;
     const working=it.sets.filter(s=>!s.warmup);
     const cap=(profile.level<=0?3:profile.level===1?4:profile.level===2?5:6);
     if(working.length>=cap)continue;
     const muscle=it.muscle;
     const target=toNum(plan.weeklyTarget?.[muscle],0);
     const prior=toNum(plan.weeklyDone?.[muscle],0);
     const planned=(plan.items||[]).reduce((sum,x)=>sum+(x.muscle===muscle?x.sets.filter(s=>!s.warmup).length:0),0);
     if(target>0&&prior+planned>=target+.5)continue;
     const last=working[working.length-1];if(!last)continue;
     it.sets.push({...last,done:false,rir:null,form:null,pain:false,durationSec:0,role:'working',label:'추가 본세트'});extras++;
   }
   if(extras>0)action='확장';
 }
 const after=estimatePending(plan);
 const result={at:Date.now(),minutesLeft:remain,before,after,removedSets:removals,addedSets:extras,action,notice:after>remain?'운동 종료 시간은 추정치입니다. 무리하게 휴식을 줄이지 마세요.':''};
 plan.changes.push(result);plan.lastReplan=result;
 return result;
}
function asymmetry(history){
 const samples=[];for(const session of history||[])for(const it of session.items||[])for(const s of it.sets||[]){
  if(!s.done||!s.sideRecords)continue;
  const L=toNum(s.sideRecords.left),R=toNum(s.sideRecords.right);if(L>0&&R>0)samples.push({exercise:s.actualId||it.currentId||it.eid,left:L,right:R,diff:Math.abs(L-R)/Math.max(L,R)});
 }
 return {samples:samples.length,uneven:samples.filter(x=>x.diff>.15).length,recent:samples.slice(-5)};
}
function adherence(history,profile){const days=clamp(toNum(profile.days,3),2,6);const cutoff=Date.now()-28*86400000;
 const recent=(history||[]).filter(s=>toNum(s.finishedAt,0)>=cutoff);
 return {done:recent.length,expected:days*4,ratio:Math.min(1,recent.length/Math.max(1,days*4))};
}
root.FitPlan15={stepsFor,isUnilateral,practiceCount,confidence,cardioDose,estimatePending,replan,asymmetry,adherence};
})(window);
