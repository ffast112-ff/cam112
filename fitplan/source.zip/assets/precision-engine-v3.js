/* FitPlan Precision Engine v3.0 — deterministic offline exercise-plan prototype.
 * Inputs: FitPlan 1.0 CATALOG, profile, readiness, completed-session history.
 * Safety: not medical advice; workout outcomes and body-shape changes cannot be
 * inferred from strength proxies alone. Physiological heuristics are conservative
 * engineering defaults, NOT validated individual optimization parameters.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.FitPlanPrecisionV3 = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const VERSION = '3.1.0-volume';
  const GROUPS = ['가슴','등','어깨','하체','뒤허벅지','둔근','이두','삼두','복부','종아리'];
  const MAJOR = new Set(['가슴','등','어깨','하체','뒤허벅지']);
  const MUSCLE_CREDIT = {
    squat:{'하체':1,'둔근':.4}, hinge:{'뒤허벅지':1,'둔근':.4}, glutes:{'둔근':1},
    push:{'가슴':1,'삼두':.35,'어깨':.15}, chestiso:{'가슴':1},
    pullvertical:{'등':1,'이두':.35}, pullhorizontal:{'등':1,'이두':.35},
    verticalpush:{'어깨':1,'삼두':.35}, shoulderiso:{'어깨':1},
    biceps:{'이두':1},triceps:{'삼두':1},core:{'복부':1},calves:{'종아리':1}
  };
  const PATTERN_GROUP={squat:'하체',hinge:'뒤허벅지',glutes:'둔근',push:'가슴',chestiso:'가슴',pullvertical:'등',pullhorizontal:'등',verticalpush:'어깨',shoulderiso:'어깨',biceps:'이두',triceps:'삼두',core:'복부',calves:'종아리',cardio:'유산소'};
  const COMMON = ['leg_press','chest_press','lat_pulldown','seated_row','rld_machine','shoulder_press','goblet_squat','body_squat','pushup','db_row','db_press','db_shoulder','glute_bridge','plank','dead_bug','walking','biceps_curl','triceps_push','lateral_raise','calf_raise','db_rdl','band_row','cable_curl'];
  const SIMPLE_RANK = new Map(COMMON.map((x,i)=>[x,i]));
  const SPLITS = [
    {id:'full',name:'1분할 · 전신 순환',days:[
      {name:'전신 A',patterns:['squat','push','pullvertical','hinge','core','shoulderiso']},
      {name:'전신 B',patterns:['hinge','pullhorizontal','push','squat','verticalpush','core']},
      {name:'전신 C',patterns:['squat','pullvertical','verticalpush','glutes','push','core']}
    ]},
    {id:'upperlower',name:'2분할 · 상하체 A/B',days:[
      {name:'상체 A',patterns:['push','pullvertical','pullhorizontal','verticalpush','triceps','biceps']},
      {name:'하체 A',patterns:['squat','hinge','glutes','core','calves']},
      {name:'상체 B',patterns:['pullhorizontal','push','verticalpush','pullvertical','shoulderiso','biceps']},
      {name:'하체 B',patterns:['hinge','squat','glutes','core','calves']}
    ]},
    {id:'ppl',name:'3분할 · 밀기/당기기/하체',days:[
      {name:'밀기',patterns:['push','verticalpush','chestiso','shoulderiso','triceps']},
      {name:'당기기',patterns:['pullvertical','pullhorizontal','biceps','core']},
      {name:'하체',patterns:['squat','hinge','glutes','calves','core']}
    ]},
    {id:'four',name:'4분할 · 부위별 순환',days:[
      {name:'가슴·삼두',patterns:['push','chestiso','triceps','shoulderiso']},
      {name:'등·이두',patterns:['pullvertical','pullhorizontal','biceps','core']},
      {name:'하체',patterns:['squat','hinge','glutes','calves']},
      {name:'어깨·보완',patterns:['verticalpush','shoulderiso','pullhorizontal','glutes','core']}
    ]}
  ];
  const clamp = (x,a,b)=>Math.max(a,Math.min(b,x));
  const number = (x,def=0)=>x===null||x===undefined||x===''?def:(Number.isFinite(Number(x))?Number(x):def);
  const sum = xs=>xs.reduce((a,b)=>a+b,0);
  const average = xs=>xs.length?sum(xs)/xs.length:null;
  const median = xs=>{const a=xs.filter(Number.isFinite).slice().sort((x,y)=>x-y);return a.length?a.length%2?a[(a.length-1)/2]:(a[a.length/2-1]+a[a.length/2])/2:null;};
  const round = (n,d=1)=>Math.round(n*10**d)/10**d;
  const isTimed = e=>['core','cardio'].includes(e.pattern);
  const usesExternalLoad = e=>!isTimed(e)&&!['body','band'].includes(e.gear);
  function normalizeProfile(p={}) { return {
    level:clamp(Math.round(number(p.level,0)),0,3),days:clamp(Math.round(number(p.days,3)),2,6),
    duration:clamp(Math.round(number(p.duration,60)),30,120),goal:p.goal||'hypertrophy',
    physique:p.physique||'balanced',place:p.place||'gym',
    focus:Array.isArray(p.focus)?p.focus.slice():[],restrictions:Array.isArray(p.restrictions)?p.restrictions.slice():[]
  }; }
  function normalizeReadiness(r={}) { return {energy:clamp(number(r.energy,3),1,5),sleep:clamp(number(r.sleep,3),1,5),soreness:clamp(number(r.soreness,2),1,5),pain:!!r.pain,painArea:r.painArea||null,formConcern:!!r.formConcern}; }
  function focusGroups(p) {let s=new Set(p.focus);if(s.has('팔')){s.add('이두');s.add('삼두');}if(s.has('하체')){s.add('뒤허벅지');s.add('둔근');s.add('종아리');}return s;}
  function recoveryRisk(r) {return !!r.pain||r.energy<=2||r.sleep<=2||r.soreness>=4;}
  function exerciseRestrictions(e,p,r,unavailable=[]) {
    if(!e||unavailable.includes(e.id))return ['unavailable'];
    const why=[];if(p.place==='home'&&!['body','dumbbell','band'].includes(e.gear))why.push('no-equipment');
    if(number(e.level,0)>p.level+1)why.push('experience');
    const q=new Set([...p.restrictions,...(r.pain&&r.painArea?[r.painArea]:[])]);
    if(q.has('어깨')&&['push','chestiso','verticalpush','shoulderiso'].includes(e.pattern))why.push('shoulder');
    if(q.has('허리')&&['hinge'].includes(e.pattern))why.push('back');
    if(q.has('무릎')&&e.pattern==='squat')why.push('knee');
    if(q.has('손목')&&['push','biceps','triceps'].includes(e.pattern))why.push('wrist');
    if(q.has('발목')&&['squat','calves'].includes(e.pattern))why.push('ankle');
    if(r.pain&&(!r.painArea||PATTERN_GROUP[e.pattern]===r.painArea||e.m===r.painArea))why.push('pain');
    return why;
  }
  function allowedExercise(e,p,r,unavailable=[]) {return exerciseRestrictions(e,normalizeProfile(p),normalizeReadiness(r),unavailable).length===0;}
  function finishedTime(session,now) { const v=session.finishedAt||session.endTime||session.timestamp||null;
    if(!v) return null; const ms=typeof v==='string'?Date.parse(v):Number(v);return Number.isFinite(ms)&&ms>0&&ms<=now+86400000?ms:null;
  }
  function datedHistory(history,now=Date.now()) {return (Array.isArray(history)?history:[]).filter(Boolean)
    .map((s,i)=>({session:s,time:finishedTime(s,now),index:i})).filter(x=>x.time!==null)
    .sort((a,b)=>a.time-b.time||a.index-b.index);}
  function executedSets(session,id) { const result=[];
    for(const item of session.items||[]){for(const s of item.sets||[]){
      if(!s.done||s.warmup||s.role==='warmup')continue;
      const actualId=s.actualId||item.currentId||item.eid||item.id;
      if(id&&actualId!==id)continue;
      result.push({id:actualId,pattern:item.pattern,kind:item.kind,set:s,item});
    }}return result;
  }
  function exerciseSessions(history,id,now=Date.now()) {return datedHistory(history,now)
    .map(x=>({...x,sets:executedSets(x.session,id)})).filter(x=>x.sets.length);
  }
  function recordRole(s) {const label=String(s.role||s.label||'');return /backoff|back-off|백오프|드롭/i.test(label)?'backoff':/warmup|준비/i.test(label)?'warmup':'working';}
  function validSet(z,timed=false) {const s=z.set||z;
    return number(s.actualReps,-1)>0&&(timed||number(s.actualWeight,-1)>0)&&s.form!=='poor'&&!s.pain;}
  function sessionPerformance(group,e) {
    const timed=isTimed(e), loaded=usesExternalLoad(e), valid=group.sets.filter(z=>validSet(z,!loaded));
    const working=valid.filter(z=>recordRole(z.set)!=='backoff');
    const reference=working.length?Math.max(...working.map(z=>number(z.set.actualWeight))):(valid.length?Math.max(...valid.map(z=>number(z.set.actualWeight))):null);
    const base=working.length?working:valid;
    const near=reference===null?[]:base.filter(z=>number(z.set.actualWeight)>=reference-.001);
    const best=near.length?near.slice().sort((a,b)=>number(b.set.actualReps)-number(a.set.actualReps))[0]:null;
    let estimate=null;
    if(best&&reference>0){let reps=number(best.set.actualReps),rir=number(best.set.rir,NaN);
      if(Number.isFinite(rir)&&reps>=3&&reps<=12&&rir>=0&&rir<=5){estimate=reference*(1+clamp(reps+rir,1,18)/30);}
    }
    const targetCount=(group.session.items||[]).reduce((count,it)=>count+(it.sets||[]).filter(s=>!s.warmup&&s.role!=='warmup'&&(s.actualId||it.currentId||it.eid||it.id)===e.id).length,0);
    const matched=group.sets.length>=Math.max(1,targetCount)&&group.sets.every(z=>{
      const s=z.set;return number(s.actualReps,-1)>=number(s.targetReps,Infinity) && (s.form!=='poor') && !s.pain;
    });
    const rirs=group.sets.map(z=>number(z.set.rir,NaN)).filter(x=>Number.isFinite(x)&&x>=0&&x<=6);
    const difficulty=number(group.session.feedback?.difficulty,number(group.session.difficulty,NaN));
    const pain=!!group.session.feedback?.pain||group.sets.some(z=>z.set.pain||z.set.form==='poor');
    return {time:group.time,reference,estimate,validCount:valid.length,total:group.sets.length,expected:targetCount,matched,rir:median(rirs),difficulty:Number.isFinite(difficulty)?difficulty:null,pain,completedSets:group.sets.length};
  }
  function equipmentIncrement(e,ctx={}) {const map=ctx.increment||{}; const override=number(map[e.id],NaN);
    return Number.isFinite(override)&&override>0?override:e.gear==='dumbbell'?1:e.gear==='machine'||e.gear==='cable'?2.5:2.5;
  }
  function quantize(w,step) {return Math.max(step,Math.round(w/step)*step);}
  function assessLoad(e,history=[],readiness={},ctx={}) {
    const r=normalizeReadiness(readiness),now=number(ctx.now,Date.now()),unit=equipmentIncrement(e,ctx);
    const records=exerciseSessions(history,e.id,now).slice(-8).map(x=>sessionPerformance(x,e));
    const loaded=usesExternalLoad(e);
    const good=records.filter(x=>x.validCount>0&&(!loaded||x.reference>0));
    const signals=good.filter(x=>x.rir!==null||x.difficulty!==null);
    const recent=good[good.length-1];
    const confidenceScore=clamp(round(good.length/5*.65+signals.length/5*.25+(good.length>=3&&good.every(x=>x.total===x.expected)? .1:0),2),0,.95);
    const confidence=good.length===0?'unmeasured':confidenceScore<.35?'low':confidenceScore<.7?'medium':'high';
    const baseline={exerciseId:e.id,unit,confidence,confidenceScore,records:good.length,
      reference:null,estimateStrength:null,trend:null,action:'calibrate',weight:null,
      repsAdjustment:0,setsAdjustment:0,reason:'실제 중량 기록이 부족합니다. 가벼운 시험 세트로 시작 중량을 측정합니다.'};
    if(!recent){
      if(!loaded)return {...baseline,weight:0,reference:0,action:'bodyweight',reason:'기구 중량 없이 동작 자세와 반복 목표를 우선 확인합니다.'};
      return baseline;
    }
    const daysSince=(now-recent.time)/86400000;
    if(loaded&&daysSince>28){
      return {...baseline,records:good.length,confidence:'low',confidenceScore:Math.min(.2,confidenceScore),
        reference:recent.reference,action:'recalibrate',weight:null,
        reason:'마지막 운동 기록이 4주 이상 전입니다. 이전 기록만으로 현재 중량을 확정하지 않고 가벼운 시험 세트로 다시 확인합니다.'};
    }
    if(!loaded){
      const goal=recent.matched&&recent.rir!==null&&recent.rir>=3?'add-reps':'hold';
      return {...baseline,records:good.length,weight:0,reference:0,confidence,confidenceScore,action:goal,repsAdjustment:goal==='add-reps'?1:0,reason:goal==='add-reps'?'맨몸 운동 목표를 여유 있게 완료해 다음 반복 목표를 1회 늘립니다.':'맨몸 운동은 중량 대신 반복·자세·시간을 점진적으로 조절합니다.'};
    }
    const strength=good.map(z=>z.estimate).filter(Number.isFinite);
    const a=strength.slice(-3),b=strength.slice(-6,-3),trend=(a.length>=2&&b.length>=2&&median(b)>0)?round((median(a)/median(b)-1)*100,1):null;
    let action='hold',weight=recent.reference,repsAdjustment=0,setsAdjustment=0;
    let reason='현재 중량을 유지하며 반복 횟수와 자세를 안정적으로 달성합니다.';
    const lastTwo=good.slice(-2);
    const repeatedMiss=lastTwo.length===2&&lastTwo.every(z=>!z.matched);
    const easy=recent.matched&&(recent.rir!==null?recent.rir>=3:recent.difficulty!==null&&recent.difficulty<=4);
    const effortKnown=recent.rir!==null||recent.difficulty!==null;
    if(recent.pain||r.pain){action='stop';weight=null;reason='통증 또는 자세 이상이 기록되어 자동 처방을 중단합니다. 통증 없는 대체 동작이나 전문가 확인이 필요합니다.';}
    else if(daysSince>10){action='return';setsAdjustment=-1;reason='마지막 운동 이후 간격이 길어 바로 증량하지 않고 회복 상태와 자세를 다시 확인합니다.';}
    else if(recoveryRisk(r)){action='recovery';setsAdjustment=-1;reason='수면·피로·근육통 상태가 좋지 않아 증량을 보류하고 세트를 줄입니다.';}
    else if(repeatedMiss){action='reduce';weight=quantize(recent.reference*.95,unit);weight=Math.min(weight,recent.reference);reason='최근 2회 모두 목표를 달성하지 못해 중량을 보수적으로 낮춥니다.';}
    else if(easy&&effortKnown&&recent.validCount>=2){
      const next=quantize(recent.reference*(e.kind==='isolation'?1.03:1.04),unit);
      const proposal=next>recent.reference?next:recent.reference+unit;
      if(proposal>recent.reference&&(proposal-recent.reference)/recent.reference<=.08){action='increase';weight=proposal;reason='최근 본세트 목표를 달성했고 반복 여유가 남아 최소 증량 단위로 중량을 올립니다.';}
      else{action='add-reps';repsAdjustment=1;reason='기구의 최소 중량 증가폭이 커서 다음 운동은 중량 대신 반복 목표를 1회 늘립니다.';}
    } else if(recent.matched&&recent.rir!==null&&recent.rir<=1){reason='목표를 달성했으나 반복 여유가 적어 증량하지 않습니다.';}
    else if(!effortKnown){reason='난이도 평가가 없어 반복 목표와 중량을 유지합니다. 다음 기록에서 반복 여유를 수집합니다.';}
    return {...baseline,reference:recent.reference,estimateStrength:strength.length?round(median(strength.slice(-3)),1):null,
      trend,action,weight,repsAdjustment,setsAdjustment,reason};
  }
  function recentMinutesPerExercise(history,id,now=Date.now()) {const vals=[];
    for(const group of exerciseSessions(history,id,now).slice(-8)){
      for(const it of group.session.items||[])if(it.eid===id||it.currentId===id){
        const dur=number(it.durationSec,NaN);if(Number.isFinite(dur)&&dur>=60&&dur<=2400)vals.push(dur);
      }
    }return median(vals);
  }
  function exerciseTime(e,sets,history=[],now=Date.now()) {
    const observed=recentMinutesPerExercise(history,e.id,now);
    if(observed!==null){const currentCount=sets.length,prevCount=3;return Math.max(60,observed*currentCount/prevCount);}
    let seconds=45;for(let i=0;i<sets.length;i++){
      const s=sets[i];seconds+=isTimed(e)?s.targetReps:s.targetReps*(e.kind==='compound'?4:3)+14;
      if(i<sets.length-1)seconds+=s.restSec;
    }return Math.ceil(seconds);
  }
  function targetRange(e,p) {if(e.pattern==='core')return [20,45];if(e.pattern==='cardio')return [120,300];
    if(e.kind==='isolation')return [10,15];if(p.goal==='strength')return p.level===0?[6,10]:[5,8];
    if(p.goal==='fitness'||p.goal==='fatloss')return [10,15];return [8,12];
  }
  function baseSets(e,p,r,focus) {let count=p.level===0?2:p.level===1?3:p.level===2?3:3;
    if(focus.has(e.m)&&p.level>=1&&p.duration>=75&&!recoveryRisk(r))count++;
    if(p.duration<=40&&count>2)count--;
    if(recoveryRisk(r))count=Math.max(1,count-1);
    return clamp(count,1,4);
  }
  function prescribeSets(e,p,r,analysis,count) {
    const [lo,hi]=targetRange(e,p), timed=isTimed(e),level=p.level,unit=equipmentIncrement(e);
    const base=analysis.weight;const sets=[];const mainRIR=level===0?3:level===1?2:2;
    const rest=p.goal==='strength'&&e.kind==='compound'?180:e.kind==='compound'?120:75;
    if(!timed&&e.kind==='compound'&&base!==null&&base>0&&level>=1){
      sets.push({role:'warmup',warmup:true,targetWeight:quantize(base*.5,unit),targetReps:8,targetRIR:5,restSec:60,confidence:analysis.confidence});
    }
    const mid=Math.round((lo+hi)/2);
    for(let i=0;i<count;i++){
      const strengthVariation=level>=2&&p.goal==='strength'&&count>=3;
      const backoff=strengthVariation&&i===count-1;
      const adjustedWeight=base===null||timed?null:backoff?quantize(Math.max(unit,base*.9),unit):base;
      sets.push({role:backoff?'backoff':'working',warmup:false,targetWeight:adjustedWeight,
        targetReps:timed?clamp(e.pattern==='cardio'?120+i*30:25+i*5,lo,hi):clamp(mid+(analysis.repsAdjustment||0)+(backoff?2:0),lo,hi+1),
        repRange:[lo,hi],targetRIR:mainRIR,restSec:rest,confidence:analysis.confidence});
    }return sets;
  }
  // Weekly volume allocation: use finished working sets only, and give secondary
  // muscles fractional credit rather than treating a compound set as multiple full sets.
  function currentWorkingCredits(chosen){const out=Object.fromEntries(GROUPS.map(m=>[m,0]));
    for(const z of chosen){const c=MUSCLE_CREDIT[z.pattern]||{};
      const n=z.sets.filter(s=>!s.warmup).length;
      for(const m in c)out[m]+=c[m]*n;
    }return out;}
  function projectedExposures(split,profile,readiness,catalog,unavailable,sessionIndex,remaining,desired){
    const out=Object.fromEntries(GROUPS.map(m=>[m,0]));
    for(let j=0;j<remaining;j++){
      const day=split.days[(sessionIndex+j)%split.days.length];
      let slots=0;
      for(const pat of day.patterns){if(slots>=desired)break;
        if(!catalog.some(e=>e.pattern===pat&&allowedExercise(e,profile,readiness,unavailable)))continue;
        slots++;
        const credits=MUSCLE_CREDIT[pat]||{};
        for(const m in credits)out[m]+=credits[m];
      }
    }
    return out;
  }
  function weeklyAllocationContext(input){
    const {p,r,catalog,history,now,choice,sessionIndex,unavailable,targets,weekly,focus,response,desired}=input;
    const last7=datedHistory(history,now).filter(z=>now-z.time<=7*86400000&&executedSets(z.session).length).length;
    const remaining=clamp(p.days-last7,1,p.days);
    const exposures=projectedExposures(choice.split,p,r,catalog,unavailable,sessionIndex,remaining,desired);
    const quota={};
    for(const m of GROUPS) quota[m]=round(clamp((targets[m]-weekly[m])/Math.max(1,exposures[m]),0,8),2);
    return {quota,exposures,remaining,last7,focus,response};
  }
  function perExerciseMax(e,p,r,response,focus,analysis,minutes){
    if(recoveryRisk(r))return 2;
    if(response[e.m]?.highFatigue||analysis.setsAdjustment<0)return 2;
    const cap=[3,4,5,6][p.level];
    return clamp(cap+(p.level>=2&&focus.has(e.m)&&minutes>=90?1:0),2,7);
  }
  function benefitOfExtra(item,chosen,alloc,targets,weekly,focus){
    const c=MUSCLE_CREDIT[item.pattern]||{};
    const already=currentWorkingCredits(chosen);
    let benefit=0;
    for(const m in c){
      const deficiency=Math.max(0,alloc.quota[m]-already[m]);
      if(deficiency<=0.18)continue;
      const reach=Math.min(c[m],deficiency);
      benefit+=reach*(MAJOR.has(m)?3.2:1.7)*(focus.has(m)?1.26:1);
    }
    const count=item.sets.filter(s=>!s.warmup).length;
    return benefit - Math.max(0,count-2)*.11;
  }
  function distributeWorkingSets(chosen,params){
    const {p,r,history,now,pace,budget,alloc,targets,weekly,focus}=params;
    let time=chosen.reduce((v,z)=>v+exerciseTime(z.exercise,z.sets,history,now)*pace,0);
    // Only add sets with meaningful remaining weekly-musclegroup demand.
    // The estimated added work *and* the resulting rest must fit the session budget.
    for(let iter=0;iter<70;iter++){
      const options=[];
      for(const it of chosen){
        const n=it.sets.filter(z=>!z.warmup).length;
        if(n>=it.maxWorkingSets)continue;
        const value=benefitOfExtra(it,chosen,alloc,targets,weekly,focus);
        if(value<=.25)continue;
        const next=prescribeSets(it.exercise,p,r,it.loadDecision,n+1);
        const oldTime=exerciseTime(it.exercise,it.sets,history,now)*pace;
        const newTime=exerciseTime(it.exercise,next,history,now)*pace;
        const delta=newTime-oldTime;
        if(delta<0||time+delta>budget)continue;
        options.push({it,next,delta,score:value/Math.max(30,delta)*100});
      }
      if(!options.length)break;
      options.sort((a,b)=>b.score-a.score||a.it.exercise.id.localeCompare(b.it.exercise.id));
      const winner=options[0];winner.it.sets=winner.next;time+=winner.delta;
    }
    return time;
  }
  function weeklyMuscleCredits(history,catalog,ctx={}){
    const now=number(ctx.now,Date.now()),days=clamp(number(ctx.days,7),1,90);
    const table=new Map(catalog.map(x=>[x.id,x]));const out=Object.fromEntries(GROUPS.map(g=>[g,0]));
    for(const row of datedHistory(history,now)){
      if(now-row.time>days*86400000)continue;
      for(const s of executedSets(row.session)){
        const pat=table.get(s.id)?.pattern||s.pattern;const c=MUSCLE_CREDIT[pat]||{};
        for(const k in c)out[k]+=c[k];
      }
    }
    for(const g of GROUPS)out[g]=round(out[g],2);
    return out;
  }
  function muscleTargets(profile,readiness,response={}){
    const p=normalizeProfile(profile),r=normalizeReadiness(readiness),focus=focusGroups(p);
    // starting heuristics; these are NOT universal optimal set counts
    let v=[6,8,11,14][p.level];if(p.goal==='fitness')v*=.8;
    if(p.goal==='strength')v*=.90;
    if(recoveryRisk(r))v*=.78;
    const t={};for(const g of GROUPS){let x=v*(MAJOR.has(g)?1:.5);
      if(focus.has(g))x*=1.2;
      const z=response[g];if(z&&z.samples>=4){
        if(z.stalled&&z.recoveryAdequate)x*=1.08;
        if(z.highFatigue)x*=.8;
      }
      t[g]=clamp(Math.round(x),MAJOR.has(g)?3:2,MAJOR.has(g)?16:10);
    }return t;
  }
  function responseModel(history,catalog,ctx={}) {
    const now=number(ctx.now,Date.now()),lookup=new Map(catalog.map(e=>[e.id,e]));
    const model=Object.fromEntries(GROUPS.map(g=>[g,{samples:0,sessions:0,successes:0,highFatigue:false,
      stalled:false,recoveryAdequate:false,successRate:null}]));
    const sessionRows=Object.fromEntries(GROUPS.map(g=>[g,[]]));
    const byExercise=new Map();
    for(const h of datedHistory(history,now).slice(-28)){
      const grouped=new Map();
      for(const z of executedSets(h.session)){
        const e=lookup.get(z.id),m=e?.m||PATTERN_GROUP[z.pattern];if(!m||!model[m])continue;
        const b=model[m];b.samples++;
        if(number(z.set.actualReps)>=number(z.set.targetReps,Infinity))b.successes++;
        if(!grouped.has(m))grouped.set(m,[]);grouped.get(m).push(z);
        if(e&&usesExternalLoad(e)&&validSet(z)){
          if(!byExercise.has(e.id))byExercise.set(e.id,[]);
          byExercise.get(e.id).push({time:h.time,muscle:m,proxy:number(z.set.actualWeight)*(1+clamp(number(z.set.actualReps),1,15)/30)});
        }
      }
      for(const [m,sets] of grouped){
        const rir=median(sets.map(z=>number(z.set.rir,NaN)).filter(Number.isFinite));
        sessionRows[m].push({time:h.time,rir,hard:rir!==null&&rir<=1,
          soreness:numFeedback(h.session,'soreness'),difficulty:numFeedback(h.session,'difficulty'),pain:!!h.session.feedback?.pain});
      }
    }
    for(const m of GROUPS){const b=model[m],rows=sessionRows[m];b.sessions=rows.length;
      b.successRate=b.samples?round(b.successes/b.samples,2):null;
      const recent=rows.slice(-3),pain=recent.some(x=>x.pain),fatigue=recent.filter(x=>x.soreness!==null&&x.soreness>=4).length;
      b.highFatigue=pain||fatigue>=2||recent.length>=2&&recent.filter(x=>x.hard||x.difficulty!==null&&x.difficulty>=9).length>=2;
      b.recoveryAdequate=recent.length>=2&&!b.highFatigue&&recent.filter(x=>x.soreness!==null).length>=2;
      // Plateau is assessed across separate sessions of a *comparable exercise*, not sets of different exercises.
      const candidates=[];
      for(const [id,sets] of byExercise){if(lookup.get(id)?.m!==m)continue;
        const perDay=new Map();for(const a of sets){if(!perDay.has(a.time))perDay.set(a.time,[]);perDay.get(a.time).push(a.proxy);}
        const values=[...perDay].sort((a,b)=>a[0]-b[0]).map(([time,proxies])=>({time,value:Math.max(...proxies)}));
        if(values.length<4)continue;
        const last=values.slice(-4);const prior=median(last.slice(0,2).map(z=>z.value)),after=median(last.slice(2).map(z=>z.value));
        if(prior>0)candidates.push({samples:values.length,stalled:after<=prior*1.01});
      }
      candidates.sort((a,b)=>b.samples-a.samples);
      b.stalled=!!candidates.length&&candidates[0].stalled;
    }
    return model;
  }
  function numFeedback(s,name) {const n=number(s.feedback?.[name],NaN);return Number.isFinite(n)?n:null;}
  function patternAvailability(catalog,patterns,p,r,unavailable){return patterns.filter(pt=>catalog.some(e=>e.pattern===pt&&allowedExercise(e,p,r,unavailable)));}
  function estimateSetOpportunity(p){return p.duration<=40?3:p.duration<=70?4:p.duration<=95?5:6;}
  function assessSplit(split,p,catalog,history,readiness,unavailable=[],ctx={}) {
    const now=number(ctx.now,Date.now()),r=normalizeReadiness(readiness),focus=focusGroups(p);
    const w=Object.fromEntries(GROUPS.map(g=>[g,0]));const exposures=Object.fromEntries(GROUPS.map(g=>[g,0]));
    const maxEx=estimateSetOpportunity(p),days=[],notes=[];
    for(let d=0;d<p.days;d++){
      const day=split.days[d%split.days.length],used=new Set(),muscles=new Set();let slots=0;
      for(const pat of day.patterns){if(slots>=maxEx)break;
        const available=catalog.filter(e=>e.pattern===pat&&allowedExercise(e,p,r,unavailable));
        if(!available.length)continue;
        available.sort((a,b)=>(SIMPLE_RANK.get(a.id)??30)-(SIMPLE_RANK.get(b.id)??30));
        const e=available[0];if(used.has(e.id))continue;used.add(e.id);slots++;
        for(const m in MUSCLE_CREDIT[pat]||{}){w[m]+=MUSCLE_CREDIT[pat][m]*(p.level===0?2:3);if(MUSCLE_CREDIT[pat][m]>=.35)muscles.add(m);}
      }
      for(const m of muscles)exposures[m]++;
      days.push({name:day.name,slots,muscles:Array.from(muscles)});
    }
    const targets=muscleTargets(p,r,responseModel(history,catalog,{now}));
    let coverage=0,focusFit=0,missing=0,excess=0;
    for(const m of GROUPS){const weight=MAJOR.has(m)?1.4:0.5;
      coverage+=weight*Math.min(1,w[m]/Math.max(1,targets[m]));
      if(focus.has(m))focusFit+=Math.min(1,w[m]/Math.max(1,targets[m]));
      if(MAJOR.has(m)&&exposures[m]===0)missing+=3.5;
      if(MAJOR.has(m)&&exposures[m]===1&&p.days>=4)missing+=1;
      if(w[m]>targets[m]*1.5)excess+=(w[m]-targets[m]*1.5)*.25;
    }
    // A candidate with most sessions containing only one usable exercise is invalid.
    const avail=average(days.map(d=>Math.min(1,d.slots/Math.min(3,maxEx))))||0;
    let score=coverage*5+focusFit*3+avail*8-missing*4-excess;
    if(p.level<=1&&split.id==='full')score+=5;
    if(p.level===0&&split.id==='four')score-=12;
    if(p.days<=3&&split.id==='four')score-=20;
    if(p.days===2&&split.id==='full')score+=6;
    if(p.days>=5&&split.id==='full')score-=7;
    if(p.days===3&&split.id==='ppl')score-=4;
    if(p.days>=5&&p.level>=2&&split.id==='ppl')score+=4;
    if(p.days===4&&split.id==='upperlower')score+=6;
    if(split.id==='four'&&p.days<4)notes.push('주 4일 미만에서는 특정 근육의 자극 빈도가 너무 낮아질 수 있음');
    if(missing>0)notes.push('주간 주요 근육군 운동 빈도를 확인해야 함');
    return {id:split.id,label:split.name,score:round(score,2),coverage:round(coverage,2),focusFit:round(focusFit,2),missPenalty:round(missing,2),equipmentFit:round(avail,2),predictedWeeklyCredits:Object.fromEntries(Object.entries(w).map(([k,v])=>[k,round(v,1)])),exposures,days,notes};
  }
  function rankSplits(input){const p=normalizeProfile(input.profile),r=normalizeReadiness(input.readiness),cat=input.catalog||[],h=input.history||[];
    return SPLITS.map(s=>assessSplit(s,p,cat,h,r,input.unavailable||[],input.context||{})).sort((a,b)=>b.score-a.score||a.id.localeCompare(b.id));
  }
  function selectSplit(profile,catalog=[],history=[],readiness={},unavailable=[],context={}){
    const candidates=rankSplits({profile,catalog,history,readiness,unavailable,context});
    return {split:SPLITS.find(x=>x.id===candidates[0].id),score:candidates[0].score,candidates};
  }
  function stretchesFor(patterns,available){
    const upper=patterns.some(x=>['push','pullvertical','pullhorizontal','verticalpush','shoulderiso'].includes(x));
    const lower=patterns.some(x=>['squat','hinge','glutes','calves'].includes(x));
    const before=available<=40?5:available<=70?7:available<=95?9:10;
    const after=available<=40?4:available<=70?5:available<=95?7:8;
    const pre=[{id:'march',name:'가볍게 걷기',seconds:Math.min(120,before*60*.38)}];
    if(lower)pre.push({id:'hip',name:'고관절·발목 동적 가동',seconds:60});
    if(upper)pre.push({id:'arm',name:'팔 돌리기·어깨 동적 가동',seconds:60});
    pre.push({id:'squats',name:'첫 운동 가벼운 예행 동작',seconds:60});
    const post=[{id:'cool_walk',name:'천천히 걷고 호흡 정리',seconds:90}];
    if(upper)post.push({id:'chest',name:'상체 가벼운 정적 스트레칭',seconds:45});
    if(lower)post.push({id:'quad',name:'하체 가벼운 정적 스트레칭',seconds:45});
    function fit(items,target){let arr=items.map(x=>({...x,seconds:Math.round(x.seconds)}));let remain=target*60-sum(arr.map(z=>z.seconds));
      if(remain<0){for(let i=arr.length-1;i>=0&&remain<0;i--){const less=Math.min(arr[i].seconds-20,-remain);arr[i].seconds-=less;remain+=less;}}
      if(remain>0){arr[0].seconds+=remain;}
      return arr.filter(x=>x.seconds>0);
    }
    return {pre:fit(pre,before),post:fit(post,after),preSeconds:before*60,postSeconds:after*60};
  }
  function exercisePriority(e,ctx,chosen){const {p,focus,targets,weekly,response}=ctx;
    const usedSame=chosen.filter(x=>x.muscle===e.m).length;
    const credited=chosen.reduce((v,x)=>v+(MUSCLE_CREDIT[x.pattern]?.[e.m]||0)*x.sets.filter(y=>!y.warmup).length,0);
    const need=clamp((targets[e.m]||2)-(weekly[e.m]||0)-credited,-8,15);
    const useful=need*.65+(focus.has(e.m)?4:0)+(e.kind==='compound'&&chosen.length<2?2:0);
    const simple=SIMPLE_RANK.has(e.id)?3.5-SIMPLE_RANK.get(e.id)*.05:(e.gear==='machine'?1:0);
    const risk=response[e.m]?.highFatigue?-5:0;
    return useful+simple+risk-usedSame*3-number(e.level)*.7;
  }
  function sessionPace(history,now){const ratios=datedHistory(history,now).slice(-8).map(x=>{
    const s=x.session,a=number(s.durationMin,NaN),b=number(s.timeLimit,NaN);
    return a>10&&b>=25&&a<300?a/b:NaN;
  }).filter(v=>Number.isFinite(v)&&v>=.5&&v<=2.5);return clamp(median(ratios)??1,.85,1.4);}
  function planDay(input={}){
    const p=normalizeProfile(input.profile||{}),r=normalizeReadiness(input.readiness||{}),catalog=input.catalog||[],history=input.history||[],ctx=input.context||{};
    const available=clamp(number(input.minutes,p.duration),30,120),now=number(ctx.now,Date.now()),unavailable=input.unavailable||[];
    const choice=selectSplit(p,catalog,history,r,unavailable,{now});
    const tmpl=choice.split.days[Math.max(0,Math.floor(number(input.sessionIndex,0)))%choice.split.days.length];
    const focus=focusGroups(p),response=responseModel(history,catalog,{now}),targets=muscleTargets(p,r,response),weekly=weeklyMuscleCredits(history,catalog,{now});
    const availablePatterns=patternAvailability(catalog,tmpl.patterns,p,r,unavailable);
    const safety={stop:false,flags:[]};if(r.pain)safety.flags.push('운동 관련 통증이 있습니다. 통증이 있는 부위는 운동에서 제외하고 증상이 지속되면 전문가와 상의하세요.');
    if(r.pain&&!r.painArea){safety.stop=true;safety.flags.push('통증 부위가 지정되지 않아 자동 중량 운동을 생성하지 않습니다.');}
    const stretch=stretchesFor(availablePatterns,available),budgetSeconds=available*60-stretch.preSeconds-stretch.postSeconds;
    const patterns=[...availablePatterns,...Object.keys(PATTERN_GROUP).filter(pat=>!availablePatterns.includes(pat)&&focus.has(PATTERN_GROUP[pat]))];
    const chosen=[],used=new Set(),desired=estimateSetOpportunity({...p,duration:available});
    const pace=sessionPace(history,now),effectiveBudget=Math.max(0,budgetSeconds-available*60*.04);
    const sessionIndex=Math.max(0,Math.floor(number(input.sessionIndex,0)));
    const alloc=weeklyAllocationContext({p,r,catalog,history,now,choice,sessionIndex,
      unavailable,targets,weekly,focus,response,desired});
    let usedSeconds=0;
    // Phase A: secure a varied core program with 1-2 working sets per movement.
    // Fewer movements are preferable to a program with no capacity for meaningful volume.
    if(!safety.stop)for(const pattern of patterns){
      if(chosen.length>=desired+(focus.size>=2&&available>=75?1:0))break;
      const options=catalog.filter(e=>e.pattern===pattern&&!used.has(e.id)&&allowedExercise(e,p,r,unavailable))
       .sort((a,b)=>exercisePriority(b,{p,focus,targets,weekly,response},chosen)-exercisePriority(a,{p,focus,targets,weekly,response},chosen));
      for(const e of options.slice(0,4)){
        const load=assessLoad(e,history,r,{...ctx,now});if(load.action==='stop')continue;
        const minSets=recoveryRisk(r)||load.setsAdjustment<0?1:2;
        const sets=prescribeSets(e,p,r,load,minSets);
        const seconds=exerciseTime(e,sets,history,now)*pace;
        if(usedSeconds+seconds>effectiveBudget)continue;
        used.add(e.id);
        chosen.push({id:e.id,name:e.n,muscle:e.m,pattern:e.pattern,gear:e.gear,kind:e.kind,
          exercise:e,maxWorkingSets:perExerciseMax(e,p,r,response,focus,load,available),
          sets,estimateSeconds:Math.ceil(seconds),loadDecision:load,reason:load.reason});
        usedSeconds+=seconds;break;
      }
    }
    // Phase B: distribute available time by projected per-muscle weekly deficits.
    // This can result in 2, 3, 4, 5 or 6+ sets depending on purpose and constraints.
    usedSeconds=distributeWorkingSets(chosen,{p,r,history,now,pace,budget:effectiveBudget,
      alloc,targets,weekly,focus});
    const workingToday=currentWorkingCredits(chosen);
    for(const it of chosen){
      it.estimateSeconds=Math.ceil(exerciseTime(it.exercise,it.sets,history,now)*pace);
      const n=it.sets.filter(z=>!z.warmup).length;
      it.volumeReason=`${it.muscle} 주간 목표 ${targets[it.muscle]}세트, 최근 7일 수행 약 ${round(weekly[it.muscle],1)}세트, 남은 예정 운동 기회를 고려해 오늘 ${n}세트를 배정했습니다.`;
      it.reason=`${it.loadDecision.reason} ${it.volumeReason}`;
      delete it.exercise;delete it.maxWorkingSets;
    }
    const estimatedSeconds=Math.ceil(usedSeconds+stretch.preSeconds+stretch.postSeconds);
    if(chosen.length===0&&!safety.stop)safety.flags.push('설정한 기구·시간·제한 사항에서 적합한 운동을 찾지 못했습니다.');
    if(chosen.some(x=>x.loadDecision.action==='calibrate'))safety.flags.push('최초 종목에는 실제 가벼운 시험 세트가 필요하며 중량을 임의로 확정하지 않습니다.');
    if(choice.candidates[0].score-choice.candidates[1].score<3)safety.flags.push('분할 후보 점수가 비슷해 선택된 분할이 유일한 정답은 아닙니다.');
    const outcome={schema:'precision-v3',version:VERSION,profileSnapshot:p,readiness:r,
      split:choice.split.id,splitLabel:choice.split.name,dayName:tmpl.name,
      splitCandidates:choice.candidates,minutes:available,estimatedSeconds,estimatedMinutes:Math.ceil(estimatedSeconds/60),
      unusedMinutes:Math.max(0,round((available*60-estimatedSeconds)/60,1)),
      weeklyTarget:targets,weeklyDone:weekly,weeklyQuota:alloc.quota,plannedWorkingCredits:workingToday,items:chosen,stretch,
      safety,concerns:safety.flags,explanation:`${choice.split.name}: ${choice.candidates.length}개 분할 후보를 비교하고 근육별 7일 목표 세트를 ${alloc.remaining}회 예정 운동에 배분했습니다. 종목당 3세트 고정이 아닌 시간·회복·수행 이력을 반영했습니다.`,
      metadata:{createdAt:now,paceFactor:pace,scoringType:'heuristic-comparison',clinicalValidation:false}
    };return outcome;
  }
  function planProgram(input={}) {
    const p=normalizeProfile(input.profile||{}),weeks=clamp(Math.round(number(input.weeks,8)),4,12),ctx=input.context||{};
    const choice=selectSplit(p,input.catalog||[],input.history||[],input.readiness||{},input.unavailable||[],ctx);
    const r=normalizeReadiness(input.readiness||{}),response=responseModel(input.history||[],input.catalog||[],ctx),targets=muscleTargets(p,r,response);
    const calendar=[];for(let w=0;w<weeks;w++){
      const sessions=[];for(let d=0;d<p.days;d++){
        const offset=w*p.days+d,day=choice.split.days[offset%choice.split.days.length];
        sessions.push({sequence:offset+1,slot:d+1,name:day.name,patterns:day.patterns.slice(),minutes:p.duration});
      }
      calendar.push({week:w+1,sessions,review:w===1||w===3||((w+1)%4===0),
        guidance:w===0?'처음에는 가벼운 중량·자세 숙달로 시작하세요.':'실제 수행 기록과 회복 상태에 따라 자동 재계획합니다.'});
    }
    const risk=recoveryRisk(r),alerts=[];
    if(risk)alerts.push('현재 컨디션이 좋지 않아 증량보다 회복을 우선합니다.');
    if(input.history?.length===0)alerts.push('운동 기록이 없어 목표 세트 수는 초기 추정입니다. 처음 여러 운동일은 기준점 확보 기간입니다.');
    return {schema:'precision-v3-program',weeks,split:choice.split.id,splitLabel:choice.split.name,
      candidates:choice.candidates,weeklyTargets:targets,calendar,reviewCycle:'2~4주마다 기록을 평가하며 필요시 분할과 세트 수를 재선정',
      alerts,notes:['장기 달력은 확정 중량표가 아닙니다. 매 운동 시작 시 컨디션과 시간에 맞춰 다시 처방합니다.','운동량 조절 수치는 개인의 운동 효과를 보장하지 않는 보수적 개발 가정입니다.']};
  }
  function adjustNextSet(e,planned,nextSet,result,context={}) {
    if(!nextSet)return null;const out={...nextSet,reason:'기존 계획을 유지합니다.',halt:false};
    if(!result?.done)return out;
    if(result.pain||result.form==='poor'){out.halt=!!result.pain;out.reason=result.pain?'통증이 발생해 운동을 중단합니다.':'자세 불안정으로 자동 증량하지 않습니다.';return out;}
    if(planned?.warmup||nextSet.warmup||nextSet.targetWeight===null||isTimed(e))return out;
    const actual=number(result.reps,0),target=number(planned.targetReps,10),rir=number(result.rir,NaN),unit=equipmentIncrement(e,context);
    if(actual<target*.8){const current=number(nextSet.targetWeight,0);out.targetWeight=Math.min(current,quantize(current*.95,unit));out.restSec=number(nextSet.restSec,90)+30;out.reason='목표 횟수를 크게 밑돌아 다음 세트의 중량을 낮추고 휴식을 늘렸습니다.';}
    else if(actual>=target&&rir>=4&&context.allowIntraSessionIncrease){const current=number(nextSet.targetWeight,0),candidate=current+unit;
      if(current>0&&unit/current<=.06){out.targetWeight=candidate;out.reason='충분한 반복 여유가 기록되어 최소 단위 증량을 제안합니다.';}
    }return out;
  }
  function compareAlternatives(original,catalog,profile,readiness,unavailable=[],context={}) {
    const p=normalizeProfile(profile),r=normalizeReadiness(readiness);
    return (catalog||[]).filter(e=>e.id!==original.id&&e.pattern===original.pattern&&allowedExercise(e,p,r,unavailable))
      .map(e=>({id:e.id,name:e.n,score:round(10-(SIMPLE_RANK.get(e.id)??25)*.13-number(e.level)*.6,2),
        requiresCalibration:!exerciseSessions(context.history||[],e.id,number(context.now,Date.now())).length,
        reason:'같은 주동작 패턴을 유지합니다. 기구마다 실제 저항이 달라 대체 운동의 중량은 별도 설정합니다.'}))
      .sort((a,b)=>b.score-a.score);
  }
  function reviewSession(session,previousHistory,catalog,profile,readiness,context={}) {
    const h=[...(previousHistory||[]),session],list=[],seen=new Set();
    for(const z of executedSets(session)){if(seen.has(z.id))continue;seen.add(z.id);
      const e=catalog.find(x=>x.id===z.id);if(!e)continue;
      const before=assessLoad(e,previousHistory,readiness,context),after=assessLoad(e,h,readiness,context);
      list.push({id:e.id,name:e.n,from:before.weight,to:after.weight,decision:after.action,confidence:after.confidence,reason:after.reason});
    }
    return {schema:'precision-v3-review',changed:list,weeklyCredits:weeklyMuscleCredits(h,catalog,context),response:responseModel(h,catalog,context),notes:['전체 난이도 하나만으로 전 종목을 일괄 증량하지 않습니다.']};
  }
  function validatePlan(plan) {const issues=[];
    if(plan.estimatedSeconds>plan.minutes*60+1)issues.push('time-over');
    if(plan.safety?.stop&&plan.items.length)issues.push('pain-stop-violated');
    for(const item of plan.items||[]){if(!item.sets.length)issues.push('no-sets:'+item.id);
      for(const s of item.sets){if(number(s.targetReps)<=0)issues.push('bad-reps:'+item.id);
        if(s.targetWeight!==null&&number(s.targetWeight)<0)issues.push('bad-weight:'+item.id);
        if(s.restSec<0)issues.push('bad-rest:'+item.id);
      }
    }return {ok:issues.length===0,issues};
  }
  return {VERSION,SPLITS,prescribeSets,stretchesFor,targetRange,normalizeProfile,normalizeReadiness,exerciseSessions,assessLoad,weeklyMuscleCredits,
    muscleTargets,responseModel,rankSplits,selectSplit,planProgram,planDay,adjustNextSet,compareAlternatives,
    reviewSession,validatePlan,allowedExercise,workingMuscleCredits:currentWorkingCredits,estimateExerciseSeconds:exerciseTime};
});
