#!/usr/bin/env python3
"""FitPlan V4 APK builder without external Android SDK.

Creates a minimal Dex-backed Android Activity hosting packaged local HTML/CSS/JS, with JavaScriptInterface for screen wake and vibrator.
Emits binary AndroidManifest.xml and APK Signature Scheme v2 signature.
Uses only Python stdlib and cryptography. minSdkVersion=24.
"""
from __future__ import annotations
import os, io, sys, struct, hashlib, zlib, zipfile, datetime
from pathlib import Path
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding

P=Path(__file__).resolve().parent
OUT=Path('/mnt/data/FitPlan_1.9.8_Stable.apk')
APP='com.fitplan.autocv196'
U32=lambda n:struct.pack('<I',n)
U16=lambda n:struct.pack('<H',n)
U64=lambda n:struct.pack('<Q',n)

def uleb(n):
    out=bytearray()
    while True:
        b=n&0x7f;n>>=7
        if n:out.append(b|0x80)
        else:out.append(b);break
    return bytes(out)

def align4(b):
    while len(b)%4:b.append(0)

def build_dex():
    # Use the exact previously user-confirmed working 0.1 startup/activity DEX.
    # The experimental 0.2-0.4 native bridge used untested handwritten instructions
    # and could cause Android ART verification/runtime errors at launch.
    # Stability build: keep screen wake/vibration on JS fallback; no native bridge.
    dex=bytearray((P/'launcher.dex').read_bytes())
    before=b'Lcom/fitplan/autocoach/MainActivity;'
    after=b'Lcom/fitplan/autocv196/MainActivity;'
    assert len(before)==len(after) and dex.count(before)==1
    dex=dex.replace(before,after)
    import zlib,hashlib,struct
    dex[12:32]=hashlib.sha1(dex[32:]).digest()
    struct.pack_into('<I',dex,8,zlib.adler32(dex[12:])&0xffffffff)
    return bytes(dex)

# BINARY XML writer
ANDROID='http://schemas.android.com/apk/res/android'
ATTR_IDS={'theme':0x01010000,'label':0x01010001,'icon':0x01010002,'name':0x01010003,'exported':0x01010010,'versionCode':0x0101021b,'versionName':0x0101021c,'minSdkVersion':0x0101020c,'targetSdkVersion':0x01010270,'allowBackup':0x01010280,'supportsRtl':0x010103af,'usesCleartextTraffic':0x010104ec}

def axml():
    # events: (kind, tag, [(namespace/name,value/type)...])
    start=('start',)
    events=[
        ('start','manifest',[(None,'package',APP,'str'),(ANDROID,'versionCode',63,'int'),(ANDROID,'versionName','1.9.8','str')]),
        ('start','uses-sdk',[(ANDROID,'minSdkVersion',24,'int'),(ANDROID,'targetSdkVersion',32,'int')]),
        ('end','uses-sdk',[]),
        ('start','uses-permission',[(ANDROID,'name','android.permission.INTERNET','str')]),
        ('end','uses-permission',[]),
        ('start','uses-permission',[(ANDROID,'name','android.permission.VIBRATE','str')]),
        ('end','uses-permission',[]),
        ('start','application',[(ANDROID,'label','FitPlan','str'),(ANDROID,'icon',0x7f010000,'ref'),(ANDROID,'allowBackup',True,'bool'),(ANDROID,'supportsRtl',True,'bool'),(ANDROID,'usesCleartextTraffic',False,'bool')]),
        ('start','activity',[(ANDROID,'name',APP+'.MainActivity','str'),(ANDROID,'exported',True,'bool')]),
        ('start','intent-filter',[]),
        ('start','action',[(ANDROID,'name','android.intent.action.MAIN','str')]),
        ('end','action',[]),
        ('start','category',[(ANDROID,'name','android.intent.category.LAUNCHER','str')]),
        ('end','category',[]),
        ('end','intent-filter',[]),
        ('end','activity',[]),
        ('end','application',[]),
        ('end','manifest',[]) ]
    a_names=sorted(ATTR_IDS,key=lambda n:ATTR_IDS[n]);slist=list(a_names)
    def insert(s):
        if s is not None and s not in slist:slist.append(s)
    insert('android');insert(ANDROID)
    for kind,tag,attrs in events:
        insert(tag)
        for ns,name,value,typ in attrs:
            insert(name);insert(ns)
            if typ=='str':insert(value)
    indexes={v:i for i,v in enumerate(slist)}
    def utf8len(n):return bytes([n]) if n<=0x7f else bytes([(n>>8)|0x80,n&0xff])
    pooldata=bytearray();offsets=[]
    for s in slist:
        offsets.append(len(pooldata));raw=s.encode('utf-8');pooldata.extend(utf8len(len(s.encode('utf-16-le'))//2)+utf8len(len(raw))+raw+b'\0')
    align4(pooldata)
    sp_size=28+4*len(slist)+len(pooldata)
    stringpool=struct.pack('<HHIIIIII',0x0001,28,sp_size,len(slist),0,0x100,28+4*len(slist),0)
    stringpool+=b''.join(U32(x) for x in offsets)+pooldata
    # resource map: 1:1 index mapping to Android attr ids, 0 otherwise
    resids=[ATTR_IDS.get(s,0) for s in slist]
    resmap=struct.pack('<HHI',0x0180,8,8+4*len(resids))+b''.join(U32(x) for x in resids)
    def node(typ,payload,extra=b''):
        return struct.pack('<HHIII',typ,16,16+len(payload)+len(extra),1,0xffffffff)+payload+extra
    out=bytearray()
    out.extend(node(0x0100,U32(indexes['android'])+U32(indexes[ANDROID])))
    for kind,tag,attrs in events:
        if kind=='end':out.extend(node(0x0103,U32(0xffffffff)+U32(indexes[tag])));continue
        attrs=sorted(attrs,key=lambda a:ATTR_IDS.get(a[1],0))
        body=bytearray()
        for ns,name,value,typ in attrs:
            nsid=indexes[ns] if ns else 0xffffffff
            raw=indexes[value] if typ=='str' else 0xffffffff
            if typ=='str':data_type=3;data=indexes[value]
            elif typ=='bool':data_type=0x12;data=0xffffffff if value else 0
            elif typ=='ref':data_type=0x01;data=int(value)
            else:data_type=0x10;data=int(value)
            body.extend(U32(nsid)+U32(indexes[name])+U32(raw)+struct.pack('<HBBI',8,0,data_type,data))
        ext=struct.pack('<IIHHHHHH',0xffffffff,indexes[tag],20,20,len(attrs),0,0,0)
        out.extend(node(0x0102,ext,body))
    out.extend(node(0x0101,U32(indexes['android'])+U32(indexes[ANDROID])))
    full=bytearray(struct.pack('<HHI',0x0003,8,8+len(stringpool)+len(resmap)+len(out)))
    full+=stringpool+resmap+out
    return bytes(full)


# resources.arsc: one Android drawable launcher icon resource at 0x7f010000.
def arsc_string_pool(strings):
    def length8(n):
        assert n < 32768
        return bytes([n]) if n <= 127 else bytes([(n >> 8) | 0x80,n & 255])
    payload=bytearray(); offsets=[]
    for string in strings:
        offsets.append(len(payload)); encoded=string.encode('utf-8')
        payload+=length8(len(string.encode('utf-16-le'))//2)+length8(len(encoded))+encoded+b'\x00'
    align4(payload)
    return (struct.pack('<HHIIIIII',0x0001,28,28+4*len(strings)+len(payload),len(strings),0,0x100,28+4*len(strings),0)
        +b''.join(U32(x) for x in offsets)+payload)

def build_resources():
    globalpool=arsc_string_pool(['res/drawable/icon.png'])
    typepool=arsc_string_pool(['drawable'])
    keypool=arsc_string_pool(['ic_launcher'])
    spec=struct.pack('<HHIB3xI',0x0202,16,20,1,1)+U32(0x40000000)
    config=U32(64)+bytes(60)
    entry=struct.pack('<HHI',8,0,0)+struct.pack('<HBBI',8,0,3,0)
    type_header_size=8+12+len(config)
    typ=(struct.pack('<HHIBB HII',0x0201,type_header_size,type_header_size+4+len(entry),1,0,0,1,type_header_size+4)
         +config+U32(0)+entry)
    name=APP.encode('utf-16-le')+bytes(256-len(APP.encode('utf-16-le')))
    pack_header=(struct.pack('<HHII',0x0200,288,288+len(typepool)+len(keypool)+len(spec)+len(typ),0x7f)
           +name+struct.pack('<IIIII',288,1,288+len(typepool),1,0))
    assert len(pack_header)==288
    package=pack_header+typepool+keypool+spec+typ
    return struct.pack('<HHII',0x0002,12,12+len(globalpool)+len(package),1)+globalpool+package

def lp(s):return U32(len(s))+s

def content_digest(sections):
    pieces=[]
    for section in sections:
        for i in range(0,len(section),1024*1024):
            chunk=section[i:i+1024*1024]
            pieces.append(hashlib.sha256(b'\xa5'+U32(len(chunk))+chunk).digest())
    return hashlib.sha256(b'\x5a'+U32(len(pieces))+b''.join(pieces)).digest()

def getkey():
    keyfile=P/'fitplan_signing_private_key.pem'
    if keyfile.is_file():
        key=serialization.load_pem_private_key(keyfile.read_bytes(),password=None)
    else:
        key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        keyfile.write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
        os.chmod(keyfile,0o600)
    certfile=P/'fitplan_signing_certificate.der'
    if certfile.is_file():cert=x509.load_der_x509_certificate(certfile.read_bytes())
    else:
        now=datetime.datetime.now(datetime.timezone.utc)
        who=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'FitPlan Local Development')])
        cert=x509.CertificateBuilder().subject_name(who).issuer_name(who).public_key(key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now-datetime.timedelta(days=1)).not_valid_after(now+datetime.timedelta(days=3650)).sign(key,hashes.SHA256())
        certfile.write_bytes(cert.public_bytes(serialization.Encoding.DER))
    return key,cert

def sigv2(apk,key,cert):
    # zip local file entries + central directory + EOCD (22 byte, no zip comment)
    eocdoff=apk.rfind(b'PK\x05\x06')
    if eocdoff<0:raise ValueError('EOCD not found')
    central_off=struct.unpack_from('<I',apk,eocdoff+16)[0]
    # Contents digest computes with central dir offset adjusted to signature block start.
    digest=content_digest([apk[:central_off],apk[central_off:eocdoff],apk[eocdoff:]])
    alg=0x0103  # RSASSA-PKCS1-v1_5 SHA-256
    digests=lp(lp(U32(alg)+lp(digest)))
    certificates=lp(lp(cert.public_bytes(serialization.Encoding.DER)))
    signeddata=digests+certificates+lp(b'')
    signature=key.sign(signeddata,padding.PKCS1v15(),hashes.SHA256())
    signatures=lp(lp(U32(alg)+lp(signature)))
    pubkey=key.public_key().public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)
    signer=lp(signeddata)+signatures+lp(pubkey)
    signers=lp(lp(signer))
    pair=U64(4+len(signers))+U32(0x7109871a)+signers
    blocksize=len(pair)+24
    block=U64(blocksize)+pair+U64(blocksize)+b'APK Sig Block 42'
    eocd=bytearray(apk[eocdoff:])
    struct.pack_into('<I',eocd,16,central_off+len(block))
    return apk[:central_off]+block+apk[central_off:eocdoff]+bytes(eocd)

def put_aligned_stored(z, filename, payload):
    # Android API 30+ requires resources.arsc STORED and 4-byte ZIP data alignment.
    # Align all stored Android program and resource entries as good practice.
    file_header_length = 30 + len(filename.encode('utf-8'))
    position = z.fp.tell()
    padding = (-(position + file_header_length + 4)) % 4
    extra = struct.pack('<HH',0xa11e,padding) + bytes(padding)
    info = zipfile.ZipInfo(filename)
    info.compress_type = zipfile.ZIP_STORED
    info.extra = extra
    info.external_attr = 0o644 << 16
    z.writestr(info,payload)

def main():
    manifest=axml();dex=build_dex();print('manifest:',len(manifest),'dex:',len(dex))
    bio=io.BytesIO()
    with zipfile.ZipFile(bio,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        put_aligned_stored(z,'AndroidManifest.xml',manifest)
        put_aligned_stored(z,'classes.dex',dex)
        put_aligned_stored(z,'resources.arsc',build_resources())
        z.write(P/'icon.png','res/drawable/icon.png')
        for f in sorted((P/'assets').iterdir()):
            if f.is_file():z.write(f,'assets/'+f.name)
    key,cert=getkey()
    signed=sigv2(bio.getvalue(),key,cert)
    OUT.write_bytes(signed)
    print('APK:',OUT,len(signed),'bytes')
    print('SHA-256:',hashlib.sha256(signed).hexdigest())

if __name__=='__main__':main()
